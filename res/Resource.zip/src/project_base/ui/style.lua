-------------------------------------------------------------------------
-- Title:          所有UI样式的配置
-- Author:      Jackie Liu
-- Date:         2016/11/03 23:55:00
-- Desc:
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
return
{
    txt =
    {
        loading =
        {
            class = "Label",
            sysFnt = "Arial",
            fntSize = 50,
            fntClr = cc.c3b(255,255,255)
        }
    }
}