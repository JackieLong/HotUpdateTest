-------------------------------------------------------------------------
-- Title:          登录界面布局
-- Author:      Jackie Liu
-- Date:         2016/11/06 14:38:53
-- Desc:
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
return
{
    class = "Layer",
    name = "hall",
    {
        class = "Sprite",
        name = "bg",
        src = base.res.login.bg,
        center = ptf.contants.ui.Parent
    },
}