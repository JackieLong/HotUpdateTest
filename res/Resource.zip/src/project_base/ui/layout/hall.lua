-------------------------------------------------------------------------
-- Title:          大厅布局文件
-- Author:      Jackie Liu
-- Date:         2016/11/06 14:38:53
-- Desc:
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
return
{
    class = "Layer",
    name = "hall",
    {
        class = "Sprite",
        name = "bg",
        src = base.res.hall.bg,
        center = ptf.contants.ui.Parent
    },
    {
        -- 随机庄家
        class = "Btn",
        name = "btnSuiJi",
        normal = base.res.common.common_btn_1,
        selected = base.res.common.common_btn_1,
        audio_down = nil,
        audio_up = nil,
        ani_up = nil,
        ani_down = nil,
        pressActionEnabled = true,
        center = "bg"
    }
}