-------------------------------------------------------------------------
-- Author:      Derek
-- Date:        2017-05-14 03:37:49
-- Desc:        网络信号节点
-- Revisions:         Derek create this file at 2017-05-14 03:37:49
-- Copyright (c) 2017 FengYun Game
-------------------------------------------------------------------------

local NetNode = class("NetNode", cc.node)

local SIGNAL_RES = "ui/NetNode/signal%d.png"
local WIFI_RES = "ui/NetNode/wifi%d.png"

function NetNode:ctor(imageNet)
	if simulateNode then
		NetNode.super.ctor(self)
		self:setAnchorPoint(imageNet:getAnchorPoint())
		self:setPosition(imageNet:getPosition())
		imageNet:getParent():addChild(self)
		-- imageNet:setVisible(false)
        self:addChild(imageNet)
        self._imageNet = imageNet
		self:initUI()
	end
end

function NetNode:initUI()
	-- local bg = cc.Sprite:create()
	-- bg:setScale(2)
	-- self:addChild(bg)
	self._imageNet:setVisible(false)
	local function updateNetInfo(dt)
		local netInfo = Market_getInstance():getNetLevel()
		if(0 == netInfo.level) then
			self._imageNet:setVisible(false)
			return
		end
		if(0 == netInfo.type) then
			self._imageNet:setVisible(true)
			self._imageNet:loadTexture(string.format(SIGNAL_RES, netInfo.level))
		elseif(1 == netInfo.type) then
			self._imageNet:setVisible(true)
			self._imageNet:loadTexture(string.format(WIFI_RES, netInfo.level))
		else
			self._imageNet:setVisible(false)
		end
	end
	self:schedule(updateNetInfo, 0.5)
end

return NetNode

