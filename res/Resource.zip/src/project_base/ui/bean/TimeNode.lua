-------------------------------------------------------------------------
-- Author:      Derek
-- Date:        2017-05-14 03:37:49
-- Desc:        时间节点(游戏中自动刷新时间) 
-- Revisions:         Derek create this file at 2017-05-14 03:37:49
-- Copyright (c) 2017 FengYun Game
-------------------------------------------------------------------------
local TimeNode = class("TimeNode", cc.Node)

function TimeNode:ctor(textTime)
	TimeNode.super.ctor(self)
	self:setAnchorPoint(textTime:getAnchorPoint())
	self:setPosition(textTime:getPosition())
	textTime:getParent():addChild(self)]
    self:addChild(textTime)
    self._textTime = textTime
    self._dianText = ccui.Text:create()
    -- simulateNode:setVisible(false)
	self:initUI()
end

function TimeNode:initUI()
	-- local dianText = ccui.Text:create()
	self._dianText:setFontSize(self._textTime:getFontSize())
	self._dianText:setTextColor(self._textTime:getTextColor())
    self._dianText:setFontName(self._textTime:getFontName())
    self._dianText:setString(":")
	self:addChild(self._dianText)
	
	-- local timeText = ccui.Text:create()
	-- timeText:setFontSize(24)
	-- timeText:setTextColor(cc.c4b(250, 180, 80, 255))
	-- self:addChild(timeText)
	self._textTime:setString(os.date("%H:%M", os.time()))
	local function updateProgress(dt)
		dianText:runAction(myactions.LoomingAction(0.1, 1))
		self._textTime:setString(os.date("%H %M", os.time()))
	end
	self:schedule(updateProgress, 1)
end


-- 设置字体大小
function TimeNode:setFontSize(fontSize)
    self._textTime:setFontSize(fontSize)
    self._dianText:setFontSize(fontSize)
end

-- 获取字体大小
function TimeNode:getFontSize()
    return self._textTime:getFontSize()
end

function TimeNode:setFontName(fontName)
    self._textTime:setFontName(fontName)
    self._dianText:setFontName(fontName)
end

-- 获取字体名称
function TimeNode:getFontName()
    return self._textTime:getFontName()
end

-- 设置文字颜色
function TimeNode:setTextColor(color4B)
    self:_textTime:setTextColor(color4B)
    self._dianText:setTextColor(color4B)
end

-- 获取时间文字色值
function timeText:getTextColor()
    return self._textTime:getTextColor()
end

return TimeNode