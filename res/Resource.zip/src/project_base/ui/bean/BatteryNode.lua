-------------------------------------------------------------------------
-- Author:      Derek
-- Date:        2017-05-14 03:37:49
-- Desc:        电量节点
-- Revisions:         Derek create this file at 2017-05-14 03:37:49
-- Copyright (c) 2017 FengYun Game
-------------------------------------------------------------------------

local BatteryNode = class("BatteryNode", cc.node)

function BatteryNode:ctor(imageBattery)
    BatteryNode.super.ctor(self)
    self:setAnchorPoint(imageBattery:getAnchorPoint())
    self:setPosition(imageBattery:getPosition())
    imageBattery:getParent():addChild(self)
    -- imageBattery:setVisible(false)
    self:addChild(imageBattery)
    self._imageBattery = imageBattery

    self:initUI()
end

function BatteryNode:initUI()
    -- local bg = cc.Sprite:create("ui/BatteryNode/bg.png")
    -- bg:setScale(1.5)
    -- self:addChild(bg)
    local progressBar = cc.ProgressTimer:create(cc.Sprite:create("ui/BatteryNode/bar.png"))
    -- progressBar:setScale(1.5)
    progressBar:setType(cc.PROGRESS_TIMER_TYPE_BAR)
    progressBar:setMidpoint(cc.p(0, 0.5))
    progressBar:setBarChangeRate(cc.p(1, 0))
    progressBar:setPercentage(Market_getInstance():getBatteryLevel())
    progressBar:setPosition(cc.p(1, 0))
    self:addChild(progressBar)

    local function updateProgress(dt)
        progressBar:setPercentage(Market_getInstance():getBatteryLevel())
    end
    self:schedule(updateProgress, 5)
end

return BatteryNode

