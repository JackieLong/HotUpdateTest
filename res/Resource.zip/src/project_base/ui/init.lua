-- UI样式配置
base.style = import(".style")

-- 创建主scene
local scene = ptf.director:runWithScene(cc.Scene:create()):keyBackClose( function()
    ptf.ui.viewMgr.back()
end )

-- 连续两次点击退出
local flagExitNode = nil
ptf.ui.viewMgr:setOutOfViewListener( function()
    if not flagExitNode then
        flagExitNode = cc.Node:create():addTo(scene)
        flagExitNode:runAction(ptf.ui.createAni( {
            ptf.conf.ui.TWICE_CLICK_TO_EXIT,
            function()
                flagExitNode:removeFromParent()
                flagExitNode = nil
            end
        } ))
        base.util.toast(base.util.getStr("click_again_exit"))
    else
        ptf.director:endToLua()
    end
end )

-- 登录界面
import(".view.LoginLayer"):create():addTo(ptf.ui.mainScene)
-- base.util.replaceView("LoginView")


