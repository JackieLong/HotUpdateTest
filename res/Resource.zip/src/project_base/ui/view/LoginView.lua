-------------------------------------------------------------------------
-- Desc:           游戏大厅登录界面
-- Author:        Jackie Liu
-- Date:    2016/07/30 22:21:45
-- Desc:       purpose
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
local LoginView = class("LoginView", ptf.ui.baseView)
local TAG = "LoginView"
local ptf, base = ptf, base

function LoginView:ctor()

end

-- 界面生成前的回调，返回需要加载的资源列表
function LoginView:onPreload()

end

-- 界面生成
function LoginView:onGetLayout()
    return base.util.getLayout("login")
end

function LoginView:onCreateView(view)
    self._view = view
    self._viewConf = view.viewConf
    ptf.util.fillScrn(self._viewConf.bg)

    ptf.util.bindListener(self._view, { { "login", handler(self, self._messageReceived) }, { "loginsuccess", handler(self, self._messageReceived) } })

    -- 连接登录服务器
    base.util.loading(base.util.getStr("waiting_login"))
    ptf.net.netMgr:connect(base.conf.LoginSvrAddr, function()
        -- 连接成功
        ptf.log.debug("base.init", "connect login server successfully")
        -- 登录
        base.proxyLogin:login()
    end , nil,
    function()
        -- socket关闭
        base.util.endLoading()
    end ,
    function()
        -- socket错误
        base.util.toast(base.util.getStr("connect_svr_fail"))
    end )
end

function LoginView:_messageReceived(event)
    local name, msg = event.name, event.data
    if name == "login" then
        if msg.isSucc then
            base.util.toast(base.util.getStr("login_succ"))
        else
            base.util.toast(base.util.getStr("login_fail"))
        end
    elseif name == "loginsuccess" then
        -- 得到所有游戏内容
        -- 斗牛随机庄家玩法
--        base.util.replaceView("HallView")
    end
end

function LoginView:getView()
    return self._view
end

-- 界面销毁前的回调,返回需要卸载的资源列表
function LoginView:onDestroy()

end

-- 返回loading界面
function LoginView:onLoadingView()

end

-- view切换动画,in进入的动画，out退出的动画，返回动画的时间
function LoginView:onTransAniIn(view, viewOld)

end

-- view切换动画,in进入的动画，out退出的动画，返回动画的时间
function LoginView:onTransAniOut(view, viewOld)

end

return LoginView