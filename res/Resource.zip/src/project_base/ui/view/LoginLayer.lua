﻿-------------------------------------------------------------------------
-- Desc:
-- Author:      Jackie Liu
-- Date:        2017-05-06 15:29:23
-- Detail:
-- Revisions:
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
local LoginLayer = class("LoginLayer", cc.Layer)
local loginLayout = import("..layout.login")

function LoginLayer:ctor()
    self._ui = ptf.ui.createUI( {
        {
            class = "Sprite",
            name = "bg",
            src = base.res.login.bg,
            center = ptf.contants.ui.Parent,
            parent = self
        }
    } )

    ptf.util.fillScrn(self._ui.bg)

    --    -- 连接登录服务器
    --    base.util.loading(base.util.getStr("waiting_login"))
    --    ptf.net.netMgr:connect(base.conf.LoginSvrAddr, function()
    --        -- 连接成功
    --        ptf.log.debug("base.init", "connect login server successfully")
    --        -- 登录
    --        base.proxyLogin:login()
    --    end , nil,
    --    function()
    --        -- socket关闭
    --        base.util.endLoading()
    --    end ,
    --    function()
    --        -- socket错误
    --        base.util.toast(base.util.getStr("connect_svr_fail"))
    --    end )
end

return LoginLayer