-------------------------------------------------------------------------
-- Desc:           游戏大厅登录界面
-- Author:        Jackie Liu
-- Date:    2016/07/30 22:21:45
-- Desc:       purpose
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
local HallView = class("HallView", ptf.ui.baseView)
local TAG = "HallView"
local ptf, base = ptf, base
local ptfutil, baseutil = ptf.util, base.util

function HallView:ctor()
    self._view = nil
end

-- 界面生成前的回调，返回需要加载的资源列表
function HallView:onPreload()

end

-- 界面生成
function HallView:onGetLayout()
    return baseutil.getLayout("hall")
end

function HallView:onCreateView(view)
    self._view = view
    local viewConf = view.viewConf

    -- 填充背景
    ptfutil.fillScrn(viewConf.bg)
    -- 随机庄家
    viewConf.btnSuiJi:onClick( function(sender)
        -- 启动斗牛模块
        base.util.startGameModule(10001)
    end )
end

function HallView:_messageReceived(event)
    local name, msg = event.name, event.data
    if name == "login" then
    elseif name == "loginsuccess" then
    end
end

function HallView:getView()
    return self._view
end

-- 界面销毁前的回调,返回需要卸载的资源列表
function HallView:onDestroy()

end

-- 返回loading界面
function HallView:onLoadingView()

end

-- view切换动画,in进入的动画，out退出的动画，返回动画的时间
function HallView:onTransAniIn(view, viewOld)
    ptf.util.cascadeOpacity(view)
    ptf.util.cascadeOpacity(viewOld)
    view:setOpacity(0)
    local time = 0.3
    view:runAction(cc.FadeIn:create(time))
    viewOld:runAction(cc.FadeOut:create(time))
    return time
end

-- view切换动画,in进入的动画，out退出的动画，返回动画的时间
function HallView:onTransAniOut(view, viewOld)

end

return HallView