-------------------------------------------------------------------------
-- Title:          文字配置
-- Author:      Jackie Liu
-- Date:         2016/11/13 15:04:25
-- Desc:
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
return
{
    waiting_login = "登录中，请稍候...",
    connect_svr_fail = "连接服务器失败，请重新进入游戏",
    login_succ = "登录成功",
    login_fail = "登录失败",
    click_again_exit = "再按一次，退出游戏",
    waiting = "稍候...",
}