-------------------------------------------------------------------------
-- Title:          基础项目配置
-- Author:      Jackie Liu
-- Date:         2016/11/05 21:29:09
-- Desc:
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
return {
    ROOT_PATH = "project_base",
    -- 登录服地址
    LoginSvrAddr = "45.63.62.96:8777",
    -- 游戏服地址
    GameSvrAddr = "45.63.62.96:8555",
    -- 语言版本
    Language = 1,
    Terminal =
    {
        -- 终端类型: 1 :Android、2: iPhone、
        Type = 1,
        -- 手机型号
        Model = "Mi",
        -- 操作系统版本
        OSVersion = "5.0.0",
        -- 屏幕分辨率
        Screen = { width = 800, height = 600 },
        Info = "node2 16g mem",
    },
    -- 1:socket
    ConnectType = 1,
    -- 不知道啥玩意儿，得问后台
    RegType = 0,
    -- 包名
    PackageName = "com.linlin.gz",
    -- 客户端版本
    Version = "1.0.0b",
    -- 设备信息
    terminalinfo = "node2 16g mem",
    SP = 101,
    OP = 11,
    -- 连接点类型，1234依次对应wifi 2g 3g 4g
    ConnectPoint = 1,
    IMSI = "0000",
    ICCID = "0000",
    IP = "192.168.0.1",
    GAMES =
    {
        [10001] = "zgame_dn.init"
    },
    ui =
    {
        -- toast默认持续时间
        TOAST_DEFAULT_TIME = 2.0,
    }
}