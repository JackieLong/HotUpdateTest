﻿base.conf = import(".config")

base.wholeRes = import(".res")

-- 语言
base.string = import(".strings")

-- 广播事件
base.event = import(".event")

-- 资源目录
base.res = base.wholeRes.res

-- 代码目录
base.src = base.wholeRes.src.project_base
