-------------------------------------------------------------------------
-- Author:      Jackie Liu
-- Date:        2017-03-17 17:09:34
-- Desc:         海南麻将数据，各种内存中缓存的
-- Revisions:         Jackie Liu create this file at 2017-03-17 17:09:34
-- Copyright (c) 2017 Jackie Liu Game
-------------------------------------------------------------------------
base.userData = import(".UserDataController")