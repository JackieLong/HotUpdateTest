local hall_proto = {}

local types = [[
.GamePlayTypeInfo{
	 gameplaytypeid 0 :integer
	 playtype 1 :integer
	 playtypename 2 :string
	 playdata 3:string
	 playparam 4:string
	 sourceurl 5:string
	 desc 6: string
}

.GameInfo{
	 gameinfoid 0:integer
	 gameid 1 :integer
	 gamename 2 :string
	 sourceurl 3:string
	 desc 4: string
	 playtypelist 5 :*GamePlayTypeInfo
}

.GameZoneInfo {
	gamezoneid 0 :integer
	zoneadaptid 1:integer
	name 2:string
	gameid 3:integer
	zonewin 4:integer
	playtype 5:integer
	playtimeout 6:integer
	gametimeout 7:integer
	player 8:integer
	maxplayer 9:integer
	watch 10:integer
	scoremultiple 11:integer
	fortunebase 12:integer
	fortunetax	13:integer
	fortunemin	14:integer
	fortunemax	15:integer
	description 16:string
}
]]


local c2s = [[
heartbeat 1001 {
	response {}
}

reloadgameinfo 1002{
	response {
		gameinfolist 0 : *GameInfo
	}
}

get_gamezoneinfolist 1003{
	request {
		gameid 0:integer
		playtype 1 : integer
	}
	response {
		gamezoneinfolist 0:*GameZoneInfo
	}
}

quickstartgame 1004{
	request {
		gameid 0:integer
		playtype 1:integer
		gamezoneid 2 : integer
	}
	response {
		result 0:integer
		gameid 1:integer
		gamezoneid 2:integer
		tableid 3:string
		playid 4:string
		no 5:integer
	}
}

## ����뿪��Ϸ
leavegame 1005{
	request {
	}
	response {
		result 0:integer
	}
}

## ����˽�˷���
createprivatetable 1006{
	request {
		gameid 0:integer
		playtype 1:integer
		params 2 : string
	}
	response {
		result 0:integer
		gameid 1:integer
		gamezoneid 2:integer
		tableid 3:string
	}
}
## ����˽�˷�
enterprivatetable 1007{
	request {
		gameid 0:integer
		password 1 : integer
	}
	response {
		result 0:integer
		gameid 1:integer
		gamezoneid 2:integer
		tableid 3:string
	}
}
## ��ɢ˽�˷�
dissolveprivatetable 1008{
	request {
		gameid 0:integer
		tableid 1 : string
	}
	response {
		result 0:integer
		gameid 1:integer
		gamezoneid 2:integer
		tableid 3:string
	}
}
## ���ط���
backtable 1009{
	request {
		gameid 0:integer
		tableid 1 : string
	}
	response {
		result 0:integer
		gameid 1:integer
		gamezoneid 2:integer
		tableid 3:string
	}
}
]]

local s2c = [[
	loginsuccess 1001{
		request {
			gameinfolist 0 : *GameInfo
		}
	}
]]


hall_proto.c2s=types .. c2s
hall_proto.s2c=types .. s2c
return hall_proto