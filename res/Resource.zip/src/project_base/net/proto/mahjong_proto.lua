local mahjong_proto = {}

local types = [[
.MJPlayUser{
	no 0:integer
	userid 1:string
	iconid 4:integer
	usertype 2:integer
	nickname 3:string
	gender 5:integer
	status 6:integer
	cardscount 7:integer ##玩家手上所有牌数量，包括门牌
	cards 8:*integer ##玩家手上所有牌，包括门牌
	doorcard 9:integer ## 门牌
	chowcards 10:*integer
	pengcards 11:*integer
	mkongcards 12:*integer
	akongcards 13:*integer ##别家暗杠均为-1
}
.MJTableInfo {
	gamezoneid 0:integer
	tableid 1 :string
	mainuser 2:string
	password 3:string
	params 4:string	##牌桌参数
	tablestatus 5 :integer ## 牌桌状态 0:空闲 1:对局中
	lastplayid 6:string ## 桌子最后对局id
	playusers 7:*MJPlayUser ## 桌子玩家
	cardscount 8:integer ## 总牌数
	scardscount 9:integer ##  剩余牌数
	sindex 10:integer ## 剩余牌索引
	banker 11:string ## 庄家Id
	dice 12:*integer ## 色子
}
.ActionItem {
	actiontype 0:integer ## 1 吃牌 2 碰牌 3 明杠 4 加杠 5 暗杠 6点炮胡 7自摸胡 8 杠上自摸
	actioncards 1 :*integer ## 操作对应的牌
	actiondata 2:integer ## 操作对应数据 胡牌时为番数
}
]]


local c2s = [[
## 玩家准备
mj_ready 3001{
	request {
		tableid 0 :string
	}
	response {
		result 0:integer
	}
}

## 玩家打牌
mj_playcard 3002{
	request {
		tableid 0:string
		playid 1:string
		card 2:integer ##牌
		cardindex 3:integer ##牌索引
	}
	response {
		result 0:integer
	}
}

## 玩家操作
mj_action 3003{
	request {
		tableid 0:string
		playid 1:string
		actiontype 2:integer ##操作类型 0:过 其他对应ActionItem.actiontype
	}
	response {
		result 0:integer
	}
}
]]

local s2c = [[
	## 牌桌信息
	mj_tableinfo 3001{
		request {
			type 0:integer ## 0:其他 1:开局
			tableinfo 1:MJTableInfo
		}
	}
	
	## 玩家进入信息
	mj_userenter 3002{
		request {
			no 0:integer
			userid 1:string
			iconid 2:integer
			usertype 3:integer
			nickname 4:string
			gender 5:integer
		}
	}
	
	## 玩家离开信息
	mj_userleave 3003{
		request {
			leavetype 0:integer ##0:退出，1:正常离开，2:断线/对局中强退后结算后强制离开，3:3局不操作系统踢除，4：超时不操作系统踢除
			no 1:integer
			userid 2:string
		}
	}
	
	## 玩家准备信息
	mj_userready 3004{
		request {
			tableid 0:string
			no 1:integer
			userid 2:string
		}
	}
	
	## 玩家摸牌
	mj_drawcard 3005{
		request {
			tableid 0:string
			playid 1:string
			userid 2:string
			nextplayer 3:string
			cardindex 4:integer ## 牌索引
			card 5:integer ## 牌数据
		}
	}
	
	## 玩家打牌
	mj_userplaycard 3006{
		request {
			tableid 0:string
			playid 1:string
			no 2:integer
			userid 3:string
			card 4:integer ##牌
			cardindex 5:integer ##牌索引
		}
	}
	
	## 可操作通知
	mj_useractionnotify 3007{
		request {
			tableid 0:string
			playid 1:string
			userid 2:string
			actions 3:*ActionItem
		}
	}
	
	## 玩家操作返回动作
	mj_useractionres 3008{
		request {
			tableid 0:string
			playid 1:string
			userid 2:string
			nextplayer 3:string
			action 4:ActionItem
		}
	}
	
	## 游戏结束
	mj_gameover 3009{
		request {
			tableid 0:string
			playid 1:string
		}
	}
	
	
]]

mahjong_proto.c2s = types .. c2s
mahjong_proto.s2c = types .. s2c
return mahjong_proto