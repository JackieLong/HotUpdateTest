-------------------------------------------------------------------------
-- Title:          登录消息代理,握手，登录，重连。
-- Author:      Jackie Liu
-- Date:         2016/10/29 14:34:34
-- Desc:
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
local LoginProxy = class("LoginProxy", ptf.net.proxy)
local TAG = "LoginProxy"

local ptf = ptf

function LoginProxy:ctor()
end

function LoginProxy:filterMsg()
    return {
        "handshake",
        "auth",
        "challenge",
        "login",
    }
end

local private_key_login_userid = nil
local public_key_login_userid = nil
local pwd_login_userid = nil
local userid_login_userid = nil
local session_key_auth = nil
local session_id_auth = nil
local token_login = nil
local pwd_userid_no_exist = nil
function LoginProxy:msgReceived(name, args)
    ptf.log.debug(TAG, "response[%s]", name)
    if name == "handshake" then
        if args.result ~= 0 then
            ptf.log.error(TAG, "handshake failed[%d]", args.result)
            return
        end
        if args.logintype ~= 0 and args.logintype ~= 1 then
            ptf.log.error(TAG, "handshake invalid logintype[%d]", args.logintype)
            return
        end
        local conf = base.conf
        local params = {
            language = conf.Language,
            terminaltype = conf.Terminal.Type,
            authtype = args.logintype,
            regtype = conf.RegType,
            connectiontype = conf.ConnectType,
            packname = conf.PackageName,
            clientversion = conf.Version,
            gamemodel = conf.Terminal.Model,
            osinfo = conf.Terminal.OSVersion,
            terminalwidth = conf.Terminal.Screen.width,
            terminalheight = conf.Terminal.Screen.height,
            terminalinfo = conf.Terminal.info,
            sp = conf.SP,
            op = conf.OP,
            connectpoint = conf.ConnectPoint,
            imsi = conf.IMSI,
            iccid = conf.ICCID,
            ip = conf.IP,
        }
        if args.user_exists then
            -- 用户存在,生成session_key
            session_key_auth = ptf.net.create_client_session_key(
            userid_login_userid,
            pwd_login_userid,
            args.salt,
            private_key_login_userid,
            public_key_login_userid,
            args.server_pub)

            --            ptf.userDefault:setIntegerForKey("session_key_auth", session_key_auth)
            --            ptf.userDefault:flush()

            params.challenge = ptf.net.encrypt(args.challenge, session_key_auth)
        else
            -- 当前用户不存在,创建新用户
            if args.logintype == 1 then
                ptf.log.error("LoginProxy:msgHandleCallback", "login error")
            end
            pwd_userid_no_exist = base.util.genPWD()
            session_key_auth = ptf.net.create_client_session_key(
            args.userid,
            pwd_userid_no_exist,
            args.salt,
            private_key_login_userid,
            public_key_login_userid,
            args.server_pub)
            --            ptf.userDefault:setIntegerForKey("session_key_auth", session_key_auth)
            --            ptf.userDefault:flush()
            params.challenge = ptf.net.encrypt(args.challenge, session_key_auth)
            params.password = ptf.net.encrypt(pwd_userid_no_exist, session_key_auth)
        end
        self:request("auth", params)
    elseif name == "auth" then
        if args.result == 0 then
            session_id_auth = args.session
            self:request("challenge", { session = session_id_auth, challenge = ptf.net.encrypt(args.challenge, session_key_auth) })
        else
            ptf.log.error("LoginProxy:msgHandleCallback", "auth failed[%d]", args.result)
        end
    elseif name == "challenge" then
        -- 连接游戏服
        self._netMgr:connect(base.conf.GameSvrAddr, function()
            -- 连接成功，登录
            token_login = ptf.net.encrypt(args.token, session_key_auth)
            self:request("login", { session = session_id_auth, token = token_login })
        end )
    elseif name == "login" then
        base.util.endLoading()
        if args.result ~= 0 then
            ptf.log.debug(TAG, "login failed[%d]", args.result)
        else
            ptf.log.debug(TAG, "login successfully")
            base.userdata.sessionid, base.userdata.token = session_id_auth, token_login
            -- 保存session_id和login_token
            --            ptf.userDefault:setIntegerForKey("login_token", token_login)
            --            ptf.userDefault:setIntegerForKey("login_session", session_id_auth)
            --            ptf.userDefault:flush()
            -- 登录成功，切换至游戏服务器
            -- 连接服务器
        end
        private_key_login_userid = nil
        public_key_login_userid = nil
        pwd_login_userid = nil
        userid_login_userid = nil
        session_key_auth = nil
        pwd_userid_no_exist = nil
        session_id_auth = nil
        token_login = nil
        return { isSucc = args.result == 0 }
    end
end

function LoginProxy:login()
    base.util.loading(base.util.getStr("waiting_login"))

    local localAccoutData = {
        login_token = ptf.userDefault:getStringForKey("login_token"),
        userid = ptf.userDefault:getStringForKey("userid"),
        pwd = ptf.userDefault:getStringForKey("pwd"),
        login_session = ptf.userDefault:getIntegerForKey("login_session"),
    }


    ptf.log.debug(TAG, "local account data:", localAccoutData)
    if localAccoutData.login_session and localAccoutData.login_session > 0 and localAccoutData.login_token and localAccoutData.login_token ~= "" then
        -- 先尝试session+token登录
        self:loginToken(localAccoutData.login_session, localAccoutData.login_token)
    elseif localAccoutData.userid and localAccoutData.userid ~= "" then
        -- 再尝试账号密码登录
        self:loginUserId(localAccoutData.userid)
        pwd_login_userid = localAccoutData.pwd
        userid_login_userid = localAccoutData.userid
    else
        -- 最后只能注册
        self:register()
    end
end

-- session+token登录
function LoginProxy:loginToken(session, token)
    self:request("login", { session = session, token = token })
end

-- 账号登录
function LoginProxy:loginUserId(userid)
    private_key_login_userid, public_key_login_userid = ptf.net.create_client_key()
    local params = {
        userid = userid,
        client_pub = public_key_login_userid,
        packname = base.conf.PackageName,
        clientversion = base.conf.Version,
        sp = base.conf.SP
    }
    self:request("handshake", params)
end

-- 注册
function LoginProxy:register()
    ptf.log.debug("LoginProxy", "send register request")
    private_key_login_userid, public_key_login_userid = ptf.net.create_client_key()
    local params = {
        logintype = 0,
        userid = "0",
        client_pub = public_key_login_userid,
        packname = base.conf.PackageName,
        clientversion = base.conf.Version,
        sp = base.conf.SP,
    }
    self:request("handshake", params)
end

return LoginProxy