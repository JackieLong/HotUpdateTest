-------------------------------------------------------------------------
-- Title:        大厅消息代理，获取游戏列表，刷新游戏列表,心跳等
-- Author:    Jackie Liu
-- Date:       2016/09/13 15:48:27
-- Desc:
-- Copyright (c) wawagame Entertainment All right reserved.
-------------------------------------------------------------------------
local HallProxy = class("HallProxy", ptf.net.proxy)
local TAG = "HallProxy"

function HallProxy:ctor()
end

function HallProxy:filterMsg()
    return { "loginsuccess", "heartbeat", "reloadgameinfo", "get_gamezoneinfolist" }
end

function HallProxy:msgReceived(name, msg)
    if name == "loginsuccess" then
        -- 登录成功推送游戏列表
        local games = { }
        for k, gameInfo in ipairs(msg.gameinfolist) do
            games[gameInfo.gameid] = gameInfo
        end
        base.userdata.games = games
    elseif name == "heartbeat" then
        -- 心跳
    elseif name == "reloadgameinfo" then

    elseif name == "get_gamezoneinfolist" then
        return msg
    end
end

-- 发送心跳
function HallProxy:heartbeat()
    self:request("heartbeat")
end

-- 重新加载大厅游戏列表
function HallProxy:refreshGameList()
    self:request("reloadgameinfo")
end

-- 获取房间列表 
function HallProxy:requestRoomList(gameid, playType)
    self:request("get_gamezoneinfolist", {
        gameid = gameid,
        playtype = playType
    } )
end

return HallProxy