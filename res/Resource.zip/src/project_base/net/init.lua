-- 加载项目全部协议（大厅，包括麻将、斗牛等子游戏协议）
ptf.net.netMgr:loadProto(base.util.createProto(base.src.net.proto), "allProjectNetProtocol")

-- 登陆
base.proxyLogin = import(".proxy.LoginProxy"):create():start()
-- 大厅
base.proxyHall = import(".proxy.HallProxy"):create():start()