-------------------------------------------------------------------------
-- Title:          基础项目
-- Author:      Jackie Liu
-- Date:         2016/11/05 18:10:40
-- Desc:
--        这是所有其他项目的基础。
--        包含了所有共用的接口，比如工具，资源，协议。
--        还包含了共有的功能。比如共用账号体系。
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
cc.exports.base = {
    conf = nil,
    -- 资源目录table(src + res)
    wholeRes = nil,
    -- 文字
    string = nil,
    -- 事件
    event = nil,
    -- UI资源目录
    res = nil,
    -- src目录
    src = nil,
    -- 缓存数据
    userData = nil,
    -- 登陆消息代理
    proxyLogin = nil,
    -- 大厅消息代理
    proxyHall = nil,
    -- UI样式资源
    style = nil,
    -- 工具方法集合
    util = nil,
}

-- 配置，常量，资源，文字
import(".conf.init")

-- 方法工具模块
import(".util.init")

-- 网络模块
import(".net.init")

-- 缓存数据
import(".data.init")

-- UI显示部分
import(".ui.init")