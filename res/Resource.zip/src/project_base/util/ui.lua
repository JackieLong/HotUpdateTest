-------------------------------------------------------------------------
-- Title:
-- Author:    Jackie Liu
-- Date:       2016/09/13 15:48:27
-- Desc:
-- Copyright (c) wawagame Entertainment All right reserved.
-------------------------------------------------------------------------
local uiUtils = base.util

uiUtils.startGameModule = function(gameid)
    if package.loaded[base.conf.GAMES[gameid]] then
        ptf.log.warn("startGameModule", "cache of [%s] is still existed.it will be wiped out soon", base.conf.GAMES[gameid])
    end
    package.loaded[base.conf.GAMES[gameid]] = nil
    require(base.conf.GAMES[gameid])
end

-- 加载创建视图相关方法
uiUtils.createViewMethods = function(viewMap, layoutMap)
    local viewMap, layoutMap = viewMap, layoutMap
    -- 根据根据布局文件名创建生成布局
    local createView = function(viewClassNameOrClass, ...)
        local classname = viewClassNameOrClass
        if viewClassNameOrClass.class then
            classname = viewMap[viewClassNameOrClass.class.__cname]
        end
        assert(viewMap[classname], "failed to find class named: " .. classname)
        return require(viewMap[classname]):create(...)
    end

    -- 根据布局文件名获取布局table
    local getLayout = function(layoutname)
        local layout = assert(layoutMap[layoutname], "falied to find layout named " .. layoutname)
        return require(layoutMap[layoutname])
    end

    -- inflate出layoutId的布局到view上。layoutId为nil的时候，默认根据view的类名查找
    local inflateLayout = function(layoutname)
        return ptf.ui.createUI(getLayout(layoutname))
    end

    -- 根据ID设置当前界面，ID就是类名
    local addView = function(viewClassNameOrClass, ...)
        ptf.ui.viewMgr:addView(createView(viewClassNameOrClass, ...))
    end

    local replaceView = function(viewClassNameOrClass, ...)
        ptf.ui.viewMgr:replaceView(createView(viewClassNameOrClass, ...))
    end

    local replaceViewEx = function(viewClassNameOrClass, ...)
        ptf.ui.viewMgr:replaceViewEx(createView(viewClassNameOrClass, ...))
    end

    return createView, getLayout, inflateLayout, addView, replaceView, replaceViewEx
end

-- toast
local toastInstance = nil
uiUtils.toast = function(str, time)
    ptf.log.debug("toast", str)
    if toastInstance then
        toastInstance:removeFromParent()
        toastInstance = nil
    end
    toastInstance = ptf.ui.createUI( {
        class = "Scale9Sprite",
        src = base.res.bg_input,
        cascadeOpacity = true,
        cascadeColor = true,
        parent = ptf.ui.mainScene,
        order = 1,
    } )
    local cntnt = ptf.ui.createUI( {
        class = "Label",
        sysFnt = "Arial",
        parent = toastInstance,
        fntSize = 50,
        txt = str,
        cascadeOpacity = true,
        cascadeColor = true,
    } )
    --    dump(toastInstance:getContentSize())
    toastInstance:setPreferredSize(cc.size(math.max(toastInstance:width(), cntnt:width() + 40), 80))
    cntnt:center(toastInstance)
    toastInstance:centerX(ptf.ui.mainScene):offsetY(200):scale(0.0):runAction(ptf.ui.createAni(
    {
        cc.EaseBackOut:create(cc.ScaleTo:create(0.20,1.0)),
        time or base.conf.ui.TOAST_DEFAULT_TIME,
        cc.FadeOut:create(0.4),
        function()
            toastInstance:removeFromParent()
            toastInstance = nil
        end
    } ))
    return toastInstance
end

-- 加载loading界面
local loadingLayerInstance = nil
uiUtils.loading = function(str)
    if not loadingLayerInstance then
        loadingLayerInstance = display.newLayer( { r = 0, g = 0, b = 0 }):addTo(ptf.ui.mainScene)
        loadingLayerInstance:swallowTouch()
        ptf.ui.createUI( { class = "Label", _style = base.style.txt.loading, txt = str }):addTo(loadingLayerInstance):center(loadingLayerInstance)
        loadingLayerInstance:setOpacity(0):runAction(cc.FadeTo:create(0.1, 100))
        --        ptf.util.cascadeOpacity(loadingLayerInstance)
    end
end

-- 取消laoding界面
uiUtils.endLoading = function()
    if loadingLayerInstance then
        ptf.util.safeExeSeq(loadingLayerInstance, cc.FadeOut:create(0.1), function()
            loadingLayerInstance:removeFromParent()
            loadingLayerInstance = nil
        end )
    end
end