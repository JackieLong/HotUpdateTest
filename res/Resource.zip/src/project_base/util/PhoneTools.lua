local PhoneTools = class("PhoneTools")

function PhoneTools:ctor()
	self.targetPlatform = cc.Application:getInstance():getTargetPlatform()
	self.callbackList = {}
	self.loginArg = ""
	self.loginCallback = nil
	self.shareCallback = nil
end

function PhoneTools:refreshToken(refresh_token, openid)
	local xhr = cc.XMLHttpRequest:new()
	xhr.responseType = cc.XMLHTTPREQUEST_RESPONSE_JSON
	local url = "https://api.weixin.qq.com/sns/oauth2/refresh_token?appid=" .. WeiChat_AppID .. "&grant_type=refresh_token&refresh_token=" .. refresh_token
	xhr:open("GET", url)
	local function onResponse()
		if xhr.readyState == 4 and (xhr.status >= 200 and xhr.status < 207) then
			local str = string.gsub(xhr.response, "\\", "")
			local t = json.decode(str)
			if(t.errcode) then
				cc.UserDefault:getInstance():setStringForKey("weichat_refresh_token", "")
				cc.UserDefault:getInstance():setStringForKey("weichat_openid", "")
				self:requestLogin(self.loginArg, self.loginCallback)
			else
				cc.UserDefault:getInstance():setStringForKey("weichat_refresh_token", t.refresh_token)
				cc.UserDefault:getInstance():setStringForKey("weichat_openid", t.openid)
				self:getWeiChatUserInfo(t.access_token, t.openid)
			end
		else
			printInfo("xhr.readyState is:", xhr.readyState, "xhr.status is: ",xhr.status)
			createTips("连接网络失败")
		end
	end
	xhr:registerScriptHandler(onResponse)
	xhr:send()
end

function PhoneTools:getWeiChatUserInfo(access_token, openid)
	local xhr = cc.XMLHttpRequest:new()
	xhr.responseType = cc.XMLHTTPREQUEST_RESPONSE_JSON
	local url = "https://api.weixin.qq.com/sns/userinfo?access_token=" .. access_token .. "&openid=" .. openid
	xhr:open("GET", url)
	local function onResponse()
		if xhr.readyState == 4 and (xhr.status >= 200 and xhr.status < 207) then
			local str = string.gsub(xhr.response, "\\", "")
			local t = json.decode(str)
			if(t.errcode) then
				cc.UserDefault:getInstance():setStringForKey("weichat_refresh_token", "")
				cc.UserDefault:getInstance():setStringForKey("weichat_openid", "")
				self:requestLogin(self.loginArg, self.loginCallback)
			else
				if(self.loginCallback) then
					self.loginCallback(t)
					self.loginCallback = nil
				end
			end
		else
			printInfo("xhr.readyState is:", xhr.readyState, "xhr.status is: ",xhr.status)
			createTips("连接网络失败")
		end
	end
	xhr:registerScriptHandler(onResponse)
	xhr:send()
end

function PhoneTools.responseLogin(args)
	local self = PhoneTools_getInstance()
	local info = args
	--IOS 传过来为table
	if type(args) ~= "table" then
		 info = json.decode(args)
	end
	self:refreshToken(info.refresh_token, info.openid)
end

function PhoneTools.responseShare(args)
	local self = PhoneTools_getInstance()
	local info = json.decode(args)
	if(self.shareCallback) then
		self.shareCallback(info)
		self.shareCallback = nil
	end
end

function PhoneTools.responseChannel(args)
	local self = PhoneTools_getInstance()
	local t = json.decode(args)
	local callbackAddres, arg = t.fun_key, t.arg_key
	if(self.callbackList[callbackAddres]) then
		self.callbackList[callbackAddres](arg)
		self.callbackList[callbackAddres] = nil
	end
end

-- 登陆
function PhoneTools:requestLogin(arg, callback)
	self.loginArg = arg
	self.loginCallback = callback
	local refresh_token = cc.UserDefault:getInstance():getStringForKey("weichat_refresh_token", "")
	local openid = cc.UserDefault:getInstance():getStringForKey("weichat_openid", "")
	if("" ~= refresh_token and "" ~= openid) then
		self:refreshToken(refresh_token, openid)
		return
	end
	if (cc.PLATFORM_OS_ANDROID == self.targetPlatform) then
        local args = {arg, PhoneTools.responseLogin}
        local sigs = "(Ljava/lang/String;I)V"
        local luaj = require "cocos.cocos2d.luaj"
        local className = "org/bly/blyPhoneTools/export/GameChannel"
        local ok, ret = luaj.callStaticMethod(className, "requestLogin", args, sigs)
        if not ok then
			print("luaj error:", ret)
		else
			print("The ret is:", ret)
		end
		return ret
    elseif (cc.PLATFORM_OS_IPHONE == self.targetPlatform) or (cc.PLATFORM_OS_IPAD == self.targetPlatform) or (cc.PLATFORM_OS_MAC == self.targetPlatform) then

	 	local args = {};
		
		if callback then args["callBackID"] = PhoneTools.responseLogin end
		local paramTab = json.decode(arg);
		for k,v in pairs(paramTab) do
			args[k] = v;
		end

		local  count = 0;
		for k,v in pairs(args) do  
    		count = count + 1 --clac the count of the table(t_)  
		end  

		if count == 0 then args = nil end

		local luaoc = require "cocos.cocos2d.luaoc"
		local className = "NativePerform"
		local ok, ret  = luaoc.callStaticMethod(className,"wechatLogin",args)
		if ret then
			print("The ret is:", ret)
		end

		return ret
	end
	return ""
end

-- 分享
function PhoneTools:requestShare(shareInfo, callback)
	if(not shareInfo.bOnlyPic) then
		shareInfo.bOnlyPic = false
	end
	self.shareCallback = callback
	local function share(arg)
		if (cc.PLATFORM_OS_ANDROID == self.targetPlatform) then
	        local args = {arg, PhoneTools.responseShare}
	        local sigs = "(Ljava/lang/String;I)V"
	        local luaj = require "cocos.cocos2d.luaj"
	        local className = "org/bly/blyPhoneTools/export/GameChannel"
	        local ok, ret = luaj.callStaticMethod(className, "requestShare", args, sigs)
	        if not ok then
				print("luaj error:", ret)
			else
				print("The ret is:", ret)
			end
			return ret
	    elseif (cc.PLATFORM_OS_IPHONE == self.targetPlatform) or (cc.PLATFORM_OS_IPAD == self.targetPlatform) or (cc.PLATFORM_OS_MAC == self.targetPlatform) then
			local args = {};
			
			if callback then args["callBackID"] = callback end
			local paramTab = json.decode(arg);
			for k,v in pairs(paramTab) do
				args[k] = v;
			end

			local  count = 0;
			for k,v in pairs(args) do  
	    		count = count + 1 --clac the count of the table(t_)  
			end  

			if count == 0 then args = nil end

			local luaoc = require "cocos.cocos2d.luaoc"
			local className = "NativePerform"
			local ok, ret  = luaoc.callStaticMethod(className,"requestShare",args)
			if ret then
				print("The ret is:", ret)
			end

			return ret
		end
	 end

	if(not shareInfo.filePath or "" == shareInfo.filePath) then
		local function afterCaptured(succeed, outputFile)  
			if succeed then
				shareInfo.filePath = outputFile
				share(json.encode(shareInfo))
			else
				shareInfo.filePath = nil
				share(json.encode(shareInfo))
			end
		end
		cc.utils:captureScreen(afterCaptured, "CaptureScreenShare.png")
	else
		share(json.encode(shareInfo))
	end


	return ""
end

function PhoneTools:requestChannel(module, method, arg, callback)

	if (cc.PLATFORM_OS_ANDROID == self.targetPlatform) then

		arg = arg or ""
		local callbackAddres = ""
		if(callback) then
			callbackAddres = tostring(callback)
			self.callbackList[callbackAddres] = callback
		end

        local args = {module, method, arg, callbackAddres, PhoneTools.responseChannel}
        local sigs = "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Ljava/lang/String;"
        local luaj = require "cocos.cocos2d.luaj"
        local className = "org/bly/blyPhoneTools/export/GameChannel"
        local ok, ret = luaj.callStaticMethod(className, "requestChannel", args, sigs)
        if not ok then
			print("luaj error:", ret)
		else
			print("The ret is:", ret)
		end
		return ret
    elseif (cc.PLATFORM_OS_IPHONE == self.targetPlatform) or (cc.PLATFORM_OS_IPAD == self.targetPlatform) or (cc.PLATFORM_OS_MAC == self.targetPlatform) then
		local args = {};

		if callback then args["callBackID"] = callback end
		
		local paramTab = {};
		if arg then
			if type(arg) == "string" then
				paramTab = json.decode(arg)
			elseif type(arg) == "table" then
				paramTab = arg;
			end
		end

		for k,v in pairs(paramTab) do
			args[k] = v;
		end

		if tools.TableLen(args) == 0 then args = nil end

		local luaoc = require "cocos.cocos2d.luaoc"
		local className = "NativePerform"
		local ok, ret  = luaoc.callStaticMethod(className,method,args)

		return ret
	end
	return ""
end

--获取电量
function PhoneTools:getBatteryLevel()
	local batteryLevel = 50
	if (cc.PLATFORM_OS_ANDROID == self.targetPlatform) then
        local args = {}
        local sigs = "()I"
        local luaj = require "cocos.cocos2d.luaj"
        local className = "org/bly/blyPhoneTools/export/GameChannel"
        local ok, ret = luaj.callStaticMethod(className, "getBatteryLevel", args, sigs)
        if not ok then
			print("luaj error:", ret)
		else
			print("The ret is:", ret)
			batteryLevel = ret
		end
		return batteryLevel
    elseif (cc.PLATFORM_OS_IPHONE == self.targetPlatform) or (cc.PLATFORM_OS_IPAD == self.targetPlatform) or (cc.PLATFORM_OS_MAC == self.targetPlatform) then
		
		local luaoc = require "cocos.cocos2d.luaoc"
		local className = "NativePerform"
		local ok, ret  = luaoc.callStaticMethod(className,"getBatteryLevel",nil)
		if not ok then
			print("uaj error:", ret)
		else
			print("The ret is:", ret)
		end

		 batteryLevel = ret
	end
    return batteryLevel
end

--获取网络强度
function PhoneTools:getNetLevel()
	local netInfo = {type = 1, level = 4}
	if (cc.PLATFORM_OS_ANDROID == self.targetPlatform) then
        local args = {}
        local sigs = "()Ljava/lang/String;"
        local luaj = require "cocos.cocos2d.luaj"
        local className = "org/bly/blyPhoneTools/export/GameChannel"
        local ok, ret = luaj.callStaticMethod(className, "getNetLevel", args, sigs)
        if not ok then
			print("luaj error:", ret)
		else
			print("The ret is:", ret)
			--[[
				json.put("type", 1);// 1wifi  0siganl
				json.put("level", getWifiLevel());
			]]
			return json.decode(ret)
		end
    elseif (cc.PLATFORM_OS_IPHONE == self.targetPlatform) or (cc.PLATFORM_OS_IPAD == self.targetPlatform) or (cc.PLATFORM_OS_MAC == self.targetPlatform) then
		local luaoc = require "cocos.cocos2d.luaoc"
		local className = "NativePerform"
		local ok, ret  = luaoc.callStaticMethod(className,"getNetLevel",nil)
		if not ok then
			print("uaj error:", ret)
		else
			print("The ret is:", ret)
		end
		return ret
	end
    return netInfo
end

local instance = nil
-- 获取单例
function PhoneTools_getInstance()
	if(nil == instance) then
		instance = PhoneTools:create()
	end
	return instance
end

