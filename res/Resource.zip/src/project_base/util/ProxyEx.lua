-------------------------------------------------------------------------
-- Title:
-- Author:      Jackie Liu
-- Date:         2016/11/16 23:55:25
-- Desc:
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
local ProxyEx = ptf.net.proxy
local base = base

local oldRequest = ProxyEx.request
function ProxyEx:request(name, params)
    base.util.loading(base.util.getStr("waiting"))
    return oldRequest(self, name, params)
end

local oldReceive = ProxyEx._msgReceived
function ProxyEx:_msgReceived(name, msg)
    base.util.endLoading()
    if msg.result and msg.result ~= 0 then
        base.util.toast(string.format("%s failed,error code[%d]", name, args.result))
    else
        oldReceive(self, name, msg)
    end
end
