-------------------------------------------------------------------------
-- Title:          基础项目工具类，为其他所有项目共用。
-- Author:      Jackie Liu
-- Date:         2016/11/05 18:01:55
-- Desc:
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
local util = { }

base.util = util

local import = import

import(".ProxyEx")

-- 语言版本
local strings = base.string
util.getStr = function(stringname)
    return strings[stringname]
end

-- 生成项目的消息协议
-- 每个proto的tag都不相同。
local adjustProtoStr = function(protoStr)
    local i = 0
    local function func(str)
        i = i + 1
        local str1, str2 = string.match(str, "(%s*%w+%s+)%d(%s*%{)")
        return str1 .. i .. str2
    end
    return string.gsub(protoStr, "%s*%w+%s+%d%s*%{", func)
end
util.createProto = function(protoTable)
    local c2s, s2c = { }, { }
    for k, v in pairs(protoTable) do
        local tmpProto = require(v)
        if tmpProto.c2s then
            c2s[#c2s + 1] = tmpProto.c2s
        end
        if tmpProto.s2c then
            s2c[#s2c + 1] = tmpProto.s2c
        end
    end
    return { c2s = table.concat(c2s, ""), s2c = table.concat(s2c, "") }
end

util.startProxy = function(proxyDir)
    local proxyTable = { }
    for k, v in pairs(proxyDir) do
        proxyTable[string.match(v, "%.(%w+)$")] = require(v):create():start()
        ptf.log.debug("base.util.init", "start proxy[%s] successfully.", v)
    end
    return proxyTable
end

util.stopProxy = function(proxyTable)
    for k, v in pairs(proxyTable) do
        if v then
            ptf.log.debug("base.util.init", "stop proxy[%s] successfully.", v.__cname)
            v:stop()
        end
    end
end

-- 随机生成一个合法密码
util.genPWD = function()
    return "123abcDef$%^"
end

import(".ui")

-- 创建界面的方法
util.createView, util.getLayout, util.inflateLayout, util.addView, util.replaceView, util.replaceViewEx =
util.createViewMethods(base.src.ui.view, base.src.ui.layout)