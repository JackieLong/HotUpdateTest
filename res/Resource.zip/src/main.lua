-- avoid memory leak
collectgarbage("collect")
collectgarbage("setpause", 100)
collectgarbage("setstepmul", 5000)

require "config"

require "cocos.init"

-- 基础框架
require "jackie.init"

local function main()

    ptf.ui.mainScene = ptf.director:getRunningScene()
    --    -- 公共基础项目，登陆模块
    --    require("project_base.init")

    require("bettyskin.init")

end

xpcall(main, ptf.__G__TRACKBACK__)
