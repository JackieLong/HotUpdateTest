--region *.lua
--Date
--此文件由[BabeLua]插件自动生成

local LobbyLogic = class("LobbyLogic")

function LobbyLogic:ctor()
    self.userId = 0
    self.nickname = ""
    self.fangka = 0
    self.headurl  = ""
end

--平台消息解析
function LobbyLogic:onNetMsgUserInfo( msgTable )

end

cc.exports.LobbyLogic = cc.exports.LobbyLogic or LobbyLogic:create()
return cc.exports.LobbyLogic

--endregion
