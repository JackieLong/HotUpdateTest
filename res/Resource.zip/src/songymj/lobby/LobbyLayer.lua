--region *.lua
--Date
--此文件由[BabeLua]插件自动生成

local LobbyLayer = class("LobbyLayer", cc.Layer)

LobbyLayer.csb = "LobbyScene.csb"
local _widget = nil

function LobbyLayer:ctor()
    self:init()
end

function LobbyLayer:init()
    _widget = cc.CSLoader:createNode(LobbyLayer.csb)
    self:addChild(_widget)

    local Panel_Main = _widget:getChildByName("Panel_Main")
    local Panel_Top = Panel_Main:getChildByName("Panel_Top")
    --设置
    local button = Panel_Top:getChildByName("Button_Setting")
    if button then
        button:addClickEventListener(function()
            --
        end)
    end

    --消息
    button = Panel_Top:getChildByName("Button_Msg")
    if button then
        button:addClickEventListener(function()
            --
        end)
    end

    --战绩
    button = Panel_Top:getChildByName("Button_Zhanji")
    if button then
        button:addClickEventListener(function()
            --
        end)
    end

    --分享
    button = Panel_Top:getChildByName("Button_Share")
    if button then
        button:addClickEventListener(function()
            --
        end)
    end

    --帮助
    button = Panel_Top:getChildByName("Button_Help")
    if button then
        button:addClickEventListener(function()
            --
        end)
    end

    --创建房间
    button = Panel_Main:getChildByName("Button_CreateRoom")
    if button then
        button:addClickEventListener(function()
            --
        end)
    end

    --加入房间
    button = Panel_Main:getChildByName("Button_JoinRoom")
    if button then
        button:addClickEventListener(function()
            --
        end)
    end

    --打开代理设置界面
    button = Panel_Main:getChildByName("Button_Gift")
    if button then
        button:addClickEventListener(function()
            --
        end)
    end
end

function LobbyLayer:updateUserInfo()
    local Panel_Top = _widget:getChildByName("Panel_Main"):getChildByName("Panel_Top")
    --头像
    local Image_Head = Panel_Top:getChildByName("Image_Head")

    --昵称
    local Text_Name =  Panel_Top:getChildByName("Panel_Name"):getChildByName("Text_Name")
    if Text_Name then
        Text_Name:setString(LobbyLogic.nickname)
    end

     --ID
    local Text_ID =  Panel_Top:getChildByName("Panel_ID"):getChildByName("Text_ID")
    if Text_ID then
        Text_ID:setString(tostring(LobbyLogic.userId))
    end

     --房卡数量
    local Text_Num =  Panel_Top:getChildByName("Panel_Fangka"):getChildByName("Text_Num")
    if Text_Num then
        Text_Num:setString(tostring(LobbyLogic.fangka))
    end
end

return LobbyLayer

--endregion
