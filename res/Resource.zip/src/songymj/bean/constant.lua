﻿-- 牌状态
PaiStatus = cmx.util.createEnum( {
    "LAY_UP",-- 摊牌，正面朝上
    "LAY_DOWN",-- 摊牌，正面朝下
    "STAND"-- 牌立着，这个没有正面朝向的问题
} )

-- 方位：上下左右
SeatPos = cmx.util.createEnum( {
    "ME = 1",
    "RIGHT",
    "UP",
    "LEFT"
} )

-- PaiSize = cmx.util.createEnum( {
--    "PAISIZE_1 = 1",
--    "PAISIZE_2",
--    "PAISIZE_3",
--    "PAISIZE_4",
-- } )

PaiValue = cmx.util.createEnum( {
    "WAN_1 = 11",
    "WAN_2",
    "WAN_3",
    "WAN_4",
    "WAN_5",
    "WAN_6",
    "WAN_7",
    "WAN_8",
    "WAN_9",
    "TONG_1 = 21",
    "TONG_2",
    "TONG_3",
    "TONG_4",
    "TONG_5",
    "TONG_6",
    "TONG_7",
    "TONG_8",
    "TONG_9",
    "TIAO_1 = 31",
    "TIAO_2",
    "TIAO_3",
    "TIAO_4",
    "TIAO_5",
    "TIAO_6",
    "TIAO_7",
    "TIAO_8",
    "TIAO_9",
} )