﻿-------------------------------------------------------------------------
-- Desc:
-- Author:      Jackie Liu
-- Date:        2017-05-25 10:23:43
-- Detail:
--        测试代码
--        local mjPlist = "Image/mj.plist"
--        local mjPng = "Image/mj.png"
--        display.loadSpriteFrames(mjPlist, mjPng)

--        local Pai = require("mjguiyang.ui.test.Pai")
--        local tmpNode = nil
--        local status = { "stand", "laydown", "layup" }
--        local start = cc.p(60, SET_SCREEN_HEIGHT - 80)
--        local tmpI = 0
--        for _, pos in pairs(SeatPos) do
--            for _, func in pairs(status) do
--                for k, value in pairs(PaiValue) do
--                    tmpNode = Pai:create(value, pos)
--                    tmpNode[func](tmpNode):addTo(self):pos(start):offset(tmpI % 15 * 60, - math.floor(tmpI / 15) * 60)
--                    tmpI = tmpI + 1
--                end
--            end
--        end
-- Revisions:
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
local Pai = class("Pai", cc.Sprite)

import(".constant")

local string = string
local assert = assert
local display = display
local tonumber = tonumber

local PaiSrcConf = nil
local SrcSizeConf = nil

function Pai:ctor(paiValue, seatPos)
    -- 牌值
    self._value = paiValue
    -- 牌位置：上下左右
    self._seatPos = seatPos
    -- 牌Status，正放着的，盖着的。
    self._status = nil
    -- 牌值节点
    self._valueNode = nil

    self:setScale(1 / 1.5)
end

function Pai:setSide(seatPos)
    self._seatPos = seatPos
    return self
end

function Pai:setValue(value)
    self._value = value
    return self
end

-- 牌立起
function Pai:stand()
    assert(self._seatPos, "null seatPos")
    if PaiStatus.STAND ~= self._status then
        self._status = PaiStatus.STAND
        self:initWithSpriteFrameName(Pai.getBgSrcConf(self._seatPos).stand)
        if SeatPos.ME == self._seatPos then
            if not self._valueNode and self._value then
                self._valueNode = self:_createValueNode():addTo(self)
                self:_adaptValueNodePos()
            else
                if self._valueNode then
                    self._valueNode:setVisible(true)
                end
            end
        else
            if self._valueNode then
                self._valueNode:setVisible(false)
            end
        end
    end
    return self
end

-- 躺着，正面朝上
function Pai:layup()
    assert(self._seatPos, "null seatPos")
    if PaiStatus.LAY_UP ~= self._status then
        self._status = PaiStatus.LAY_UP
        self:initWithSpriteFrameName(Pai.getBgSrcConf(self._seatPos).lay_up)
        if not self._valueNode and self._value then
            self._valueNode = self:_createValueNode():addTo(self)
            self:_adaptValueNodePos()
        else
            if self._valueNode then
                self._valueNode:setVisible(true)
            end
        end
    end
    return self
end

-- 牌躺着，正面朝下。
function Pai:laydown()
    if PaiStatus.LAY_DOWN ~= self._status then
        self._status = PaiStatus.LAY_DOWN
        self:initWithSpriteFrameName(Pai.getBgSrcConf(self._seatPos).lay_down)
        if self._valueNode then
            self._valueNode:setVisible(true)
        end
    end
    return self
end

-- 创建牌值节点
function Pai:_createValueNode()
    local src = Pai.getValueSrc(self._value, self._seatPos, self._status)
    return display.newSprite("#" .. src)
end

-- 调节valuenode的位置到中间
local PaiValueNodePosConf =
{
    [SeatPos.ME] =
    {
        lay =
        {
            anchor = cc.p(0.0,0.0),
            pos = cc.p(3 * 1.5,13 * 1.5),
        },
        stand =
        {
            anchor = cc.p(0.0,0.0),
            pos = cc.p(7,7),
        }
    },
    [SeatPos.RIGHT] =
    {
        lay =
        {
            pos = cc.p(21 * 1.5,22 * 1.5),
            rotate = 180.0,
        },
    },
    [SeatPos.LEFT] =
    {
        lay =
        {
            anchor = cc.p(0.0,0.0),
            pos = cc.p(8 * 1.5,12 * 1.5),
        },
    },
    [SeatPos.UP] =
    {
        lay =
        {
            rotate = 180,
            pos = cc.p(16 * 1.5,29 * 1.5),
        },
    }
}
function Pai:_adaptValueNodePos()
    if self._valueNode then
        local conf = nil
        if self._status == PaiStatus.LAY_DOWN or self._status == PaiStatus.LAY_UP then
            conf = PaiValueNodePosConf[self._seatPos].lay
        elseif self._status == PaiStatus.STAND then
            conf = PaiValueNodePosConf[self._seatPos].stand
        end

        if conf.anchor then
            self._valueNode:setAnchorPoint(conf.anchor)
        end
        if conf.pos then
            self._valueNode:setPosition(conf.pos)
        end
        if conf.rotate then
            self._valueNode:setRotation(conf.rotate)
        end
    end
end

function Pai:copy()
    local ret = Pai:create(self.paiValue, self.seatPos)
    if self._status then
        if self._status == PaiStatus.LAY_UP then
            ret:layUp()
        elseif self._status == PaiStatus.LAY_DOWN then
            ret:layDown()
        elseif self._status == PaiStatus.STAND then
            ret:stand()
        end
    end
    return ret
end

PaiSrcConf =
{
    [PaiSize._1] =
    {
        [PaiValue.WAN_1] = mjguiyang.res.UI_GAME_PAI_SIZE1_WAN1,
        [PaiValue.WAN_2] = mjguiyang.res.UI_GAME_PAI_SIZE1_WAN2,
        [PaiValue.WAN_3] = mjguiyang.res.UI_GAME_PAI_SIZE1_WAN3,
        [PaiValue.WAN_4] = mjguiyang.res.UI_GAME_PAI_SIZE1_WAN4,
        [PaiValue.WAN_5] = mjguiyang.res.UI_GAME_PAI_SIZE1_WAN5,
        [PaiValue.WAN_6] = mjguiyang.res.UI_GAME_PAI_SIZE1_WAN6,
        [PaiValue.WAN_7] = mjguiyang.res.UI_GAME_PAI_SIZE1_WAN7,
        [PaiValue.WAN_8] = mjguiyang.res.UI_GAME_PAI_SIZE1_WAN8,
        [PaiValue.WAN_9] = mjguiyang.res.UI_GAME_PAI_SIZE1_WAN9,
        [PaiValue.TONG_1] = mjguiyang.res.UI_GAME_PAI_SIZE1_TONG1,
        [PaiValue.TONG_2] = mjguiyang.res.UI_GAME_PAI_SIZE1_TONG2,
        [PaiValue.TONG_3] = mjguiyang.res.UI_GAME_PAI_SIZE1_TONG3,
        [PaiValue.TONG_4] = mjguiyang.res.UI_GAME_PAI_SIZE1_TONG4,
        [PaiValue.TONG_5] = mjguiyang.res.UI_GAME_PAI_SIZE1_TONG5,
        [PaiValue.TONG_6] = mjguiyang.res.UI_GAME_PAI_SIZE1_TONG6,
        [PaiValue.TONG_7] = mjguiyang.res.UI_GAME_PAI_SIZE1_TONG7,
        [PaiValue.TONG_8] = mjguiyang.res.UI_GAME_PAI_SIZE1_TONG8,
        [PaiValue.TONG_9] = mjguiyang.res.UI_GAME_PAI_SIZE1_TONG9,
        [PaiValue.TIAO_1] = mjguiyang.res.UI_GAME_PAI_SIZE1_TIAO1,
        [PaiValue.TIAO_2] = mjguiyang.res.UI_GAME_PAI_SIZE1_TIAO2,
        [PaiValue.TIAO_3] = mjguiyang.res.UI_GAME_PAI_SIZE1_TIAO3,
        [PaiValue.TIAO_4] = mjguiyang.res.UI_GAME_PAI_SIZE1_TIAO4,
        [PaiValue.TIAO_5] = mjguiyang.res.UI_GAME_PAI_SIZE1_TIAO5,
        [PaiValue.TIAO_6] = mjguiyang.res.UI_GAME_PAI_SIZE1_TIAO6,
        [PaiValue.TIAO_7] = mjguiyang.res.UI_GAME_PAI_SIZE1_TIAO7,
        [PaiValue.TIAO_8] = mjguiyang.res.UI_GAME_PAI_SIZE1_TIAO8,
        [PaiValue.TIAO_9] = mjguiyang.res.UI_GAME_PAI_SIZE1_TIAO9,
    },
    [PaiSize._2] =
    {
        [PaiValue.WAN_1] = mjguiyang.res.UI_GAME_PAI_SIZE2_WAN1,
        [PaiValue.WAN_2] = mjguiyang.res.UI_GAME_PAI_SIZE2_WAN2,
        [PaiValue.WAN_3] = mjguiyang.res.UI_GAME_PAI_SIZE2_WAN3,
        [PaiValue.WAN_4] = mjguiyang.res.UI_GAME_PAI_SIZE2_WAN4,
        [PaiValue.WAN_5] = mjguiyang.res.UI_GAME_PAI_SIZE2_WAN5,
        [PaiValue.WAN_6] = mjguiyang.res.UI_GAME_PAI_SIZE2_WAN6,
        [PaiValue.WAN_7] = mjguiyang.res.UI_GAME_PAI_SIZE2_WAN7,
        [PaiValue.WAN_8] = mjguiyang.res.UI_GAME_PAI_SIZE2_WAN8,
        [PaiValue.WAN_9] = mjguiyang.res.UI_GAME_PAI_SIZE2_WAN9,
        [PaiValue.TONG_1] = mjguiyang.res.UI_GAME_PAI_SIZE2_TONG1,
        [PaiValue.TONG_2] = mjguiyang.res.UI_GAME_PAI_SIZE2_TONG2,
        [PaiValue.TONG_3] = mjguiyang.res.UI_GAME_PAI_SIZE2_TONG3,
        [PaiValue.TONG_4] = mjguiyang.res.UI_GAME_PAI_SIZE2_TONG4,
        [PaiValue.TONG_5] = mjguiyang.res.UI_GAME_PAI_SIZE2_TONG5,
        [PaiValue.TONG_6] = mjguiyang.res.UI_GAME_PAI_SIZE2_TONG6,
        [PaiValue.TONG_7] = mjguiyang.res.UI_GAME_PAI_SIZE2_TONG7,
        [PaiValue.TONG_8] = mjguiyang.res.UI_GAME_PAI_SIZE2_TONG8,
        [PaiValue.TONG_9] = mjguiyang.res.UI_GAME_PAI_SIZE2_TONG9,
        [PaiValue.TIAO_1] = mjguiyang.res.UI_GAME_PAI_SIZE2_TIAO1,
        [PaiValue.TIAO_2] = mjguiyang.res.UI_GAME_PAI_SIZE2_TIAO2,
        [PaiValue.TIAO_3] = mjguiyang.res.UI_GAME_PAI_SIZE2_TIAO3,
        [PaiValue.TIAO_4] = mjguiyang.res.UI_GAME_PAI_SIZE2_TIAO4,
        [PaiValue.TIAO_5] = mjguiyang.res.UI_GAME_PAI_SIZE2_TIAO5,
        [PaiValue.TIAO_6] = mjguiyang.res.UI_GAME_PAI_SIZE2_TIAO6,
        [PaiValue.TIAO_7] = mjguiyang.res.UI_GAME_PAI_SIZE2_TIAO7,
        [PaiValue.TIAO_8] = mjguiyang.res.UI_GAME_PAI_SIZE2_TIAO8,
        [PaiValue.TIAO_9] = mjguiyang.res.UI_GAME_PAI_SIZE2_TIAO9,
    },
    [PaiSize._3] =
    {
        [PaiValue.WAN_1] = mjguiyang.res.UI_GAME_PAI_SIZE3_WAN1,
        [PaiValue.WAN_2] = mjguiyang.res.UI_GAME_PAI_SIZE3_WAN2,
        [PaiValue.WAN_3] = mjguiyang.res.UI_GAME_PAI_SIZE3_WAN3,
        [PaiValue.WAN_4] = mjguiyang.res.UI_GAME_PAI_SIZE3_WAN4,
        [PaiValue.WAN_5] = mjguiyang.res.UI_GAME_PAI_SIZE3_WAN5,
        [PaiValue.WAN_6] = mjguiyang.res.UI_GAME_PAI_SIZE3_WAN6,
        [PaiValue.WAN_7] = mjguiyang.res.UI_GAME_PAI_SIZE3_WAN7,
        [PaiValue.WAN_8] = mjguiyang.res.UI_GAME_PAI_SIZE3_WAN8,
        [PaiValue.WAN_9] = mjguiyang.res.UI_GAME_PAI_SIZE3_WAN9,
        [PaiValue.TONG_1] = mjguiyang.res.UI_GAME_PAI_SIZE3_TONG1,
        [PaiValue.TONG_2] = mjguiyang.res.UI_GAME_PAI_SIZE3_TONG2,
        [PaiValue.TONG_3] = mjguiyang.res.UI_GAME_PAI_SIZE3_TONG3,
        [PaiValue.TONG_4] = mjguiyang.res.UI_GAME_PAI_SIZE3_TONG4,
        [PaiValue.TONG_5] = mjguiyang.res.UI_GAME_PAI_SIZE3_TONG5,
        [PaiValue.TONG_6] = mjguiyang.res.UI_GAME_PAI_SIZE3_TONG6,
        [PaiValue.TONG_7] = mjguiyang.res.UI_GAME_PAI_SIZE3_TONG7,
        [PaiValue.TONG_8] = mjguiyang.res.UI_GAME_PAI_SIZE3_TONG8,
        [PaiValue.TONG_9] = mjguiyang.res.UI_GAME_PAI_SIZE3_TONG9,
        [PaiValue.TIAO_1] = mjguiyang.res.UI_GAME_PAI_SIZE3_TIAO1,
        [PaiValue.TIAO_2] = mjguiyang.res.UI_GAME_PAI_SIZE3_TIAO2,
        [PaiValue.TIAO_3] = mjguiyang.res.UI_GAME_PAI_SIZE3_TIAO3,
        [PaiValue.TIAO_4] = mjguiyang.res.UI_GAME_PAI_SIZE3_TIAO4,
        [PaiValue.TIAO_5] = mjguiyang.res.UI_GAME_PAI_SIZE3_TIAO5,
        [PaiValue.TIAO_6] = mjguiyang.res.UI_GAME_PAI_SIZE3_TIAO6,
        [PaiValue.TIAO_7] = mjguiyang.res.UI_GAME_PAI_SIZE3_TIAO7,
        [PaiValue.TIAO_8] = mjguiyang.res.UI_GAME_PAI_SIZE3_TIAO8,
        [PaiValue.TIAO_9] = mjguiyang.res.UI_GAME_PAI_SIZE3_TIAO9,
    },
    [PaiSize._4] =
    {
        [PaiValue.WAN_1] = mjguiyang.res.UI_GAME_PAI_SIZE4_WAN1,
        [PaiValue.WAN_2] = mjguiyang.res.UI_GAME_PAI_SIZE4_WAN2,
        [PaiValue.WAN_3] = mjguiyang.res.UI_GAME_PAI_SIZE4_WAN3,
        [PaiValue.WAN_4] = mjguiyang.res.UI_GAME_PAI_SIZE4_WAN4,
        [PaiValue.WAN_5] = mjguiyang.res.UI_GAME_PAI_SIZE4_WAN5,
        [PaiValue.WAN_6] = mjguiyang.res.UI_GAME_PAI_SIZE4_WAN6,
        [PaiValue.WAN_7] = mjguiyang.res.UI_GAME_PAI_SIZE4_WAN7,
        [PaiValue.WAN_8] = mjguiyang.res.UI_GAME_PAI_SIZE4_WAN8,
        [PaiValue.WAN_9] = mjguiyang.res.UI_GAME_PAI_SIZE4_WAN9,
        [PaiValue.TONG_1] = mjguiyang.res.UI_GAME_PAI_SIZE4_TONG1,
        [PaiValue.TONG_2] = mjguiyang.res.UI_GAME_PAI_SIZE4_TONG2,
        [PaiValue.TONG_3] = mjguiyang.res.UI_GAME_PAI_SIZE4_TONG3,
        [PaiValue.TONG_4] = mjguiyang.res.UI_GAME_PAI_SIZE4_TONG4,
        [PaiValue.TONG_5] = mjguiyang.res.UI_GAME_PAI_SIZE4_TONG5,
        [PaiValue.TONG_6] = mjguiyang.res.UI_GAME_PAI_SIZE4_TONG6,
        [PaiValue.TONG_7] = mjguiyang.res.UI_GAME_PAI_SIZE4_TONG7,
        [PaiValue.TONG_8] = mjguiyang.res.UI_GAME_PAI_SIZE4_TONG8,
        [PaiValue.TONG_9] = mjguiyang.res.UI_GAME_PAI_SIZE4_TONG9,
        [PaiValue.TIAO_1] = mjguiyang.res.UI_GAME_PAI_SIZE4_TIAO1,
        [PaiValue.TIAO_2] = mjguiyang.res.UI_GAME_PAI_SIZE4_TIAO2,
        [PaiValue.TIAO_3] = mjguiyang.res.UI_GAME_PAI_SIZE4_TIAO3,
        [PaiValue.TIAO_4] = mjguiyang.res.UI_GAME_PAI_SIZE4_TIAO4,
        [PaiValue.TIAO_5] = mjguiyang.res.UI_GAME_PAI_SIZE4_TIAO5,
        [PaiValue.TIAO_6] = mjguiyang.res.UI_GAME_PAI_SIZE4_TIAO6,
        [PaiValue.TIAO_7] = mjguiyang.res.UI_GAME_PAI_SIZE4_TIAO7,
        [PaiValue.TIAO_8] = mjguiyang.res.UI_GAME_PAI_SIZE4_TIAO8,
        [PaiValue.TIAO_9] = mjguiyang.res.UI_GAME_PAI_SIZE4_TIAO9,
    },
}

PaiBgConf =
{
    [SeatPos.ME] =
    {
        stand = mjguiyang.res.UI_GAME_PAI_SIZE1_MAHJONG2,
        lay_down = mjguiyang.res.UI_GAME_PAI_SIZE2_MAHJONG3,
        lay_up = mjguiyang.res.UI_GAME_PAI_SIZE2_MAHJONG1,
        size_stand = PaiSize._1,
        size_lay = PaiSize._2,
    },
    [SeatPos.RIGHT] =
    {
        stand = mjguiyang.res.UI_GAME_PAI_SIZE3_MAHJONG3,
        lay_down = mjguiyang.res.UI_GAME_PAI_SIZE3_MAHJONG2,
        lay_up = mjguiyang.res.UI_GAME_PAI_SIZE3_MAHJONG1,
        size_lay = PaiSize._3,
    },
    [SeatPos.UP] =
    {
        stand = mjguiyang.res.UI_GAME_PAI_SIZE2_MAHJONG2,
        lay_down = mjguiyang.res.UI_GAME_PAI_SIZE2_MAHJONG3,
        lay_up = mjguiyang.res.UI_GAME_PAI_SIZE2_MAHJONG1,
        size_lay = PaiSize._2,
    },
    [SeatPos.LEFT] =
    {
        stand = mjguiyang.res.UI_GAME_PAI_SIZE3_MAHJONG3,
        lay_down = mjguiyang.res.UI_GAME_PAI_SIZE3_MAHJONG2,
        lay_up = mjguiyang.res.UI_GAME_PAI_SIZE3_MAHJONG1,
        size_lay = PaiSize._3
    },
}

function Pai.getBgSrcConf(seatPos)
    return PaiBgConf[seatPos]
end

function Pai.getValueSrc(value, seatPos, status)
    return PaiSrcConf[Pai.getPaiSize(seatPos, status)][value]
end

function Pai.getPaiSize(seatPos, status)
    if status == PaiStatus.STAND then
        return PaiBgConf[seatPos].size_stand
    elseif status == PaiStatus.LAY_UP or status == PaiStatus.LAY_DOWN then
        return PaiBgConf[seatPos].size_lay
    end
end

return Pai