-------------------------------------------------------------------------
-- Title:          斗牛初始化入口
-- Author:      Jackie Liu
-- Date:         2016/11/05 18:15:35
-- Desc:
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
-- 斗牛的总table
cc.exports.dn = { }
local dn = dn
local ptf = ptf

-- 斗牛配置，资源，文字
import(".conf.init")

-- 斗牛工具
import(".util.init")

-- 网络消息
import("net.init")

-- 缓存数据
import(".data.init")

-- UI层
import(".ui.init")