-------------------------------------------------------------------------
-- Title:
-- Author:      Jackie Liu
-- Date:         2016/10/29 00:42:54
-- Desc:
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
dn.util = { }

local util = dn.util

-- 语言版本
local strings = dn.strings
util.getStr = function(stringname)
    return strings[stringname]
end

import(".ui")
import(".logic")

-- 创建界面的方法
util.createView, util.getLayout, util.inflateLayout, util.addView, util.replaceView, util.replaceViewEx =
util.createViewMethods(base.src.ui.view, base.src.ui.layout)