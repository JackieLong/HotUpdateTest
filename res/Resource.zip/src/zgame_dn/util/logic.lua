-------------------------------------------------------------------------
-- Title:	
-- Author:     Jackie Liu
-- Date:       2016/09/13 15:48:27
-- Desc:
-- Copyright (c) wawagame Entertainment All right reserved.
-------------------------------------------------------------------------
local logic = dn.util
local math, dn, string = math, dn, string

-- 返回花色和牌值
logic.getPokerAttr = function(pokerValue)
    return math.floor(pokerValue / 16), pokerValue % 16
end

-- local constants = {[1] = "3",[2] = "4",[3] = "5",[4] = "6",[5] = "7",[6] = "8",[7] = "9",[8] = "10",[9] = "J",[10] = "Q",[11] = "K",[12] = "A",[13] = "2",}
-- 获取牌值的sprite
-- 12345678  9  10JQK
-- 23456789  10J  QKA
-- 345678910J  Q  KA2
local strBlack = dn.res.game.card_num_black
local strRed = dn.res.game.card_num_red
local startAscii = string.byte(1)
logic.getPokerValNode = function(pokerValue, flagRedOrBlack)
    local offset = nil
    if pokerValue <= 12 then
        offset = pokerValue
    else
        offset = 0
    end
    return cc.Label:createWithCharMap(flagRedOrBlack and strRed or strBlack, 36, 42, startAscii):setString(string.char(startAscii + offset))
end

-- getPokerColorEnum(1) = dn.conf.CARD.Hei
-- 获取花色的sprite
local colorSrc = { dn.res.game.card_color_1, dn.res.game.card_color_2, dn.res.game.card_color_3, dn.res.game.card_color_4, }
logic.getPokerColorNode = function(pokerColor)
    return display.newSprite(colorSrc[pokerColor])
end