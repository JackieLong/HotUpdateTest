-------------------------------------------------------------------------
-- Title:           文字配置
-- Author:      Jackie Liu
-- Date:         2016/10/29 00:48:52
-- Desc:
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
return
{
    waiting_login = "请稍候...",
    login_succ = "登录成功",
    login_fail = "登录失败",
    sui_ji_zhuang_jia = "随机庄家",
    quick_start = "快速开始",
    null_room_list = "先获取房间列表",
}