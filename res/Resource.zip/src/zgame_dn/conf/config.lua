return
{
    GAME_ID = 10001,
    ROOT_PATH = "zgame_dn",
    CARD =
    {
        -- 黑桃
        Hei = 1,
        -- 红桃
        Hong = 2,
        -- 梅花
        Mei = 3,
        -- 方块
        Fang = 4,
    },
    -- 翻牌时间
    POKER_TURN_TIME = 0.3,
}