﻿
-- 斗牛配置
dn.conf = import(".config")

-- 斗牛广播事件
dn.event = import(".event")

-- 语言
dn.strings = import(".strings")

-- 斗牛ui资源
dn.res = base.wholeRes.res.dn

-- 斗牛源码
dn.src = base.wholeRes.src.zgame_dn