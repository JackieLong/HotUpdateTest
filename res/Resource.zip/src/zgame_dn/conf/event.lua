-------------------------------------------------------------------------
-- Title:          斗牛模块中产生的消息，一般都只在斗牛内部处理
-- Author:      Jackie Liu
-- Date:         2016/11/17 00:32:14
-- Desc:
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
return
{
    MSG_IN_GAME_DONE = "MSG_IN_GAME_DONE"
}