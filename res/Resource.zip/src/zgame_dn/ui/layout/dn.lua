-------------------------------------------------------------------------
-- Title:          斗牛主界面
-- Author:      Jackie Liu
-- Date:         2016/11/06 14:38:53
-- Desc:
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
return
{
    class = "Layer",
    name = "hall",
    {
        class = "Sprite",
        name = "bg",
        src = dn.res.hall.bg,
        center = ptf.contants.ui.Parent
    },
    {
        -- 开始游戏
        class = "Btn",
        name = "btnStartGame",
        _style = dn.style.btn_style_1,
        titleTxt = dn.util.getStr("quick_start"),
        center = "bg",
    }
}