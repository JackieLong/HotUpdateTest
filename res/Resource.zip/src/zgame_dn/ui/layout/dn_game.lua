-------------------------------------------------------------------------
-- Title:          斗牛游戏对局布局
-- Author:      Jackie Liu
-- Date:         2016/11/16 22:58:16
-- Desc:
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
return
{
    class = "Layer",
    name = "hall",
    {
        class = "Sprite",
        name = "bg",
        src = dn.res.game.bg_1,
        center = ptf.contants.ui.Parent
    },
}