﻿-- UI样式配置
dn.style = import(".style")

-- 初始界面是MainView
dn.util.replaceViewEx("DNView")