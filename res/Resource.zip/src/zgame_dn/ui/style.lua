return
{
    btn_style_1 =
    {
        class = "Btn",
        titleClr = display.COLOR_BLUE,
        titleFntSize = 40,
        normal = base.res.common.common_btn_1,
    }
}