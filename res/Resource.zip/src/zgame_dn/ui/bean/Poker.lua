-------------------------------------------------------------------------
-- Title:
-- Author:    Jackie Liu
-- Date:       2016/09/13 15:48:27
-- Desc:
-- Copyright (c) wawagame Entertainment All right reserved.
-------------------------------------------------------------------------
local Poker = class("Poker", cc.Node)
local TAG = "Poker"
local ptf, dn = ptf, dn

function Poker:ctor(pokerValue)
    -- 牌值
    self._num = nil
    -- 花色
    self._color = nil
    -- 背面
    self._bg = nil
    -- 正面
    self._fore = nil
    -- 当前是不是背面
    self._flag_back = false

    self._color, self._num = dn.logic.getPokerAttr(pokerValue)
    ptf.log.debug(TAG, "poker color:%d, poker num:%d", self._color, self._num)
    assert(self._color <= 4 and self._num <= 13, "invalid poker color or invalid poker num")
    self._fore = display.newSprite(dn.res.game.card_1):addTo(self)
    self._bg = display.newSprite(dn.res.game.card_2):addTo(self):setVisible(false)
    self:size(self._fore)
    self._fore:center(self)
    self._bg:center(self)
    local pokerValFlag = dn.logic.getPokerValNode(self._num, self._color == 2 or self._color == 4):addTo(self._fore):innerLeft(self._fore):innerTop(self._fore):offset(5, -5)
    local pokerColor = dn.logic.getPokerColorNode(self._color):addTo(self._fore):center(self._fore):offsetY(-10)
end

function Poker:isBack()
    return self._flag_back
end

function Poker:setBack(flag)
    flag = flag == nil and false or flag
    if self._flag_back ~= flag or((flag == nil) and self._flag_back) then
        -- 状态不同才有必要设置正面还是背面
        self._fore:setVisible(not flag)
        self._bg:setVisible(flag)
        self._flag_back = flag
    end
    return self
end

-- 当前是否正在翻转中
local flag_turning = false
local time = dn.conf.POKER_TURN_TIME
function Poker:turn(callback)
    assert(not flag_turning, "poker can not be turn in one time")
    local fore, back
    if self._flag_back then
        fore, back = self._fore, self._bg
    else
        fore, back = self._bg, self._fore
    end
    self._flag_back = not self._flag_back
    flag_turning = true
    fore:runAction(cc.Sequence:create(cc.DelayTime:create(time / 2),
    cc.Show:create(),
    cc.OrbitCamera:create(time / 2, 1, 0, 270, 90, 0, 0)))
    back:runAction(
    cc.Sequence:create(cc.OrbitCamera:create(time / 2, 1, 0, 0, 90, 0, 0),
    cc.Hide:create(),
    cc.CallFunc:create( function() flag_turning = false; if callback then callback() end end)))
    return self
end

return Poker