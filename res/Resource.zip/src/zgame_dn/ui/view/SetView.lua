-------------------------------------------------------------------------
-- Desc:            设置界面
-- Author:        Jackie Liu
-- CreateDate:    2016/08/31 00:52:44
-- Purpose:       purpose
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
local SetView = class("SetView")

function SetView:ctor()
    self._view = nil
end

-- 界面生成前的回调，返回需要加载的资源列表
function SetView:onPreload()

end

-- 界面生成
function SetView:onGetLayout()
    ptf.ui.edit("track.ui.views.layout.SetView.SetView")
    return { class = "Layer", name = "motherfucker" }
end

function SetView:onCreateView(view)
    self._view = view
end

function SetView:getView()
    return self._view
end

-- 界面销毁前的回调,返回需要卸载的资源列表
function SetView:onDestroy()

end

-- 返回loading界面
function SetView:onLoadingView()

end

-- view切换动画,in进入的动画，out退出的动画，返回动画的时间
function SetView:onTransAniIn(view, viewOld)

end

-- view切换动画,in进入的动画，out退出的动画，返回动画的时间
function SetView:onTransAniOut(view, viewOld)

end

return SetView