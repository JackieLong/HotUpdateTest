-------------------------------------------------------------------------
-- Title:
-- Author:           Jackie Liu
-- Date:    2016/11/06 14:33:12
-- Desc:
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
local DNView = class("DNView", ptf.ui.baseView)
local TAG = "DNView"
local ptf, dn, base = ptf, dn, base

function DNView:ctor()
    self.super.ctor(self)
    self._view = nil
end

function DNView:onPreload()

end

function DNView:onGetLayout()
    return dn.util.getLayout("dn")
end

function DNView:onCreateView(view)
    view:swallowTouch()
    self._view = view
    local viewConf = view.viewConf
    viewConf.btnStartGame:onClick( function()
        if dn.userdata.roomList then
            -- 第一个房间
            dn.proxy.DNInGameProxy:quickStart(dn.userdata.roomList[1].playtype, dn.userdata.roomList[1].gamezoneid)
        else
            base.util.toast(dn.util.getStr("null_room_list"))
        end
    end )
    ptf.util.bindListener(self._view, { { "get_gamezoneinfolist", handler(self, self._messageReceived) }, { "quickstartgame", handler(self, self._messageReceived) }, })
    ptf.util.setKeyBackListener(self._view, function(event)
        -- 斗牛退到大厅
        cc.exports.dn = nil
    end )
    -- 随机庄家玩法的房间列表
    base.proxyHall:requestRoomList(dn.conf.GAME_ID, 1)

    local poker = require(dn.src.ui.bean.Poker):create(27):addTo(self._view.viewConf.bg):offset(200, 200)
    local function callback()
        ptf.util.exeDelay(1.0, function()
            poker:turn( function()
                callback()
                base.util.toast(tostring(poker:isBack()))
            end )
        end )
    end
    callback()
end

function DNView:_messageReceived(event)
    ptf.log.debug(TAG, "_messageReceived", event.name)
    if event.name == "get_gamezoneinfolist" then
        -- 房间列表
        dn.userdata.roomList = event.data.gamezoneinfolist
    elseif event.name == "quickstartgame" then
        -- 快速开始，进入房间
        dn.util.replaceViewEx("DNGameView", event.data)
    end
end

function DNView:getView()
    return self._view
end

function DNView:onDestroy()

end

function DNView:onLoadingView()

end

function DNView:onTransAniIn(view, viewOld)
    ptf.util.cascadeOpacity(view)
    ptf.util.cascadeOpacity(viewOld)
    view:setOpacity(0)
    local time = 0.3
    view:runAction(cc.FadeIn:create(time))
    viewOld:runAction(cc.FadeOut:create(time))
    return time
end

function DNView:onTransAniOut(view, viewOld)

end

return DNView