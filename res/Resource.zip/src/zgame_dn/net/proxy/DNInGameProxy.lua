-------------------------------------------------------------------------
-- Title:
-- Author:      Jackie Liu
-- Date:         2016/11/06 14:10:16
-- Desc:
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
local ProxyGame = class("ProxyGame", ptf.net.proxy)
local TAG = "DNProxyGame"

function ProxyGame:ctor()
end

function ProxyGame:filterMsg()
    return {
        "quickstartgame",
        "leavegame",
        "bf_ready",
        "bf_bankermultiple",
        "bf_stakemultiple",
        "bf_showcards",
        "bf_userenter",
        "bf_userleave",
        "bf_userready",
        "bf_startgame",
        "bf_roundstart",
        "bf_userbankermultiple",
        "bf_playbanker",
        "bf_userstakemultiple",
        "bf_usershowcards",
        "bf_gameover",
    }
end

function ProxyGame:msgReceived(name, args)
    if name == "quickstartgame" then

    elseif name == "leavegame" then
        -- 玩家离开游戏
    elseif name == "bf_ready" then
        -- 玩家准备
    elseif name == "bf_bankermultiple" then
        -- 玩家抢庄操作
    elseif name == "bf_stakemultiple" then
        -- 玩家下注操作
    elseif name == "bf_showcards" then
        -- 玩家开牌操作
    elseif name == "loginsuccess" then
    elseif name == "bf_userenter" then
        -- 玩家进入信息
    elseif name == "bf_userleave" then
        -- 玩家离开信息
    elseif name == "bf_userready" then
        -- 玩家准备信息
    elseif name == "bf_startgame" then
        -- 牌局开始
    elseif name == "bf_roundstart" then
        -- 轮结束通知信息
    elseif name == "bf_userbankermultiple" then
        -- 玩家抢庄操作信息
    elseif name == "bf_playbanker" then
        -- 对局庄家信息
    elseif name == "bf_userstakemultiple" then
        -- 玩家下注操作信息
    elseif name == "bf_usershowcards" then
        -- 玩家开牌操作信息
    elseif name == "bf_gameover" then
        -- 牌局结算
    else
        ptf.log.warn(TAG, "unhandle game msg[%s]", name)
    end
    return args
end

function ProxyGame:heartbeat()
    self:request("heartbeat")
end

-- 快速开始
function ProxyGame:quickStart(playType, zoneID)
    self:request("quickstartgame", {
        gameid = dn.conf.GAME_ID,
        playtype = playType,
        gamezoneid = zoneID
    } )
end

-- 离开游戏
function ProxyGame:leaveGame()
    self:request("leavegame")
end

-- 玩家准备
function ProxyGame:ready()
    self:request("bf_ready")
end

-- 抢庄
function ProxyGame:qiangZhuang(multiple)
    self:request("bf_bankermultiple", {
        multiple = multiple
    } )
end

-- 下注
function ProxyGame:xiaZhu(multiple)
    self:request("bf_stakemultiple", {
        multiple = multiple
    } )
end

-- 开牌
-- type 0:integer  ## 0：使用道具/直接花费游戏币算牌 1:手动算牌
-- value 1:integer ## 0:无牛 1:有牛 11:炸弹 12:五花牛 13:五小牛
-- bullhead 2:*integer ## 牛头牌 value = 1 时需传
-- bulltail 3:*integer ## 牛尾牌 value = 1 时需传
function ProxyGame:kaiPai(params)
    self:request("bf_showcards", params)
end

return ProxyGame