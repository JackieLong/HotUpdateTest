﻿-- 斗牛消息代理
dn.proxyGame = import(".proxy.DNInGameProxy"):create():start()