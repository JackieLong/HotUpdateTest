
ptf.util.delayDo(0.01, function()
    ptf.ui.mainScene = ptf.director:getRunningScene()
    local TestLayer = cc.Layer:create():addTo(ptf.ui.mainScene)
    local BettySkinDesc = [[This is the second test hotupdate version of BettySkin.]]
    local title = cc.Label:createWithSystemFont(BettySkinDesc, "", 50):addTo(TestLayer):center(TestLayer)
end )
