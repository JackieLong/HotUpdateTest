
ptf.util.delayDo(0.01, function()
    ptf.ui.mainScene = ptf.director:getRunningScene()
    local TestLayer = cc.Layer:create():addTo(ptf.ui.mainScene)
    local title = cc.Label:createWithSystemFont("Betty Skin.", "", 50):addTo(TestLayer):center(TestLayer)
end )
