-------------------------------------------------------------------------
-- Title:          处理平台区分的事情（android,ios,windows）
-- Author:        Jackie Liu
-- CreateDate:    2016/09/11 18:35:34
-- Desc:
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
local ptf = ptf
if not ptf.platform then
    local patform = { }
    ptf.patform = patform
end