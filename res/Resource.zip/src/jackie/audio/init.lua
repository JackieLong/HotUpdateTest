-------------------------------------------------------------------------
-- Title:           音频模块
-- Author:        Jackie Liu
-- CreateDate:    2016/09/11 18:30:02
-- Desc:
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
ptf.audio = import(".AudioMgr"):create()
