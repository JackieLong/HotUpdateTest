-------------------------------------------------------------------------
-- Desc:          音频管理
-- Author:      Jackie Liu
-- Date:        2016/08/13 18:15:42
-- Detail:
--        播放单个音效
--        params =
--        {
--            --音频资源播放路径
--            src = "background.mp3",
--            --是否循环播放,默认false
--            loop = true,
--            --音量0.0~~1.0，默认1.0
--            vol = 1.0,
--            --播放结束回调
--            callback = function() print("play ended!!") end
--            ratio = 0.5,
--        }
--        AudioMgr:play(params)
-- Revisions:
--        Jackie Liu(2016/08/13 18:15:42) create this file
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
local AudioMgr = class("AudioMgr")

local gAudio = ccexp.AudioEngine

function AudioMgr:ctor()

end

function AudioMgr:init()

end

local function playOneAudio(params)
    local ret = cc.AUDIO_INVAILD_ID
    if params.src then
        ret = gAudio:play2d(params.src, params.loop, params.vol)
        if ret ~= cc.AUDIO_INVAILD_ID then
            if params.callback then
                -- 播放结束回调
                gAudio:setFinishCallback(ret, params.callback)
            end
            if params.ratio then
                -- 从百分之几开始播放
                gAudio:setCurrentTime(ret, gAudio:getDuration(ret) * params.radio)
            end
        end
    else
        ret = gAudio:play2d(params)
    end
    return ret
end

-- 可以同时播放单个或者多个音频，多个时params是下标从1开始不间断的数组形式
function AudioMgr:play(params)
    local ret = nil
    if type(params) == "string" then
        ret = playOneAudio(params)
    elseif #params <= 0 then
        -- 播放单个音效
        ret = playOneAudio(params)
    else
        -- 播放多种音效
        ret = { }
        for k, v in ipairs(params) do
            ret[#ret + 1] = playOneAudio(params)
        end
    end
    return ret
end

-- 停止播放并清除缓存
-- srcs可能就是单个路径也可能是下标从1开始不间断的数组形式
function AudioMgr:uncache(srcs)
    if type(srcs) == "string" then
        gAudio:uncache(srcs)
    else
        for k, v in ipairs(srcs) do
            gAudio:uncache(v)
        end
    end
end

return AudioMgr