-------------------------------------------------------------------------
-- Author:      Derek
-- Date:        2017-05-14 00:09:52
-- Desc:        播放音效工具，可根据配置随机播放音效 
-- Revisions:         Derek create this file at 2017-05-14 00:09:52
-- Copyright (c) 2017 FengYun Game
-------------------------------------------------------------------------
PlaySoundUtil = PlaySoundUtil or {}

-- 麻将音效资源地址
local SOUNT_MAHJONG_MAN_RES = "TDHMJ/res/MahJong/sound/man/"
local SOUNT_MAHJONG_WOMAN_RES = "TDHMJ/res/MahJong/sound/woman/"

-- 操作音效资源地址
local SOUNT_EVENT_MAN_RES = "TDHMJ/res/Event/sound/man/"
local SOUNT_EVENT_WOMAN_RES = "TDHMJ/res/Event/sound/woman/"

local languageType = {}
languageType.LANGUAGE_CN = 1           -- 普通话
languageType.LANGUAGE_OTHER = 2           -- 方言(贵州)

local LANGUAGE_OTHER_SUFFIX = "GZ_"                 -- 方言后缀(添加到方言音效资源的命名上)

local eventType = {}
eventType.EVENT_CHI = 1             -- 吃
eventType.EVENT_PENG = 2            -- 碰
eventType.EVENT_GANG = 3            -- 杠
eventType.EVENT_ANGANG = 4          -- 杠(暗杠)
eventType.EVENT_MINGGANG = 5        -- 杠(明杠或点杠)
eventType.EVENT_BUGANG = 6          -- 杠(补杠，先碰后杠)
eventType.EVENT_TING = 7            -- 听
eventType.EVENT_HU = 8              -- 胡
eventType.EVENT_DIANPAO = 8         -- 胡(点炮)
eventType.EVENT_ZIMO = 8            -- 胡(自摸)


--获取声音数量(用于随机, 为1可以省略)
local soundCountEventMan = {}
soundCountEventMan[EVENT_CHI] = 1
soundCountEventMan[EVENT_PENG] = 1
soundCountEventMan[EVENT_GANG] = 1
soundCountEventMan[EVENT_ANGANG] = 1
soundCountEventMan[EVENT_MINGGANG] = 1
soundCountEventMan[EVENT_BUGANG] = 1
soundCountEventMan[EVENT_TING] = 1
soundCountEventMan[EVENT_HU] = 1

local soundCountEventWoman = {}
soundCountEventWoman[EVENT_CHI] = 1
soundCountEventWoman[EVENT_PENG] = 1
soundCountEventWoman[EVENT_GANG] = 1
soundCountEventWoman[EVENT_ANGANG] = 1
soundCountEventWoman[EVENT_MINGGANG] = 1
soundCountEventWoman[EVENT_BUGANG] = 1
soundCountEventWoman[EVENT_TING] = 1
soundCountEventWoman[EVENT_HU] = 1


--获取声音数量(用于随机，为1可以省略)
local soundCountMan = {}
soundCountMan[1] =2
soundCountMan[2] =2
soundCountMan[3] =2
soundCountMan[4] =2
soundCountMan[8] =2
soundCountMan[11] =2
soundCountMan[12] =2
soundCountMan[13] =2
soundCountMan[14] =2
soundCountMan[16] =2
soundCountMan[17] =2
soundCountMan[18] =2
soundCountMan[19] =2
soundCountMan[21] =2
soundCountMan[22] =2
soundCountMan[24] =1
soundCountMan[23] =2
soundCountMan[25] =2
soundCountMan[27] =2
soundCountMan[28] =2
soundCountMan[29] =2

local soundCountWoman = {}
soundCountWoman[1] =2
soundCountWoman[2] =2
soundCountWoman[3] =2
soundCountWoman[4] =2
soundCountWoman[8] =2
soundCountWoman[11] =2
soundCountWoman[12] =2
soundCountWoman[13] =2
soundCountWoman[14] =2
soundCountWoman[16] =2
soundCountWoman[17] =2
soundCountWoman[18] =2
soundCountWoman[19] =2
soundCountWoman[21] =2
soundCountWoman[22] =2
soundCountWoman[23] =2
soundCountWoman[24] =2
soundCountWoman[25] =2
soundCountWoman[27] =2
soundCountWoman[28] =2


-- 播放出牌音效(适用与麻将，地主等单张出牌牌值的音效播放)       value 牌值        isMan 是否为男性    
function PlaySoundUtil.playSoundOutCard(value, isMan)
    local language = cc.UserDefault:getInstance():getIntegerForKey("language")      -- 服务端语言
    local soundRes = isMan and SOUNT_MAN_RES or SOUNT_WOMAN_RES                     -- 获取音效地址
    soundCountMan[value] = soundCountMan[value] and soundCountMan[value] or 1        -- 如果没有设置给默认值1
    soundCountWoman[value] = soundCountWoman[value] and soundCountWoman[value] or 1     -- 如果没有设置给默认值1
    local soundCount = isMan and soundCountMan[value] or soundCountWoman[cardValue] -- 获取该音效的个数
    if languageType.LANGUAGE_CN == language then
        -- 使用标准普通话
        MYAudioEngine_getInstance():playEffect(string.format("%s%d.mp3", soundRes, cardValue))
    elseif languageType.LANGUAGE_OTHER == language then
        PlaySoundUtil.playSoundLanguage(soundRes, value, soundCount)
    end
end


-- 播放动作音效(适用于麻将的吃碰杠听胡)
function PlaySoundUtil:playSoundEvents(type, isMan)
    local language = cc.UserDefault:getInstance():getIntegerForKey("language")
    local soundRes = isMan and SOUNT_EVENT_MAN_RES or SOUNT_EVENT_WOMAN_RES
    local soundCount = 1
    if eventType.EVENT_CHI == type then
        if languageType.LANGUAGE_CN == language then
            MYAudioEngine_getInstance():playEffect(string.format("%chi.mp3", soundRes))
        elseif languageType.LANGUAGE_OTHER == language then
            soundCountEventMan[eventType.EVENT_CHI] = soundCountEventMan[eventType.EVENT_CHI] and soundCountEventMan[eventType.EVENT_CHI] or 1
            soundCountEventWoman[eventType.EVENT_CHI] = soundCountEventWoman[eventType.EVENT_CHI] and soundCountEventWoman[eventType.EVENT_CHI] or 1
            soundCount = isMan and soundCountEventMan[eventType.EVENT_CHI] or soundCountEventWoman[eventType.EVENT_CHI]
            self:playSoundLanguage(soundRes, "chi", soundCount)
        end
    elseif eventType.EVENT_PENG == type then
        if languageType.LANGUAGE_CN == language then
            MYAudioEngine_getInstance():playEffect(string.format("%speng.mp3", soundRes))
        elseif languageType.LANGUAGE_OTHER == language then
            soundCountEventMan[eventType.EVENT_PENG] = soundCountEventMan[eventType.EVENT_PENG] and soundCountEventMan[eventType.EVENT_PENG] or 1
            soundCountEventWoman[eventType.EVENT_PENG] = soundCountEventWoman[eventType.EVENT_PENG] and soundCountEventWoman[eventType.EVENT_PENG] or 1
            soundCount = isMan and soundCountEventMan[eventType.EVENT_PENG] or soundCountEventWoman[eventType.EVENT_PENG]
            self:playSoundLanguage(soundRes, "peng", soundCount)
        end
    elseif eventType.EVENT_GANG == type then
        if languageType.LANGUAGE_CN == language then
            MYAudioEngine_getInstance():playEffect(string.format("%sgang.mp3", soundRes))
        elseif languageType.LANGUAGE_OTHER == language then
            soundCountEventMan[eventType.EVENT_GANG] = soundCountEventMan[eventType.EVENT_GANG] and soundCountEventMan[eventType.EVENT_GANG] or 1
            soundCountEventWoman[eventType.EVENT_GANG] = soundCountEventWoman[eventType.EVENT_GANG] and soundCountEventWoman[eventType.EVENT_GANG] or 1
            soundCount = isMan and soundCountEventMan[eventType.EVENT_GANG] or soundCountEventWoman[eventType.EVENT_GANG]
            self:playSoundLanguage(soundRes, strType, soundCount)

            -- -- 随机使用贵州方言(默认第一个)
            -- local strType = ""
            -- if eventInfo.bAnGang then
            --     strType = "an"
            -- elseif eventInfo.bBuGang then
            --     -- strType = "bugang"
            --     strType = "gang"
            -- else
            --     strType = "gang"
            -- end
            -- local soundPath = string.format("%s%s.1.wav", soundRes, strType)
            -- local randIndex = math.random(1, 2)
            -- soundPath = string.format("%s%s.%d.wav", soundRes, strType, randIndex)
            -- dump(soundPath, "derek================soundPath:")
            -- MYAudioEngine_getInstance():playEffect(soundPath)
            
        end
    elseif eventType.EVENT_ANGANG == type then
        if languageType.LANGUAGE_CN == language then
            MYAudioEngine_getInstance():playEffect(string.format("%sgang.mp3", soundRes))
        elseif languageType.LANGUAGE_OTHER == language then
            soundCountEventMan[eventType.EVENT_ANGANG] = soundCountEventMan[eventType.EVENT_ANGANG] and soundCountEventMan[eventType.EVENT_ANGANG] or 1
            soundCountEventWoman[eventType.EVENT_ANGANG] = soundCountEventWoman[eventType.EVENT_ANGANG] and soundCountEventWoman[eventType.EVENT_ANGANG] or 1
            soundCount = isMan and soundCountEventMan[eventType.EVENT_ANGANG] or soundCountEventWoman[eventType.EVENT_ANGANG]
            self:playSoundLanguage(soundRes, strType, soundCount)
        end
    elseif eventType.EVENT_MINGGANG == type then
        if languageType.LANGUAGE_CN == language then
            MYAudioEngine_getInstance():playEffect(string.format("%sgang.mp3", soundRes))
        elseif languageType.LANGUAGE_OTHER == language then
            soundCountEventMan[eventType.EVENT_MINGGANG] = soundCountEventMan[eventType.EVENT_MINGGANG] and soundCountEventMan[eventType.EVENT_MINGGANG] or 1
            soundCountEventWoman[eventType.EVENT_MINGGANG] = soundCountEventWoman[eventType.EVENT_MINGGANG] and soundCountEventWoman[eventType.EVENT_MINGGANG] or 1
            soundCount = isMan and soundCountEventMan[eventType.EVENT_MINGGANG] or soundCountEventWoman[eventType.EVENT_MINGGANG]
            self:playSoundLanguage(soundRes, strType, soundCount)
        end
    elseif eventType.EVENT_BUGANG == type then
        if languageType.LANGUAGE_CN == language then
            MYAudioEngine_getInstance():playEffect(string.format("%sgang.mp3", soundRes))
        elseif languageType.LANGUAGE_OTHER == language then
            soundCountEventMan[eventType.EVENT_BUGANG] = soundCountEventMan[eventType.EVENT_BUGANG] and soundCountEventMan[eventType.EVENT_BUGANG] or 1
            soundCountEventWoman[eventType.EVENT_BUGANG] = soundCountEventWoman[eventType.EVENT_BUGANG] and soundCountEventWoman[eventType.EVENT_BUGANG] or 1
            soundCount = isMan and soundCountEventMan[eventType.EVENT_BUGANG] or soundCountEventWoman[eventType.EVENT_BUGANG]
            self:playSoundLanguage(soundRes, strType, soundCount)
        end
    elseif(eventType.EVENT_TING == eventInfo.eventType) then
        if languageType.LANGUAGE_CN == language then
            MYAudioEngine_getInstance():playEffect(string.format("%sting.mp3", soundRes))
        elseif languageType.LANGUAGE_OTHER == language then
            soundCountEventMan[eventType.EVENT_TING] = soundCountEventMan[eventType.EVENT_TING] and soundCountEventMan[eventType.EVENT_TING] or 1
            soundCountEventWoman[eventType.EVENT_TING] = soundCountEventWoman[eventType.EVENT_TING] and soundCountEventWoman[eventType.EVENT_TING] or 1
            soundCount = isMan and soundCountEventMan[eventType.EVENT_TING] or soundCountEventWoman[eventType.EVENT_TING]
            self:playSoundLanguage(soundRes, "ting", soundCount)
        end
    elseif(eventType.EVENT_HU == eventInfo.eventType) then
        if languageType.LANGUAGE_CN == language then
            MYAudioEngine_getInstance():playEffect(string.format("%sting.mp3", soundRes))
        elseif languageType.LANGUAGE_OTHER == language then
            soundCountEventMan[eventType.EVENT_HU] = soundCountEventMan[eventType.EVENT_HU] and soundCountEventMan[eventType.EVENT_HU] or 1
            soundCountEventWoman[eventType.EVENT_HU] = soundCountEventWoman[eventType.EVENT_HU] and soundCountEventWoman[eventType.EVENT_HU] or 1
            soundCount = isMan and soundCountEventMan[eventType.EVENT_HU] or soundCountEventWoman[eventType.EVENT_HU]
            self:playSoundLanguage(soundRes, "hu", soundCount)
        end
    elseif(eventType.EVENT_DIANPAO == eventInfo.eventType) then
        if languageType.LANGUAGE_CN == language then
            MYAudioEngine_getInstance():playEffect(string.format("%sting.mp3", soundRes))
        elseif languageType.LANGUAGE_OTHER == language then
            soundCountEventMan[eventType.EVENT_DIANPAO] = soundCountEventMan[eventType.EVENT_DIANPAO] and soundCountEventMan[eventType.EVENT_DIANPAO] or 1
            soundCountEventWoman[eventType.EVENT_DIANPAO] = soundCountEventWoman[eventType.EVENT_DIANPAO] and soundCountEventWoman[eventType.EVENT_DIANPAO] or 1
            soundCount = isMan and soundCountEventMan[eventType.EVENT_DIANPAO] or soundCountEventWoman[eventType.EVENT_DIANPAO]
            self:playSoundLanguage(soundRes, "dianpao", soundCount)
        end
    elseif(eventType.EVENT_ZIMO == eventInfo.eventType) then
        if languageType.LANGUAGE_CN == language then
            MYAudioEngine_getInstance():playEffect(string.format("%sting.mp3", soundRes))
        elseif languageType.LANGUAGE_OTHER == language then
            soundCountEventMan[eventType.EVENT_ZIMO] = soundCountEventMan[eventType.EVENT_ZIMO] and soundCountEventMan[eventType.EVENT_ZIMO] or 1
            soundCountEventWoman[eventType.EVENT_ZIMO] = soundCountEventWoman[eventType.EVENT_ZIMO] and soundCountEventWoman[eventType.EVENT_ZIMO] or 1
            soundCount = isMan and soundCountEventMan[eventType.EVENT_ZIMO] or soundCountEventWoman[eventType.EVENT_ZIMO]
            self:playSoundLanguage(soundRes, "zimo", soundCount)
        end
    end
end

-- function PlaySoundUtil:playSoundHu(eventSendPlayerViewSeatNO)
--     local language = cc.UserDefault:getInstance():getIntegerForKey("language")
--     local isBoy = self.tableLogic:getUserSexBySeat(self.tableLogic:viewToLogicSeatNo(eventSendPlayerViewSeatNO))
--     local soundRes = isBoy and "TDHMJ/res/MahJong/sound/man/" or "TDHMJ/res/MahJong/sound/woman/"
--     if 1 == language then
--         MYAudioEngine_getInstance():playEffect(string.format("%shu.mp3", soundRes))
--     elseif 2 == language then
--         self:playSoundLanguage(soundRes, "hu", 2)
--     end  
-- end


-- 根据地主和资源名称随机获取音效
function PlaySoundUtil.playSoundLanguage(soundRes, soundName, soundCount)

    -- local isBoy = self.tableLogic:getUserSexBySeat(self.tableLogic:viewToLogicSeatNo(eventInfo.eventSendPlayerViewSeatNO))
    -- local soundRes = isBoy and "GYMJ/res/MahJong/sound/man/" or "GYMJ/res/MahJong/sound/woman/"
    -- local soundPath = string.format("%s%s%s.mp3", soundRes, LANGUAGE_OTHER_SUFFIX, soundName)
    local randIndex = math.random(1, soundCount)
    soundPath = string.format("%s%s%s.%d.wav", soundRes, LANGUAGE_OTHER_SUFFIX, soundName, randIndex)
    dump(soundPath, "derek================soundPath:")
    MYAudioEngine_getInstance():playEffect(soundPath)
end





