-------------------------------------------------------------------------
-- Title:            文件读取
-- Author:        Jackie Liu
-- CreateDate:    2016/09/10 21:43:11
-- Desc:
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
local File = { __cname = "File" }

function File.read(path)
    local handle = io.open(path, "r")
    if handle then
        local data = handle:read("*a")
        handle:close()
        return data
    end
end

function File.write(data, path, access)
    local handle = io.open(path, access or "w+")
    if handle then
        handle:write(data)
        handle:flush()
        handle:close()
    end
end

return File
