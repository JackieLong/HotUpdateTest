-------------------------------------------------------------------------
-- Title:
-- Author:        Jackie Liu
-- CreateDate:    2016/09/11 18:32:17
-- Desc:
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
local ptf = ptf

ptf.log = import(".Log")

ptf.__G__TRACKBACK__ = function(msg)
    local msg = debug.traceback(msg, 3)
    ptf.log.error("error", msg)

    if device.platform == "android" or device.platform == "ios" then
        buglyReportLuaException(tostring(msg), debug.traceback())
    end

    return msg
end