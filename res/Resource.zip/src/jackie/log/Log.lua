-------------------------------------------------------------------------
-- Desc:    日志管理类
-- Author:  Jackie Liu
-- Date:    2016.03.31
-- Last:
-- Content:  统一处理Log。
--------------------------------------------------------------------------
local Log = { __cname = "Log" }

local ptf = ptf

local fileUtils = ptf.fileUtil
local LOG_CONF = ptf.conf.log

local logFunc = function(logLvl, loglvlflag, tag, ...)
    if logLvl >= LOG_CONF.LVL then
        local params = { ...}
        if #params == 0 then return end
        local logPrefix = "[" .. loglvlflag .. "]" .. "[" .. tag .. "]"
        local cntnts = { }
        local tmpTable = { }
        --        dump(params)
        for k, v in ipairs(params) do
            if type(v) == "table" then
                if #tmpTable == 0 then
                    cntnts[#cntnts + 1] = v
                else
                    cntnts[#cntnts + 1] = string.format(unpack(tmpTable))
                    cntnts[#cntnts + 1] = v
                    tmpTable = { }
                end
            else
                tmpTable[#tmpTable + 1] = v
            end
        end
        --        dump(tmpTable)
        if type(params[#params]) ~= "table" then
            cntnts[#cntnts + 1] = string.format(unpack(tmpTable))
        end
        --        dump(cntnts)
        Log._log(logPrefix, cntnts)
    end
end

function Log.ctor()

end

function Log.verbose(tag, ...)
    logFunc(ptf.contants.log.VERBOSE, "verbose", tag, ...)
end

function Log.debug(tag, ...)
    logFunc(ptf.contants.log.DEBUG, "debug", tag, ...)
end

function Log.info(tag, ...)
    logFunc(ptf.contants.log.INFO, "info", tag, ...)
end

function Log.warn(tag, ...)
    logFunc(ptf.contants.log.WARN, "warn", tag, ...)
end

function Log.error(tag, ...)
    logFunc(ptf.contants.log.ERROR, "error", tag, ...)
end

function Log.assert(tag, ...)
    logFunc(ptf.contants.log.ASSERT, "assert", tag, ...)
end

function Log._log(prefix, cntnts)
    if #cntnts == 0 then Log.warn(prefix, " null params") return end
    for k, v in ipairs(cntnts) do
        if type(v) == "table" then
            cntnts[k] = Log.dump(v, prefix, 15)
        else
            print(prefix .. " " .. v)
        end
    end
    -- 配置中已开启
    if LOG_CONF then
        if LOG_CONF.WRITE_LOCAL then
            Log._save(prefix, cntnts)
        end
        if LOG_CONF.UPLOAD_SERVER then
            Log._post(prefix, cntnts)
        end
    end
end

-- 保存日志到本地
function Log._save(prefix, cntnts)
    local filePath = cc.FileUtils:getInstance():getWritablePath() .. LOG_CONF.WRITE_PATH
    if filePath then
        if not fileUtils:isFileExist(filePath) then
            io.writefile(filePath, "")
        end
        if fileUtils:isFileExist(filePath) then
            local fileSize = io.filesize(filePath)
            if fileSize and(fileSize > LOG_CONF.WRITE_SIZE) then
                -- 超出日志文件规定大小，将被重置
                io.writefile(filePath, "", "w+")
            end
            local time = os.date("[%Y-%m-%d %H:%M:%S]", os.time())
            local output = nil
            if device.platform == "windows" or device.platform == "mac" then
                -- windows和mac上把堆栈打印出来，debug的性能非常低，在移动系统上最好不要使用
                --                output = { string.format("%s%s\n", time, string.trim(string.split(debug.traceback("", 5), "\n")[3])) }
                output = { }
            else
                output = { }
            end

            for k, v in pairs(cntnts) do
                if type(v) == "table" then
                    for k1, v1 in pairs(v) do
                        output[#output + 1] = string.format("%s%s\n", time, v1)
                    end
                else
                    output[#output + 1] = string.format("%s%s %s\n", time, prefix, v)
                end
            end
            --            dump(cntnts)
            --            dump(output)
            io.writefile(filePath, table.concat(output, ""), "a")
        else
            print("[Log._save] log file path is not founed.[%s]", filepath)
        end
    end
end

function Log._post(prefix, cntnts)
    --    local str = string.format(...)
    --    local xhr = cc.XMLHttpRequest:new()
    --    xhr.responseType = cc.XMLHTTPREQUEST_RESPONSE_STRING
    --    xhr:open(LOG_CONF.UPLOAD_PARAM.method, LOG_CONF.UPLOAD_PARAM.svrAddr)
    --    xhr:registerScriptHandler( function()
    --        if xhr.readyState == 4 and(xhr.status >= 200 and xhr.status < 207) then
    --            print("Log._post" .. xhr.response)
    --        else
    --            print("readyState of postLog is: ", xhr.readyState, "status of postLog is: ", xhr.status)
    --        end
    --    end )
    --    xhr:send("username=" .. LOG_CONF.UPLOAD_ACCOUNT.username .. "&info=" .. str .. "&psw=" .. LOG_CONF.UPLOAD_ACCOUNT.psw)
end

function Log._checkParam(methodname, ...)
    if # { ...} < 1 then
        print("******************WARNING_START")
        print("ptf.log." .. methodname .. " must get 2 params which the first is tag.")
        print(debug.traceback())
        print("******************WARNING_END")
        return false
    end
    return true
end

local function dump_value_(v)
    if type(v) == "string" then
        v = "\"" .. v .. "\""
    end
    return tostring(v)
end

function Log.dump(value, desciption, nesting)
    if type(nesting) ~= "number" then nesting = 3 end

    local lookupTable = { }
    local result = { }

    --    local traceback = string.split(debug.traceback("", 2), "\n")
    --    print("dump from: " .. string.trim(traceback[3]))

    local function dump_(value, desciption, indent, nest, keylen)
        desciption = desciption or "<var>"
        local spc = ""
        if type(keylen) == "number" then
            spc = string.rep(" ", keylen - string.len(dump_value_(desciption)))
        end
        if type(value) ~= "table" then
            result[#result + 1] = string.format("%s%s%s = %s", indent, dump_value_(desciption), spc, dump_value_(value))
        elseif lookupTable[tostring(value)] then
            result[#result + 1] = string.format("%s%s%s = *REF*", indent, dump_value_(desciption), spc)
        else
            lookupTable[tostring(value)] = true
            if nest > nesting then
                result[#result + 1] = string.format("%s%s = *MAX NESTING*", indent, dump_value_(desciption))
            else
                result[#result + 1] = string.format("%s%s = {", indent, dump_value_(desciption))
                local indent2 = indent .. "    "
                local keys = { }
                local keylen = 0
                local values = { }
                for k, v in pairs(value) do
                    keys[#keys + 1] = k
                    local vk = dump_value_(k)
                    local vkl = string.len(vk)
                    if vkl > keylen then keylen = vkl end
                    values[k] = v
                end
                table.sort(keys, function(a, b)
                    if type(a) == "number" and type(b) == "number" then
                        return a < b
                    else
                        return tostring(a) < tostring(b)
                    end
                end )
                for i, k in ipairs(keys) do
                    dump_(values[k], k, indent2, nest + 1, keylen)
                end
                result[#result + 1] = string.format("%s}", indent)
            end
        end
    end
    dump_(value, desciption, "- ", 2)

    for i, line in ipairs(result) do
        print(line)
    end
    return result
end

return Log