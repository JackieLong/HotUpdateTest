-------------------------------------------------------------------------
-- Title:           WebSocket(非阻塞)
-- Author:      Jackie Liu
-- Date:         2016/10/22 23:53:26
-- Desc:
-- 需要改进的地方：
-- 1、绑定Event的方法参照更新版本的bind方法
-- example：
-- local function openCallback()
--    print("socket成功打开")
-- end
-- local function messageCallback(msg)
--    print("收到的数据:" .. tostring(msg))
-- end
-- local function closeCallback()
--    print("socket已经关闭")
-- end
-- local function errorCallback(msgError)
--    print("socket发生错误，错误信息:" .. tostring(msgError))
-- end
-- local ws = WebSocket:create("www.test.com", messageCallback, openCallback, closeCallback, errorCallback)
-- local data = {
--    "这是",
--    "二进制",
--    "数据"
-- }
-- ws:send2Msg(data)
-- ws:sendMsg("socket数据")
-- ws:close()
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
local WebSocket = class("WebSocket")
local TAG = "WebSocket"
local log = ptf.log

function WebSocket:ctor(url, msgCb, openCb, closeCb, errorCb)
    self.instance = nil
    self.msgCb = nil
    self.openCb = nil
    self.closeCb = nil
    self.errorCb = nil

    self.instance = cc.WebSocket:create(url)
    self.msgCb = msgCb
    self.openCb = openCb
    self.closeCb = closeCb
    self.errorCb = errorCb
    if self.instance then
        self.instance:registerScriptHandler(handler(self, self._onOpen), cc.WEBSOCKET_OPEN)
        self.instance:registerScriptHandler(handler(self, self._onMessage), cc.WEBSOCKET_MESSAGE)
        self.instance:registerScriptHandler(handler(self, self._onClose), cc.WEBSOCKET_CLOSE)
        self.instance:registerScriptHandler(handler(self, self._onError), cc.WEBSOCKET_ERROR)
    end
end

function WebSocket:isReady()
    return self.instance and self.instance:getReadyState() == cc.WEBSOCKET_STATE_OPEN
end

-- 发送2进制数据
function WebSocket:send2Msg(data)
    if not self:isReady() then
        log.warn(TAG, "socket isn't ready for now!")
        return false
    end
    if type(data) == "table" then
        self.instance:sendString(string.char(unpack(data)))
    else
        self.instance:sendString(string.char(data))
    end
    return true
end

function WebSocket:sendMsg(data)
    if not self:isReady() then
        log.warn(TAG, "socket isn't ready for now!")
        return false
    end
    self.instance:sendString(tostring(data))
    return true
end

function WebSocket:close()
    if self.instance then
        self.instance:close()
        self.msgCb = nil
        self.openCb = nil
        self.closeCb = nil
        self.errorCb = nil
    end
    --    self.instance:removeAllEventListeners()
    self.instance = nil
end

function WebSocket:_onOpen()
    log.debug(TAG, "socket open success")
    if self.openCb then self.openCb() end
end

function WebSocket:_onMessage(message)
    log.debug(TAG, "socket receive msg")
    if self.msgCb then self.msgCb(message) end
end

function WebSocket:_onClose()
    log.debug(TAG, "socket is closed")
    if self.closeCb then self.closeCb() end
end

function WebSocket:_onError(error)
    log.debug(TAG, "socket got a error[%s]", error)
    if self.errorCb then self.errorCb() end
end

return WebSocket
