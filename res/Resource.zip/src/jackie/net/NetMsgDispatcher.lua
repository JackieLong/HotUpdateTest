-------------------------------------------------------------------------
-- Title:
-- Author:           Jackie Liu
-- Date:              2016/10/23 12:43:41
-- Desc:
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
local NetMsgDispatcher = class("NetMsgDispatcher")
local TAG = "NetMsgDispatcher"
local xpcall = xpcall
local import = import
-- 消息序列化协议
local sproto = import(".sproto.sproto")
local sprotoparser = import(".sproto.sprotoparser")

function NetMsgDispatcher:ctor(c2s, s2c)
    -- 响应消息处理
    self._responseHandler = nil
    -- 请求处理
    self._requestHandler = nil
    -- 会话ID：标识每次请求。请求一次后都+1
    self._session_id = 0
    -- key是session，value是protoname
    self._sessionid_protoname_map = { }
    -- 消息监听句柄：唯一确定一个监听
    self._msg_listener_handle = 0
    -- 注册消息监听，以protoname分组，每组对应protoname消息的所有listener，key是handle，value是listener
    self._msg_listeners = { }

    self:updateProtocol(c2s, s2c)
end

function NetMsgDispatcher:updateProtocol(c2s, s2c)
    if not s2c or s2c == "" then
        ptf.log.warn("NetMsgDispatcher:updateProtocol", "s2c proto is nil now")
    else
        xpcall( function()
            self._responseHandler = sproto.new(sprotoparser.parse(s2c)):host "package"
        end , function(msg)
            ptf.log.__G__TRACKBACK__(msg)
        end )
    end
    if not c2s or c2s == "" then
        ptf.log.warn("NetMsgDispatcher:updateProtocol", "c2s proto is nil now")
    else
        xpcall( function()
            self._requestFunc = self._responseHandler:attach(sproto.new(sprotoparser.parse(c2s)))
        end , function(msg)
            print(5 / nil)
            ptf.log.__G__TRACKBACK__(msg)
        end )
    end
    return self
end

-- 发送请求的汇总接口，客户端所有的请求都将经过这一步
function NetMsgDispatcher:send(protoname, args)
    assert(protoname and args, "send_request_error: null protoname or args")
    self._session_id = self._session_id + 1
    self._sessionid_protoname_map[self._session_id] = protoname
    --    ptf.log.debug(TAG, "protoname:%s，sessionid:%d", protoname, self._session_id)
    return self._requestFunc(protoname, args, self._session_id)
    --    return sproto.tostring(sproto.stringpack(self._requestFunc(protoname, args, self._session_id)))
end

function NetMsgDispatcher:dispatchResponseMsg(msg)
    local Type, protoname, msgTable = self._responseHandler:dispatch(string.char(unpack(msg)))
    if Type == "REQUEST" then
        -- 推送消息
        ptf.log.debug(TAG, "push msg[%s]:", protoname, msgTable)
    else
        -- 请求的对应的响应消息，protoname其实是sessionID，根据表找到对应的protoname
        local fuck = assert(self._sessionid_protoname_map[protoname], "error,protoname is not found by sessionid")
        self._sessionid_protoname_map[protoname] = nil
        protoname = fuck
        fuck = nil
        ptf.log.debug(TAG, "response msg[%s]:", protoname, msgTable)
    end
    -- 回调所有注册的listener
    if self._msg_listeners[protoname] then
        for handle, listener in pairs(self._msg_listeners[protoname]) do
            if listener then
                listener(protoname, msgTable)
            end
        end
    end
end

-- 注册消息监听
function NetMsgDispatcher:registerMsgListener(protoname, callback)
    assert(protoname and callback)
    self._msg_listener_handle = self._msg_listener_handle + 1
    if not self._msg_listeners[protoname] then
        self._msg_listeners[protoname] = { }
    end
    self._msg_listeners[protoname][self._msg_listener_handle] = callback
    return self._msg_listener_handle
end

-- 注销消息监听
function NetMsgDispatcher:unregisterMsgListener(handle)
    for protoname, listeners in pairs(self._msg_listeners) do
        for _handle, listener in pairs(listeners) do
            if _handle > handle then
                -- 不可能在这组，到其他组去循环吧
                break
            elseif _handle == handle then
                -- 找到了
                listeners[handle] = nil
                ptf.log.debug(TAG, "remove msg listener:name:%s", protoname)
                return
            end
        end
    end
end

return NetMsgDispatcher