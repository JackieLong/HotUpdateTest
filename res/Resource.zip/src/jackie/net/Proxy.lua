-------------------------------------------------------------------------
-- Title:           网络消息代理基类，负责客户端对于后台消息的接收和处理
-- Author:      Jackie Liu
-- Date:         2016/10/28 21:21:30
-- Desc:
-- 用法：
--    实现filterMsg方法。决定proxy会接收哪些事件。
--    实现msgReceived方法，决定proxy会怎么处理消息
--    start启动proxy，
--    stop停用proxy，
--    request发送请求
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
local Proxy = class("Proxy")
local TAG = "Proxy"

local netMgr = ptf.net.netMgr
local assert = assert
local table = table
-- key：proxy的name
-- value：proxy注册的所有msg的listener的handle，数组
local proxyRegMsgHandleMap = { }

function Proxy:ctor()
end

-- 返回需要监听的消息即可
function Proxy:filterMsg()
    --    return { "handshake", "login", "register", "unregister" }
    assert(false, "Proxy:registerMsgListener must be implemented")
end

-- 收到消息后，对消息的处理，然后返回处理后的消息。这个消息将被广播出去
-- 也可以不实现这个方法，代表，收到消息不需要进行处理直接发送出去。
function Proxy:msgReceived(name, msgTable)

end

function Proxy:start()
    local msgListenerHandles = Proxy._getMsgListenerHandlesByProxy(self)

    -- 注销之前已经注册的msg
    if #msgListenerHandles > 0 then
        table.map(msgListenerHandles, function(handle, k)
            netMgr:unregisterMsgListener(handle)
        end )
    end

    table.walk(self:filterMsg(), function(name, k)
        msgListenerHandles[#msgListenerHandles + 1] = netMgr:registerMsgListener(name, handler(self, self._msgReceived))
    end )
    return self
end

function Proxy:stop()
    local msgListenerHandles = Proxy._getMsgListenerHandlesByProxy(self)
    table.map(msgListenerHandles, function(handle, k)
        netMgr:unregisterMsgListener(handle)
    end )
    return self
end

function Proxy:request(name, args)
    ptf.log.debug(TAG, "send request[%s]:", name, args)
    netMgr:send(name, args or { })
    return self
end

function Proxy:_msgReceived(name, msgTable)
    ptf.log.debug(TAG, "receive msg[%s]", name)
    self:msgReceived(name, msgTable)
end

-- 获取msg handle列表，通过proxy名字
function Proxy._getMsgListenerHandlesByProxy(proxy)
    if not proxyRegMsgHandleMap[proxy.__cname] then
        proxyRegMsgHandleMap[proxy.__cname] = { }
    end
    return proxyRegMsgHandleMap[proxy.__cname]
end

return Proxy