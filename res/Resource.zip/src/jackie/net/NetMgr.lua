-------------------------------------------------------------------------
-- Title:           socket网络通讯管理
-- Author:      Jackie Liu
-- Date:         2016/10/22 23:55:37
-- Desc:
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
local NetMgr = class("NetMgr")
local TAG = "NetMgr"

local assert = assert
local import = import

local NetMsgDispatcher = import(".NetMsgDispatcher")

function NetMgr:ctor()
    -- 消息分发器，包括请求的消息，收到的消息
    self._netMsgDispatcher = nil
    -- 保存消息协议
    self._protocols = { c2s = { }, s2c = { } }

    -- 带端口的服务器地址
    self._svrAddr = nil
    self._webSocketInstance = nil

    self._onReceivedCb = nil
    self._onConnectedCb = nil
    -- 如果发生了connectError，可以执行顺序是：connectError然后是connectClosed
    self._onConnectClosedCb = nil
    self._onConnectErrorCb = nil
end

-- 加载模块modulename的消息协议。如斗牛的消息协议
-- modulename仅用于日志打印。
function NetMgr:loadProto(protocol, modulename)
    assert(protocol and modulename, "[NetMgr:loadProto] invalid params")
    local flagNeedDoc2s = not not protocol.c2s
    local flagNeedDos2c = not not protocol.s2c

    if protocol.c2s then
        for k, proto in ipairs(self._protocols.c2s) do
            if proto == protocol.c2s then
                flagNeedDoc2s = false
            end
        end
    end
    if protocol.s2c then
        for k, proto in ipairs(self._protocols.s2c) do
            if proto == protocol.s2c then
                flagNeedDos2c = false
            end
        end
    end
    if flagNeedDoc2s or flagNeedDos2c then
        if flagNeedDoc2s then
            self._protocols.c2s[#self._protocols.c2s + 1] = protocol.c2s
        end
        if flagNeedDos2c then
            self._protocols.s2c[#self._protocols.s2c + 1] = protocol.s2c
        end
        if not self._netMsgDispatcher then
            self._netMsgDispatcher = NetMsgDispatcher:create(table.concat(self._protocols.c2s, ""), table.concat(self._protocols.s2c, ""))
        else
            self._netMsgDispatcher:updateProtocol(table.concat(self._protocols.c2s, ""), table.concat(self._protocols.s2c, ""))
        end
    end
    if flagNeedDoc2s then
        ptf.log.debug(TAG, "load %s c2s protocol successfully.", modulename)
    elseif protocol.c2s then
        ptf.log.debug(TAG, "load %s c2s protocol failed.", modulename)
    end
    if flagNeedDos2c then
        ptf.log.debug(TAG, "load %s s2c protocol successfully.", modulename)
    elseif protocol.s2c then
        ptf.log.debug(TAG, "load %s s2c protocol failed.", modulename)
    end
    return self
end

-- 卸载协议
-- modulename:模块名如斗牛等。仅用于日志打印
function NetMgr:unloadProto(protocol, modulename)
    assert(protocol and modulename, "[NetMgr:unloadProto] invalid params")
    local flagNeedDoc2s, flagNeedDos2c = false, false
    if protocol.c2s then
        for k, proto in ipairs(self._protocols.c2s) do
            if protocol.c2s == proto then
                table.remove(self._protocols.c2s, k)
                flagNeedDoc2s = true
                break
            end
        end
    end
    if protocol.s2c then
        for k, proto in ipairs(self._protocols.s2c) do
            if protocol.s2c == proto then
                table.remove(self._protocols.s2c, k)
                flagNeedDos2c = true
                break
            end
        end
    end
    if flagNeedDoc2s then
        ptf.log.debug(TAG, "unload %s c2s proto successfully.", modulename)
    elseif protocol.c2s then
        ptf.log.error(TAG, "unload %s c2s proto failed.", modulename)
    end
    if flagNeedDos2c then
        ptf.log.debug(TAG, "unload %s s2c proto successfully.", modulename)
    elseif protocol.s2c then
        ptf.log.error(TAG, "unload %s s2c proto failed.", modulename)
    end
    if flagNeedDoc2s or flagNeedDos2c then
        self._netMsgDispatcher:updateProtocol(table.concat(self._protocols.c2s, ""), table.concat(self._protocols.s2c, ""))
    end
    return self
end

-- 打印当前已经加载了的消息协议
function NetMgr:dumpProtoInfo()
    if self._protocols.c2s then
        ptf.log.debug(TAG, "***************current c2s protocol:    start")
        for k1, v1 in ipairs(self._protocols.c2s) do
            ptf.log.debug(TAG, string.format("[%d]%s", k1, string.gsub(v1, "\n", "")))
        end
        ptf.log.debug(TAG, "***************current c2s protocol:    end")
    end
    if self._protocols.s2c then
        ptf.log.debug(TAG, "***************current s2c protocol:   start")
        for k1, v1 in ipairs(self._protocols.s2c) do
            ptf.log.debug(TAG, string.format("[%d]%s", k1, string.gsub(v1, "\n", "")))
        end
        ptf.log.debug(TAG, "***************current s2c protocol:    end")
    end
end

-- 连接服务器
function NetMgr:connect(svrAddr, onConnectedCb, onReceivedCb, onConnectClosedCb, onConnectErrorCb)
    if self._webSocketInstance then
        ptf.log.debug(TAG, "there is already a socket connection(%s)，disconnect it first", self._svrAddr)
        self._webSocketInstance:close()
    end
    assert(svrAddr, "invalid connect params")
    self._svrAddr = svrAddr
    self._onReceivedCb = onReceivedCb or self._onReceivedCb
    self._onConnectedCb = onConnectedCb or self._onConnectedCb
    self._onConnectClosedCb = onConnectClosedCb or self._onConnectClosedCb
    self._onConnectErrorCb = onConnectErrorCb or self._onConnectErrorCb
    self._webSocketInstance = assert(ptf.net.webSocket:create(self._svrAddr, handler(self, self._onReceived), handler(self, self._onConnected), handler(self, self._onConnectClosed), handler(self, self._onConnectError)), "create socket failed")
    return self
end

-- 发送请求消息
function NetMgr:send(name, args)
    local package = self._netMsgDispatcher:send(name, args)
    --    ptf.log.debug(TAG, "send(%s)package size:%d", name, #package)
    self._webSocketInstance:sendMsg(package)
end

-- 注册消息监听
function NetMgr:registerMsgListener(protoname, callback)
    if type(protoname) == "string" then
        return self._netMsgDispatcher:registerMsgListener(protoname, callback)
    else
        local handles = { }
        for name, callback in pairs(protoname) do
            handles[#handles + 1] = self:registerMsgListener(name, callback)
        end
        return handles
    end
end

-- 注销消息监听
function NetMgr:unregisterMsgListener(handle)
    self._netMsgDispatcher:unregisterMsgListener(handle)
end

-- 接受到服务器发来数据的回调
function NetMgr:_onReceived(msg)
    --    ptf.log.debug(TAG, "socket got msg:")
    if self._onReceivedCb then self._onReceivedCb() end
    self._netMsgDispatcher:dispatchResponseMsg(msg)
end

-- 和服务器连接成功回调
function NetMgr:_onConnected()
    if self._onConnectedCb then self._onConnectedCb() end
end

-- 关闭和服务器连接的回调
function NetMgr:_onConnectClosed()
    if self._onConnectClosedCb then self._onConnectClosedCb() end
    self._webSocketInstance = nil
end

-- 和服务器连接出错的回调
function NetMgr:_onConnectError(errorMsg)
    if self._onConnectErrorCb then self._onConnectErrorCb() end
end

return NetMgr