-------------------------------------------------------------------------
-- Title:           网络模块
-- Author:        Jackie Liu
-- CreateDate:    2016/09/11 18:33:36
-- Desc:
--            LuaSocket
--            WebSocket
--            srp
--            aes加密
--            消息序列化协议
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
ptf.net = { }

-- 封装好的websocket
ptf.net.webSocket = import(".WebSocket")

--    -- 封装的非阻塞式的luasocket
--    ptf.net.socketTCP = import("net.SocketTCP")

-- 加密协议
ptf.net.srp = require "srp"
ptf.net.aes = require "aes"

ptf.net.print_r = import(".sproto.print_r")

-- http get请求
ptf.net.httpReqGet = function(url, callback, params)
    return net.httpReq("GET", url, callback, params)
end

-- http post请求
ptf.net.httpReqPost = function(url, callback, params)
    return net.httpReq("POST", url, callback, params)
end

-- 用法：
-- 发送HTTP，GET方式请求www.test.com?param1=1&param2=2
-- httpReq("GET", "www.test.com", function(success, ret)
--    if success then--成功了
--    else--失败了
--    end
-- end , { param1 = 1, param2 = 2 })
ptf.net.httpReq = function(method, url, callback, params)
    local ret = cc.XMLHttpRequest:new()
    ret.responseType = cc.XMLHTTPREQUEST_RESPONSE_STRING
    if next(params) then
        local flag = true
        for k, v in pairs(params) do
            if flag then
                url = url + "?" + k + "=" + v
            else
                url = url + "&" + k + "=" + v
            end
        end
    end
    ret:open(method, url)
    local function onReadyStateChanged()
        if ret.readyState == 4 and(ret.status >= 200 and ret.status < 207) then
            if callback then callback(false, ret) end
        else
            if callback then callback(true, ret) end
        end
        ret:unregisterScriptHandler()
    end
    ret:registerScriptHandler(onReadyStateChanged)
    ret:send()
end

ptf.net.create_client_key = function()
    return ptf.net.srp.create_client_key()
end

ptf.net.create_client_session_key = function(userid, password, salt, uprivate_key, upublic_key, server_pub)
    return ptf.net.srp.create_client_session_key(userid, password, salt, uprivate_key, upublic_key, server_pub)
end

ptf.net.encrypt = function(challenge, key)
    return ptf.net.aes.encrypt(challenge, key)
end

ptf.net.netMgr = import(".NetMgr"):create()

ptf.net.proxy = import(".Proxy")
