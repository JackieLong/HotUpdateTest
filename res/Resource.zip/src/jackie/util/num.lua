local Util = ptf.util

-- example:
-- Util.formatNum(9876543210,4) = "98.76亿"
-- Util.formatNum(9876543210,5) = "98.765亿"
-- Util.formatNum(9876543210,2) = "98亿"
function Util.formatNum(num, bits)
    bits = bits or 4
    if not target then
        return ""
    end
    -- 位
    local ret = ""
    local strNum = "" .. target
    local posDot = string.find(strNum, "%.")
    posDot = posDot or #strNum + 1
    -- 去掉小数点
    strNum = string.gsub(strNum, "%.", "")
    local bit = #string.sub(strNum, 1, posDot - 1) -1
    local Yis = math.floor(bit / 8)
    local Wans = math.floor((bit % 8) / 4)
    local tmp = bit + 1 - Yis * 8 - Wans * 4
    -- 整数部分
    local tmpLen = 1
    while (tmpLen < bits + 1) and(tmpLen <= #strNum) do
        if tmp == #ret then
            ret = ret .. '.'
        else
            ret = ret .. string.sub(strNum, tmpLen, tmpLen)
            tmpLen = tmpLen + 1
        end
    end
    if ret[#ret] == "." then
        ret = string.sub(ret, 1, #ret - 1)
    end
    local posDot = string.find(ret, "%.")
    if posDot then
        while ((string.sub(ret, #ret, #ret) == '0' and posDot < #ret) or string.sub(ret, #ret, #ret) == '.') do
            ret = string.sub(ret, 1, #ret - 1)
        end
    end
    while Wans > 0 do
        ret = ret .. "万"
        Wans = Wans - 1
    end
    while Yis > 0 do
        ret = ret .. "亿"
        Yis = Yis - 1
    end
    return ret
end