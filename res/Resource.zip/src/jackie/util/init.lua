-------------------------------------------------------------------------
-- Title:             工具模块
-- Author:        Jackie Liu
-- CreateDate:    2016/09/11 18:40:29
-- Desc:            包含了一些通用的方便的函数，熟悉一下非常有必要
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
ptf.util = { }

local util = ptf.util
local import = import

import(".bridge2Cpp")
import(".num")
import(".str")
import(".table")
import(".ui")

-- 延迟执行
util.delayDo = function(delay, callback)
    local scheduler, entryId = ptf.scheduler, nil
    entryId = scheduler:scheduleScriptFunc( function(dt)
        scheduler:unscheduleScriptEntry(entryId)
        callback()
    end , delay, false)
    return entryId
end

util.unschedule = function(entryId)
    ptf.scheduler:unscheduleScriptEntry(entryId)
end

-- 这个东东你不要错过哦~~，made by Jackie2016/04/12
-- 说明：监听数据的变化，用于UI和data的完美分离，你懂的。
-- 使用：
--    local dataListener = bindDataListener({money = function(oldVal,newVal)
--    print("this is old value of money:" .. oldVal)
--    print("this is now value of money:" .. newVal)
-- end})
util.bindDataListener = function(data, listeners)
    if data and not listeners then
        listeners = data
        data = { _cacheData = { } }
    else
        local old = clone(data)
        table.map(data, function(v, k) return nil end)
        data._cacheData = old
    end
    setmetatable(data, data)
    data.__index = function(t, k) return rawget(t, "_cacheData")[k] end
    data.__newindex = function(t, k, v)
        if listeners and listeners[k] then
            local old = rawget(t, "_cacheData")[k]
            rawget(t, "_cacheData")[k] = v
            listeners[k](old, v)
        else
            rawget(t, "_cacheData")[k] = v
        end
    end
    return data
end