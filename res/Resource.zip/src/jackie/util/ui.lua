local Util = ptf.util
local ptf = ptf

-- node置灰，passchild子节点是否也需要
function Util.changeGray(node, passChild)
    passChild = passChild == nil and true or checkbool(passChild)
    node:setGLProgramState(cc.GLProgramState:getOrCreateWithGLProgramName("ShaderUIGrayScale"))
    if checkbool(passChild) then
        for k, v in pairs(node:getChildren()) do
            Util.enableGray(v, passChild)
        end
    end
end

-- 让node及其子节点一起透明度变化
function Util.cascadeOpacity(node, enabled)
    enabled = enabled == nil and true or checkbool(enabled)
    node:setCascadeOpacityEnabled(enabled)
    for k, v in pairs(node:getChildren()) do
        Util.cascadeOpacity(v, enabled)
    end
end

-- 让node和子节点一起颜色变化
function Util.cascadeColor(node, enabled)
    enabled = enabled == nil and true or checkbool(enabled)
    node:setCascadeColorEnabled(enabled)
    for k, v in pairs(node:getChildren()) do
        Util.cascadeColor(v, enabled)
    end
end

-- 添加物理返回键的事件监听，生命周期绑定到node节点上
function Util.setKeyBackListener(node, callback)
    Util.setKeyPadListener(node, function(keyCode, event)
        if keyCode == cc.KeyCode.KEY_BACK then
            if callback then
                callback(event)
            end
        end
    end )
end

-- 添加监听键盘按键事件监听，生命周期已绑定到node节点上。
-- releasedCallback：释放键盘按钮时的回调
-- pressedCallback：键盘按下时候的回调
function Util.setKeyPadListener(node, releasedCallback, pressedCallback)
    local listenerReleased = nil
    local listenerPressed = nil
    if releasedCallback then
        listenerReleased = cc.EventListenerKeyboard:create()
        listenerReleased:registerScriptHandler(releasedCallback, cc.Handler.EVENT_KEYBOARD_RELEASED)
    end
    if pressedCallback then
        listenerPressed = cc.EventListenerKeyboard:create()
        listenerPressed:registerScriptHandler(pressedCallback, cc.Handler.EVENT_KEYBOARD_PRESSED)
    end

    local eventDispatcher = node:getEventDispatcher()
    if listenerReleased then
        eventDispatcher:addEventListenerWithSceneGraphPriority(listenerReleased, node)
    end
    if listenerPressed then
        eventDispatcher:addEventListenerWithSceneGraphPriority(listenerPressed, node)
    end
end

function Util.isDirectParent(node, parent)
    if not node or not parent then
        ptf.log.error("Util.isDirectParent", "invalid params")
        return
    end
    local tmp = node:getParent()
    while tmp do
        if tmp == parent then return true end
        tmp = tmp:getParent()
    end
end

function Util.drawLine(src, dest, color, lineWidth)
    color = color or cc.c4f(1, 1, 1, 0.5)
    lineWidth = lineWidth or 1
    local ret = cc.DrawNode:create()
    ret:setLineWidth(lineWidth)
    return ret:drawLine(src, dest, color)
end

-- 让node节点缩放成和屏幕一样大小
function Util.fillScrn(node)
    return node:setScale(math.max(ptf.winSize.width / node:width(), ptf.winSize.height / node:height()))
end

function Util.traverseNode(node, callback, uiTable)
    local name = node:getName()
    if uiTable then
        assert(uiTable[name], "node named " .. name .. " already exists")
        uiTable[name] = node
    end
    callback(name, node)
    for idx, child in pairs(node:getChildren()) do
        Util.traverseNode(child, callback)
    end
end