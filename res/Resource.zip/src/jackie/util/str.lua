-------------------------------------------------------------------------
-- Desc:
-- Author:        Jackie Liu
-- CreateDate:    2016/08/23 11:12:45
-- Revisions:     Jackie Liu(2016/08/23 11:12:45) create this file
-- Purpose:

-- Copyright (c)wawagame Entertainment All right reserved.
-------------------------------------------------------------------------
ptf.util.serialize = function(obj)
    local lua = ""
    local t = type(obj)
    if t == "number" then
        lua = lua .. obj
    elseif t == "boolean" then
        lua = lua .. tostring(obj)
    elseif t == "string" then
        lua = lua .. string.format("%q", obj)
    elseif t == "table" then
        lua = lua .. "{\n"
        for k, v in pairs(obj) do
            lua = lua .. "[" .. ptf.util.serialize(k) .. "]=" .. ptf.util.serialize(v) .. ",\n"
        end
        local metatable = getmetatable(obj)
        if metatable ~= nil and type(metatable.__index) == "table" then
            for k, v in pairs(metatable.__index) do
                lua = lua .. "[" .. ptf.util.serialize(k) .. "]=" .. ptf.util.serialize(v) .. ",\n"
            end
        end
        lua = lua .. "}"
    elseif t == "nil" then
        return nil
    else
        error("can not serialize a " .. t .. " type.")
    end
    return lua
end

-- 遍历utf8字符串，callback = function(startIdx,len) return true end
-- startIdx遍历到某个字符时的起始idx，len为字节长度，
-- return true停止遍历，false继续遍历
ptf.util.travelUtf8Str = function(str, callback)
    if str then
        local ret = { }
        local idx = 1
        -- utf8编码，高位1的位置表示字符所占字节数
        local utf8Sets = { 0, 0x11000000, 0x11100000, 0x11110000, 0x11111000, 0x11111100 }
        while idx <= #str do
            local tmp = string.byte(str, idx)
            local i = #utf8Sets
            while utf8Sets[i] do
                if tmp >= utf8Sets[i] then
                    -- ret[idx] = i
                    -- ret[#ret + 1] = { k = idx, v = i }
                    if callback(idx, i) then return end
                    idx = idx + i
                    break
                end
                i = i - 1
            end
        end
    end
end

-- 获取target中不超过len长度的字串。规定：一个多字节字符占2个长度，单个字节字符占1个长度。
ptf.util.subUtf8Str = function(target, maxLen)
    local tmpLen = 0
    local tmpAdapter = 0
    local ret = nil
    ptf.util.travelUtf8Str(target, function(start, len)
        if tmpAdapter +(len > 1 and 2 or 1) > maxLen then
            ret = string.sub(target, 1, tmpLen)
            return true
        end
        tmpLen = tmpLen + len
        tmpAdapter = tmpAdapter +(len > 1 and 2 or 1)
    end )
    return ret or target
end