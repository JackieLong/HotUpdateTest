-------------------------------------------------------------------------
-- Author:      Jackie
-- Date:        2017-05-10 10:37:30
-- Desc:
-- Revisions:         Jackie create this file at 2017-05-10 10:37:30
-- Copyright (c) 2017 FengYun Game
-------------------------------------------------------------------------
-- C++层需要lua做一些事情，比如显示界面等。name用来区分要干嘛，...是可能需要传的参数。
-- lua具体逻辑处请注册好事件接收。可以参考麻将反馈界面
cc.exports.onNeedLuaDo = function(name, ...)
    return ptf.util.runFuncUsedByCpp(name, ...)
end

-- 注册函数，C++调用luado即可执行
local luaFuncRegistered = { }

ptf.util.registerFuncUsedByCpp = function(eventName, func)
    assert(eventName and func and not luaFuncRegistered[eventName], string.format("already reigster func named %s", eventName))
    luaFuncRegistered[eventName] = func
end

ptf.util.unregisterFuncUsedByCpp = function(eventName)
    luaFuncRegistered[eventName] = nil
end

-- ...：就是函数的参数列表
ptf.util.runFuncUsedByCpp = function(name, ...)
    if not luaFuncRegistered[name] then
        printError("lua func named %s is not registered", name)
    else
        return luaFuncRegistered[name](...)
    end
end

