-------------------------------------------------------------------------
-- Title:           对Table的一些扩展
-- Author:        Jackie Liu
-- CreateDate:    2016/10/15 21:56:58
-- Desc:
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
-- 对table.map的扩展，对table下的所有表里的非table元素进行遍历
local _traverse = nil
_traverse = function(t, callback, flag)
    for k, v in pairs(t) do
        if type(v) == "table" then
            table.walk(v, function(v1, k1)
                if type(v1) == "table" then
                    _traverse(v1, callback)
                else
                    if flag then
                        v[k1] = callback(v1, k1)
                    else
                        callback(v1, k1)
                    end
                end
            end )
        else
            if flag then
                t[k] = callback(v, k)
            else
                callback(v, k)
            end
        end
    end
end

ptf.util.mapEx = function(table, callback)
    _traverse(table, callback, true)
end

-- 对table.walk的扩展，对table下的所有表里的非table元素进行遍历
ptf.util.walkEx = function(table, callback)
    _traverse(table, callback, false)
end