-------------------------------------------------------------------------
-- Title:           适用于开发2D游戏的lua框架
-- Author:        Jackie Liu
-- CreateDate:    2016/09/11 18:45:42
-- Desc:
--            1、最初目的是创作者为了快速开发棋牌类游戏，
--            2、创作之时，基于cocos2dx 3.12版本。基于其他版本，可能需要进行一定程度的修改
--            3、创作者虽然实力有限，但也投入了巨大精力才完成，如有幸被借鉴，请注明创作者博客http://my.csdn.net/jacikeliu
--            4、欢迎交流探讨，QQ：741212080。
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
local cc = cc
local device = device
local ptf = ptf

-- 下面这些是为了便于访问
ptf.director = cc.Director:getInstance()
ptf.userDefault = cc.UserDefault:getInstance()
ptf.fileUtil = cc.FileUtils:getInstance()
ptf.textureCache = cc.Director:getInstance():getTextureCache()
ptf.scheduler = cc.Director:getInstance():getScheduler()
ptf.glView = cc.Director:getInstance():getOpenGLView()
ptf.winSize = cc.Director:getInstance():getWinSize()
ptf.visibleSize = cc.Director:getInstance():getVisibleSize()
ptf.visibleOrigin = cc.Director:getInstance():getVisibleOrigin()

ptf.luaBinding = ptf.LuaBinding:getInstance()

-- 常量
ptf.contants = nil
-- 配置模块
ptf.conf = nil
-- 工具模块
ptf.util = nil
-- 日志模块
ptf.log = nil
-- 数理模块
ptf.math = nil
-- 持久化存储模块,file
ptf.storage = nil
-- 音频模块
ptf.audio = nil
-- 网络模块
ptf.net = nil
-- 跨平台处理模块
ptf.patform = nil
-- UI模块
ptf.ui = nil

-- 广播
ptf.broadcast = cc.bind( { }, "event")

-- 常量
ptf.contants = import(".conf.contants")

-- 配置模块
ptf.conf = import(".conf.config")

-- 工具模块
import(".util.init")

-- 日志模块
import(".log.init")

-- 持久化存储模块,userdeault,file
import(".storage.init")

-- 音频模块
import(".audio.init")

-- 网络模块
import(".net.init")

-- 跨平台处理模块
import(".platform.init")

-- UI模块
import(".ui.init")

ptf.director:setDisplayStats(CC_SHOW_FPS)

-- 设置显示窗口参数和帧率
if ptf.conf.FRAME_RATIO then
    ptf.director:setAnimationInterval(1.0 / ptf.conf.FRAME_RATIO)
end

-- 资源缩放因子
if ptf.conf.DESIGN_SIZE and CC_DESIGN_RESOLUTION then
    if CC_DESIGN_RESOLUTION.autoscale == "FIXED_HEIGHT" then
        ptf.director:setContentScaleFactor(ptf.conf.DESIGN_SIZE.height / CC_DESIGN_RESOLUTION.height)
    elseif CC_DESIGN_RESOLUTION.autoscale == "FIXED_HEIGHT" then
        ptf.director:setContentScaleFactor(ptf.conf.DESIGN_SIZE.width / CC_DESIGN_RESOLUTION.width)
    end
end

-- 屏幕缩放
if device.platform == "windows" and ptf.conf.FRAME_ZOOM_FACTOR then
    ptf.glView:setFrameZoomFactor(ptf.conf.FRAME_ZOOM_FACTOR)
end