-------------------------------------------------------------------------
-- Desc:          UI模块，根据传入的配置生成相应的UI，View或者单个节点都可以
-- Author:        Jackie Liu
-- ModifyDate:    2016/07/22 11:11:00
-- Purpose:
--        -- 样式一
--        local style =
--        {
--            {
--                class = "Btn",
--                name = "btn1",
--                normal = "1.png",
--                selected = "2.png",
--                disabled = "3.png",
--                audio_down = "m1 (1).mp3",
--                audio_up = "m1 (2).mp3",
--                ani_down = function(sender) return cc.FadeOut:create(0.2) end,
--                ani_up = function(sender) return cc.FadeIn:create(0.2) end,
--                offset = cc.p(100,100),
--                parent = self
--            },
--            {
--                class = "Label",
--                name = "Label1",
--                sysFnt = "Arial",
--                fntSize = 50,
--                fntClr = cc.c3b(100,200,200),
--                right = "btn1",
--                top = "btn1",
--                txt = "fuckeryou",
--                parent = self
--            }
--        }
--        --    conf =
--        --    {
--        --        btn1 = 0x123f4e
--        --    }
--        local conf = ptf.ui.createUI(style)
--        -- 样式二
--        local style = {
--            class = "Btn",
--            name = "btn1",
--            normal = "1.png",
--            selected = "2.png",
--            disabled = "3.png",
--            audio_down = "m1 (1).mp3",
--            audio_up = "m1 (2).mp3",
--            ani_down = function(sender) return cc.FadeOut:create(0.2) end,
--            ani_up = function(sender) return cc.FadeIn:create(0.2) end,
--            offset = cc.p(100,100),
--            parent = self
--        }
--        --    btn = 0x123f4e
--        --    conf = {
--        --        btn1 = 0x123f4e
--        --    }
--        local btn, conf = ptf.ui.createUI(style)
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
local Parent = ptf.contants.ui.Parent
-- 注册的对象集合（包括创建函数，批量设置属性函数）
local registerNodeMap = { }
local setAttrByConfName = nil
local setAttrByConfNameOrObj = nil
local setExtAttr = nil
local rescurFunc = nil
local batchSetNodeAttrFunc = nil
local batchRegisterNodeMethod = nil

-- 设置attr值。
setAttrByConfName = function(cell, conf, funcname, ...)
    local isOK = true
    local params = { }
    for k, v in ipairs( { ...}) do
        if conf[v] ~= nil then
            params[#params + 1] = conf[v]
        else
            isOK = false
            break
        end
    end
    if isOK then
        cell[funcname](cell, unpack(params))
    end
end

setAttrByConfNameOrObj = function(view, cell, conf, funcname, param)
    if conf[param] then
        if type(conf[param]) == "userdata" then
            cell[funcname](cell, conf[param])
        elseif conf[param] == Parent then
            -- 位置
            cell[funcname](cell, cell:getParent())
        else
            cell[funcname](cell, view[conf[param]])
        end
    end
end


setExtAttr = function(cell, conf, viewContainer)
    setAttrByConfNameOrObj(viewContainer, cell, conf, 'parent', 'parent')

    setAttrByConfNameOrObj(viewContainer, cell, conf, 'top', 'top')
    setAttrByConfNameOrObj(viewContainer, cell, conf, 'top1', 'top1')
    setAttrByConfNameOrObj(viewContainer, cell, conf, 'bottom', 'bottom')
    setAttrByConfNameOrObj(viewContainer, cell, conf, 'bottom1', 'bottom1')
    setAttrByConfNameOrObj(viewContainer, cell, conf, 'left', 'left')
    setAttrByConfNameOrObj(viewContainer, cell, conf, 'left1', 'left1')
    setAttrByConfNameOrObj(viewContainer, cell, conf, 'right', 'right')
    setAttrByConfNameOrObj(viewContainer, cell, conf, 'right1', 'right1')
    setAttrByConfNameOrObj(viewContainer, cell, conf, 'centerX', 'centerX')
    setAttrByConfNameOrObj(viewContainer, cell, conf, 'centerY', 'centerY')
    setAttrByConfNameOrObj(viewContainer, cell, conf, 'topCenter', 'topCenter')
    setAttrByConfNameOrObj(viewContainer, cell, conf, 'leftCenter', 'leftCenter')
    setAttrByConfNameOrObj(viewContainer, cell, conf, 'rightCenter', 'rightCenter')
    setAttrByConfNameOrObj(viewContainer, cell, conf, 'bottomCenter', 'bottomCenter')
    setAttrByConfNameOrObj(viewContainer, cell, conf, 'center', 'center')
    setAttrByConfNameOrObj(viewContainer, cell, conf, 'innerBottom', 'innerBottom')
    setAttrByConfNameOrObj(viewContainer, cell, conf, 'innerTop', 'innerTop')
    setAttrByConfNameOrObj(viewContainer, cell, conf, 'innerLeft', 'innerLeft')
    setAttrByConfNameOrObj(viewContainer, cell, conf, 'innerRight', 'innerRight')
    setAttrByConfName(cell, conf, 'offsetX', 'offsetX')
    setAttrByConfName(cell, conf, 'offsetY', 'offsetY')
    setAttrByConfName(cell, conf, 'offset', 'offset')
end

rescurFunc = function(viewContainer, parent, conf, callback)
    local node = nil
    if conf.class then
        local isSame = false
        if conf._style and(conf._style.class == conf.class or not conf._style.class) then
            for k, v in pairs(conf._style) do
                conf[k] = v
            end
        end
        node = registerNodeMap[conf.class].createInstance(conf):setName(conf.name)
        -- 数组情况
        if parent then node:addTo(parent) end
        if callback then
            callback(node, conf)
        end
        if conf.name then
            viewContainer[conf.name] = node
            --            curParent.name = conf.name
        else
            viewContainer[#viewContainer + 1] = node
        end
        -- 样式模板
        if conf._style and(conf._style.class ~= conf.class) then
            ptf.ui.setNodeAttrs(node, conf._style.class, conf._style)
        end
        -- 统一设置node属性
        batchSetNodeAttrFunc(node, "Node", conf)
        local old = conf.parent
        if parent then conf.parent = nil end
        setExtAttr(node, conf, viewContainer)
        conf.parent = old
    end
    for k, v in ipairs(conf) do
        --        if node then
        --            v.parent = node
        --        end
        rescurFunc(viewContainer, node, v, callback)
    end
end

-- createUI要求Layout中的根节点是class。
ptf.ui.createUI = function(conf, callback)
    if conf.class then
        local container = { }
        rescurFunc(container, conf.parent and(container[conf.parent] or conf.parent), conf, callback)
        if conf.name then
            local ret = container[conf.name]
            return ret, container
        else
            local ret = container[1]
            return ret, container
        end
    else
        local container = { }
        rescurFunc(container, conf.parent and(container[conf.parent] or conf.parent), conf, callback)
        return container
    end
end

batchSetNodeAttrFunc = function(node, classname, conf)
    return registerNodeMap[classname].setAttr(node, conf)
end

batchRegisterNodeMethod = function(...)
    for k, v in ipairs( { ...}) do
        registerNodeMap[v.__cname] = v
    end
    return registerNodeMap
end

-- UI注册，加入的节点将能被createUI创建，可参照增加
-- 请牢记一个原则，新注册的Node传入的style/conf参数中的属性名也就是key值最好保证唯一特性，不要和node的一些属性重名。
-- 比如Btn的conf中有一个size，最好取名btnSize，增强识别性
ptf.ui.setAttr = setAttrByConfName

ptf.ui.setNodeAttrs = batchSetNodeAttrFunc

batchRegisterNodeMethod(
import(".bean.base.ClipNode"),
import(".bean.base.DrawNode"),
import(".bean.base.Layer"),
import(".bean.base.LayerColor"),
import(".bean.base.Layout"),
import(".bean.base.Node"),
import(".bean.base.Scene"),
import(".bean.base.Sprite"),
import(".bean.base.Scale9Sprite"),
import(".bean.base.SpriteBatchNode"),
import(".bean.Btn"),
import(".bean.Label"),
import(".bean.Widget"),
import(".bean.TableView"),
import(".bean.CheckBox"),
import(".bean.EditBox"),
import(".bean.radio.RadioBtn"),
import(".bean.radio.RadioGroup"),
import(".bean.tabview.TabView"),
import(".bean.tabview.TabHeader"),
import(".bean.tabview.TabContainer"),
import(".bean.RichTxt"),
import(".bean.ListView"),
import(".bean.LoadingBar"),
import(".bean.Slider"),
import(".bean.ScrollView"),
import(".bean.PageView"),
import(".bean.PageViewEx"))