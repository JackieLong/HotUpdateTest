-------------------------------------------------------------------------
-- Title:
-- Author:           Jackie Liu
-- Date:    2016/10/28 21:13:05
-- Desc:
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
local BaseView = class("BaseView")
local TAG = "BaseView"

---- 返回需要加载的资源列表,界面生成前回调.
---- 不需要可以删除此方法
---- 如：return {"a.png","bg.mp3","view.plist"}
-- function BaseView:onPreload()

-- end

-- 界面生成回调，需要返回生成的view的layout布局
-- 必须实现的方法！
function BaseView:onGetLayout()
    assert(false, string.format("%s::onGetLayout must be implemented", self.__cname))
    --    example code
    --      return dn.util.getLayout("hall")
end

-- 界面创建完成后的回调,获取到view节点
-- 界面中的UI操作，在这里完成。
-- 必须实现此方法
function BaseView:onCreateView(view)
    assert(false, string.format("%s:onCreateView must be implemented", self.__cname))
    --    -- example code
    --    self._view = view
    --    self._view:onNodeEvent("cleanup", function()
    --        self._view = nil
    --    end )
    --    -- write you code here...
end

-- 获取当前界面的节点
-- 必须实现的方法！
function BaseView:getView()
    assert(false, string.format("%s::getView must be implemented", self.__cname))
    --    -- example code
    --    return self._view
end

---- 界面销毁前的回调,返回需要卸载的资源列表
---- 不需要可以删除此方法
---- 同onPreload
-- function BaseView:onDestroy()

-- end

---- 返回loadingView.
---- loadView和此类同类，只需要实现onGetLayout和onTransAniIn方法(见下)
---- 不需要可以删除此方法
-- function BaseView:onLoadingView()

-- end

---- view的入场动画。
---- 参数view是此界面，参数viewOld是被退出场界面。
---- 返回动画总时间。切记！！！
---- 不需要可以删除此方法
---- 例子:点击按钮，从当前界面a切换到界面b，这个时候调用b的onTransAniIn，view是b，viewIn是a
-- function BaseView:onTransAniIn(view, viewIn)

-- end

---- view的出场动画。
---- 返回动画总时间。切记！！！
---- 不需要可以删除此方法
---- 例子:点击返回键，退出a界面返回b界面。这个时候调用a的onTransAniOut，view是a，viewOut是b
-- function BaseView:onTransAniOut(view, viewOut)

-- end

return BaseView