-------------------------------------------------------------------------
-- Desc:
-- Author:        Jackie Liu
-- CreateDate:    2016/08/23 11:12:45
-- Revisions:     Jackie Liu(2016/08/23 11:12:45) create this file
-- Purpose:       purpose
-- Copyright (c)wawagame Entertainment All right reserved.
-------------------------------------------------------------------------
local Layer = cc.Layer

-- 引擎默认的setIgnoreAnchorPositionForPostion（true）
-- 这里做一下lua端于C++部分的同步
Layer.ignoreAnchor = true