-------------------------------------------------------------------------
-- Desc:     对官方Node进行扩展
-- Author:   Jackie
-- Date:  	 2016-03-07
-- Last: 	
-- Content:  添加了一些方便实用的方法
--------------------------------------------------------------------------
local NodeEx = cc.Node

-- 同步C++端的对应属性
NodeEx.ignoreAnchor = false

function NodeEx:parent(parent, order, tag)
    if parent then
        self:addTo(parent, order, tag)
    else
        return self:getParent()
    end
    return self
end

-- 设置node的锚点
-- node:anchor(cc.p(0.5,0.5))--设置锚点
-- node:.anchor()--返回锚点
-- node:anchor(0.5,0.5)--设置锚点
-- node:setAnchorPoint(node1)-- 设置和node1一样的锚点
function NodeEx:anchor(x, y)
    if x ~= nil and y == nil and type(x) == "table" then
        --        node:anchor(cc.p(0.5,0.5))设置锚点
        self:setAnchorPoint(x)
    elseif x == nil and y == nil then
        --        node:.anchor()--返回锚点
        return self:getAnchorPoint()
    elseif x ~= nil and y ~= nil then
        --        node:anchor(0.5,0.5)--设置锚点
        self:setAnchorPoint(cc.p(x, y))
    elseif x ~= nil and y == nil and x.getAnchorPoint then
        --        node:setAnchorPoint(node1)-- 设置和node1一样的锚点
        self:setAnchorPoint(x:getAnchorPoint())
    end
    return self
end

function NodeEx:rect()
    local size = self:getContentSize()
    return cc.rect(0, 0, size.width, size.height)
end

-- 返回node缩放后的宽度,countScale是否考虑缩放
function NodeEx:width(countScale)
    return self:getContentSize().width *((countScale == nil and true or countScale) and self:getScaleX() or 1)
end

-- 返回node缩放后的宽度一半,countScale是否考虑缩放
function NodeEx:width2(countScale)
    return self:width(countScale) * 0.5
end

-- 返回node的高度,countScale是否考虑缩放
function NodeEx:height(countScale)
    return self:getContentSize().height *((countScale == nil and true or countScale) and self:getScaleY() or 1)
end
-- 返回node的高度的一半,countScale是否考虑缩放
function NodeEx:height2(countScale)
    return self:height(countScale) * 0.5
end

-- node:size()--返回大小，默认考虑缩放
-- node:size(false)--返回的大小不考虑缩放,true则考虑，默认为true
-- node:size(100,200)--设置大小
-- node:size(cc.size(100,200))--设置大小
-- node:size(node1,false)--设置node为node1的大小，且不考虑node1的缩放，true则为考虑,默认为true
function NodeEx:size(newSizeOrcountScaleOrWidthOrNode, height)
    local size = self:getContentSize()
    if newSizeOrcountScaleOrWidthOrNode == nil and height == nil then
        --        node:size()--返回大小，默认考虑缩放
        return cc.size(size.width * self:scaleX(), size.height * self:scaleY())
    elseif newSizeOrcountScaleOrWidthOrNode ~= nil and height == nil and type(newSizeOrcountScaleOrWidthOrNode) == "boolean" then
        --        node:size(false)--返回的大小不考虑缩放,true则考虑
        if newSizeOrcountScaleOrWidthOrNode then
            return cc.size(size.width * self:scaleX(), size.height * self:scaleY())
        else
            return size
        end
    elseif newSizeOrcountScaleOrWidthOrNode ~= nil and height ~= nil and type(newSizeOrcountScaleOrWidthOrNode) == "number" and type(height) == "number" then
        --        node:size(100,200)--设置大小
        self:setContentSize(cc.size(newSizeOrcountScaleOrWidthOrNode, height))
    elseif newSizeOrcountScaleOrWidthOrNode ~= nil and height == nil and(not newSizeOrcountScaleOrWidthOrNode.getContentSize) and newSizeOrcountScaleOrWidthOrNode.width and newSizeOrcountScaleOrWidthOrNode.height then
        --        node:size(cc.size(100,200))--设置大小
        self:setContentSize(newSizeOrcountScaleOrWidthOrNode)
    elseif newSizeOrcountScaleOrWidthOrNode.getContentSize then
        --        node:size(node1,false)--设置node为node1的大小，且不考虑node1的缩放，true则为考虑
        if height == nil then height = true end
        height =(not not height)
        --            dump(newSizeOrcountScaleOrWidthOrNode:size(height))
        self:size(newSizeOrcountScaleOrWidthOrNode:size(height))
    end
    return self
end

-- node:scale()-- 返回缩放
-- node:scale(0.5)-- xy方向进行相同缩放
-- node:scale(0.5, 0.5)-- x，y方向都进行相应缩放
-- node:scale(nil, 0.5)-- y方向进行缩放
function NodeEx:scale(scale, scaleY)
    if scale == nil and scaleY == nil then
        --        node:scale()--返回缩放
        return self:getScale()
    elseif scale ~= nil and scaleY == nil then
        --        node:scale(0.5)--xy方向进行相同缩放
        self:setScale(scale)
    elseif scale ~= nil and scaleY ~= nil then
        --        node:scale(0.5,0.5)--x，y方向都进行相应缩放
        self:setScaleX(scale):setScaleY(scaleY)
    elseif scale == nil and scaleY ~= nil then
        --        node:scale(nil,0.5)--y方向进行缩放
        self:setScaleY(scaleY)
    end
    return self
end

-- node:scaleX()--返回X方向缩放
-- node:scaleX(0.5)--设置X方向缩放
function NodeEx:scaleX(scaleX)
    if scaleX ~= nil then
        self:setScaleX(scaleX)
    else
        return self:getScaleX()
    end
    return self
end

-- node:scaleY()--返回Y方向缩放
-- node:scaleY(0.5)--设置Y方向缩放
function NodeEx:scaleY(scaleY)
    if scaleY ~= nil then
        self:setScaleY(scaleY)
    else
        return self:getScaleY()
    end
    return self
end

function NodeEx:posX(x)
    if x then
        self:setPositionX(x)
    else
        return self:getPositionX()
    end
    return self
end

function NodeEx:posY(y)
    if y ~= nil then
        self:setPositionY(y)
    else
        return self:getPositionY()
    end
    return self
end

-- pos()--返回坐标
-- pos({x=100,y=200})--设置坐标
-- pos(100,200)--设置坐标
function NodeEx:pos(x, y)
    if x ~= nil and y == nil and type(x) == "table" then
        --    node:pos(cc.p(10,20))设置位置
        self:setPosition(x)
    elseif x ~= nil and y ~= nil then
        --    node:pos(100,200)，设置位置
        self:setPosition(cc.p(x, y))
    elseif x == nil and y == nil then
        --    node:pos()返回位置
        return cc.p(self:getPositionX(), self:getPositionY())
    elseif x ~= nil and y == nil and type(x) == "userdata" then
        --    node:pos(node1)--设置node的位置和node1一样
        self:setPosition(x:pos())
    end
    return self
end

function NodeEx:posEx(x, y)
    if x and not y then
        return self:pos(x.x, SET_SCREEN_HEIGHT - x.y)
    elseif x and y then
        return self:pos(x, SET_SCREEN_HEIGHT - y)
    end
end

function NodeEx:offsetX(x)
    self:setPositionX(self:getPositionX() + x)
    return self
end

function NodeEx:offsetY(y)
    self:setPositionY(self:getPositionY() + y)
    return self
end

function NodeEx:offset(x, y)
    if not y and type(x) == "table" then
        if not x.x or not x.y then
            self:offsetX(x[1])
            self:offsetY(x[2])
        else
            self:offsetX(x.x)
            self:offsetY(x.y)
        end
    else
        self:offsetX(x)
        self:offsetY(y)
    end
    return self
end

-- 已知node2的坐标，设置node1的坐标，使得node1和node2的世界坐标相同
-- function NodeEx:setPosByPos(node2)

-- end

-- function NodeEx:getPosByPos(fuck, node2)
--    return self:getParent():convertToNodeSpace(node2:getParent():convertToWorldSpace(node2:pos()))
-- end

---- 返回node上pos的位置对应在parent或者self:getParent()坐标系中的位置
-- function NodeEx:getPosByPos(pos, node)
--    local realPos = nil
--    if pos and node then
--        local targetParent = self:getParent()
--        realPos = targetParent:convertToNodeSpace(node:convertToWorldSpace(pos))
--    end
--    return realPos
-- end

-- 已知node2的坐标，设置node1的坐标，使得node1和node2的世界坐标相同
local function getPosOfNode(node1, node2)
    if node1:getParent() == node2:getParent() then
        return node2:pos()
    elseif node1:getParent() == node2 then
        return cc.p(0, 0)
    elseif node1 == node2:getParent() then
        return nil
    else
        return node1:getParent():convertToNodeSpace(node2:getParent():convertToWorldSpace(node2:pos()))
    end
end

function NodeEx:center(node)
    if node then
        if self:getParent() == node then
            local anchorSelf =(not self.ignoreAnchor) and self:anchor() or cc.pZero()
            local anchorNode =(not node.ignoreAnchor) and node:anchor() or cc.pZero()
            self:setPositionX(node:width2() -(0.5 - anchorSelf.x) * self:width())
            self:setPositionY(node:height2() -(0.5 - anchorSelf.y) * self:height())
        else
            local anchorSelf =(not self.ignoreAnchor) and self:anchor() or cc.pZero()
            local anchorNode =(not node.ignoreAnchor) and node:anchor() or cc.pZero()
            local posNodeInSelf = getPosOfNode(self, node)

            self:setPosition(cc.pAdd(
            posNodeInSelf,
            cc.p(
            (0.5 - anchorNode.x) * node:width() -(0.5 - anchorSelf.x) * self:width(),
            (0.5 - anchorNode.y) * node:height() -(0.5 - anchorSelf.y) * self:height()
            )))
        end
        return self
    else
        local anchorSelf =(not self.ignoreAnchor) and self:anchor() or cc.pZero()
        return cc.pAdd(self:pos(), cc.p((0.5 - anchorSelf.x) * self:width(),(0.5 - anchorSelf.y) * self:height()))
    end
end

function NodeEx:centerX(node)
    if node then
        if self:getParent() == node then
            local anchorSelf =(not self.ignoreAnchor) and self:anchor() or cc.pZero()
            local anchorNode =(not node.ignoreAnchor) and node:anchor() or cc.pZero()
            self:setPositionX(node:width() * anchorNode.x -(0.5 - anchorSelf.x) * self:width())
            self:setPositionX(node:width2() -(0.5 - anchorSelf.x) * self:width())
        else
            local anchorSelf =(not self.ignoreAnchor) and self:anchor() or cc.pZero()
            local anchorNode =(not node.ignoreAnchor) and node:anchor() or cc.pZero()
            local posNodeInSelf = getPosOfNode(self, node)
            self:setPositionX(posNodeInSelf.x +(0.5 - anchorNode.x) * node:width() -(0.5 - anchorSelf.x) * self:width())
        end
        return self
    else
        local anchorSelf =(not self.ignoreAnchor) and self:anchor() or cc.pZero()
        return self:posX() +(0.5 - anchorSelf.x) * self:width()
    end
end

function NodeEx:centerY(node)
    if node then
        if self:getParent() == node then
            local anchorSelf =(not self.ignoreAnchor) and self:anchor() or cc.pZero()
            local anchorNode =(not node.ignoreAnchor) and node:anchor() or cc.pZero()
            self:setPositionY(node:height2() -(0.5 - anchorSelf.y) * self:height())
        else
            local anchorSelf =(not self.ignoreAnchor) and self:anchor() or cc.pZero()
            local anchorNode =(not node.ignoreAnchor) and node:anchor() or cc.pZero()
            local posNodeInSelf = getPosOfNode(self, node)
            self:setPositionY(posNodeInSelf.y +(0.5 - anchorNode.y) * node:height() -(0.5 - anchorSelf.y) * self:height())
        end
        return self
    else
        local anchorSelf =(not self.ignoreAnchor) and self:anchor() or cc.pZero()
        return self:posY() +(0.5 - anchorSelf.y) * self:height()
    end
end

-- node1在node2上面，返回node1的Y坐标位置
function NodeEx:top(node)
    if node then
        if node == self:getParent() then
            local anchorSelf =(not self.ignoreAnchor) and self:anchor() or cc.pZero()
            local anchorNode =(not node.ignoreAnchor) and node:anchor() or cc.pZero()
            self:setPositionY(node:height() + anchorSelf.y * self:height())
        else
            local anchorSelf =(not self.ignoreAnchor) and self:anchor() or cc.pZero()
            local anchorNode =(not node.ignoreAnchor) and node:anchor() or cc.pZero()
            local posNodeInSelf = getPosOfNode(self, node)
            self:setPositionY(posNodeInSelf.y +(1 - anchorNode.y) * node:height() + anchorSelf.y * self:height())
        end
        return self
    else
        local anchorSelf =(not self.ignoreAnchor) and self:anchor() or cc.pZero()
        local x, y = self:getPosition()
        return y +(1 - anchorSelf.y) * self:height()
    end
end

function NodeEx:top1(node)
    local anchorSelf =(not self.ignoreAnchor) and self:anchor() or cc.pZero()
    local anchorNode =(not node.ignoreAnchor) and node:anchor() or cc.pZero()
    local posNodeInSelf = getPosOfNode(self, node)
    self:setPositionY(node:height() -(0.5 - anchorSelf.y) * self:height())
    return self
end

function NodeEx:innerTop(node)
    if node == self:getParent() then
        local anchorSelf =(not self.ignoreAnchor) and self:anchor() or cc.pZero()
        local anchorNode =(not node.ignoreAnchor) and node:anchor() or cc.pZero()
        self:setPositionY(node:height() -(1.0 - anchorSelf.y) * self:height())
    else
        local anchorSelf =(not self.ignoreAnchor) and self:anchor() or cc.pZero()
        local anchorNode =(not node.ignoreAnchor) and node:anchor() or cc.pZero()
        local posNodeInSelf = getPosOfNode(self, node)
        self:setPositionY(posNodeInSelf.y +(1 - anchorNode.y) * node:height() -(1 - anchorSelf.y) * self:height())
    end
    return self
end

function NodeEx:bottom(node)
    if node then
        if node == self:getParent() then
            local anchorSelf =(not self.ignoreAnchor) and self:anchor() or cc.pZero()
            local anchorNode =(not node.ignoreAnchor) and node:anchor() or cc.pZero()
            self:setPositionY(0 -(1.0 - anchorSelf.y) * self:height())
        else
            local anchorSelf =(not self.ignoreAnchor) and self:anchor() or cc.pZero()
            local anchorNode =(not node.ignoreAnchor) and node:anchor() or cc.pZero()
            local posNodeInSelf = getPosOfNode(self, node)
            self:setPositionY(posNodeInSelf.y - anchorNode.y * node:height() -(1 - anchorSelf.y) * self:height())
        end
        return self
    else
        local anchorSelf =(not self.ignoreAnchor) and self:anchor() or cc.pZero()
        local x, y = self:getPosition()
        return y - anchorSelf.y * self:height()
    end
end

function NodeEx:bottom1(node)
    if node == self:getParent() then
        local anchorSelf =(not self.ignoreAnchor) and self:anchor() or cc.pZero()
        local anchorNode =(not node.ignoreAnchor) and node:anchor() or cc.pZero()
        self:setPositionY(0 -(1.0 - anchorSelf.y) * self:height())
    else
        local anchorSelf =(not self.ignoreAnchor) and self:anchor() or cc.pZero()
        local anchorNode =(not node.ignoreAnchor) and node:anchor() or cc.pZero()
        local posNodeInSelf = getPosOfNode(self, node)
        self:setPositionY(posNodeInSelf.y - anchorNode.y * node:height() -(1 - anchorSelf.y) * self:height())
    end
    return self
end

function NodeEx:innerBottom(node)
    if node == self:getParent() then
        local anchorSelf =(not self.ignoreAnchor) and self:anchor() or cc.pZero()
        local anchorNode =(not node.ignoreAnchor) and node:anchor() or cc.pZero()
        self:setPositionY(anchorSelf.y * self:height())
    else
        local anchorSelf =(not self.ignoreAnchor) and self:anchor() or cc.pZero()
        local anchorNode =(not node.ignoreAnchor) and node:anchor() or cc.pZero()
        local posNodeInSelf = getPosOfNode(self, node)
        self:setPositionY(posNodeInSelf.y -(anchorNode.y * node:height() - anchorSelf.y * self:height()))
    end
    return self
end

-- node1在node2的右边，返回node1的位置
function NodeEx:right(node)
    if node then
        if node == self:getParent() then
            local anchorSelf =(not self.ignoreAnchor) and self:anchor() or cc.pZero()
            local anchorNode =(not node.ignoreAnchor) and node:anchor() or cc.pZero()
            self:setPositionX(node:width() + anchorSelf.x * self:width())
        else
            local anchorSelf =(not self.ignoreAnchor) and self:anchor() or cc.pZero()
            local anchorNode =(not node.ignoreAnchor) and node:anchor() or cc.pZero()
            local posNodeInSelf = getPosOfNode(self, node)
            self:setPositionX(posNodeInSelf.x +(1 - anchorNode.x) * node:width() + anchorSelf.x * self:width())
        end
        return self
    else
        local anchorSelf =(not self.ignoreAnchor) and self:anchor() or cc.pZero()
        return self:getPosition() +(1 - anchorSelf.x) * self:width()
    end
end

function NodeEx:right1(node)
    if node == self:getParent() then
        local anchorSelf =(not self.ignoreAnchor) and self:anchor() or cc.pZero()
        local anchorNode =(not node.ignoreAnchor) and node:anchor() or cc.pZero()
        self:setPositionX(node:width() +(anchorSelf.x - 0.5) * self:width())
    else
        local anchorSelf =(not self.ignoreAnchor) and self:anchor() or cc.pZero()
        local anchorNode =(not node.ignoreAnchor) and node:anchor() or cc.pZero()
        local posNodeInSelf = getPosOfNode(self, node)
        self:setPositionX(posNodeInSelf.x +(1 - anchorNode.x) * node:width() -(0.5 - anchorSelf.x) * self:width())
    end
    return self
end

function NodeEx:innerRight(node)
    if node == self:getParent() then
        local anchorSelf =(not self.ignoreAnchor) and self:anchor() or cc.pZero()
        local anchorNode =(not node.ignoreAnchor) and node:anchor() or cc.pZero()
        self:setPositionX(node:width() -(1 - anchorSelf.x) * self:width())
    else
        local anchorSelf =(not self.ignoreAnchor) and self:anchor() or cc.pZero()
        local anchorNode =(not node.ignoreAnchor) and node:anchor() or cc.pZero()
        local posNodeInSelf = getPosOfNode(self, node)
        self:setPositionX(posNodeInSelf.x +(1 - anchorNode.x) * node:width() -(1 - anchorSelf.x) * self:width())
    end
    return self
end

function NodeEx:left(node)
    if node then
        if node == self:getParent() then
            local anchorSelf =(not self.ignoreAnchor) and self:anchor() or cc.pZero()
            local anchorNode =(not node.ignoreAnchor) and node:anchor() or cc.pZero()
            self:setPositionX(-(1 - anchorSelf.x) * self:width())
        else
            local anchorSelf =(not self.ignoreAnchor) and self:anchor() or cc.pZero()
            local anchorNode =(not node.ignoreAnchor) and node:anchor() or cc.pZero()
            local posNodeInSelf = getPosOfNode(self, node)
            self:setPositionX(posNodeInSelf.x -(anchorNode.x) * node:width() -(1 - anchorSelf.x) * self:width())
        end
        return self
    else
        local anchorSelf =(not self.ignoreAnchor) and self:anchor() or cc.pZero()
        return self:getPosition() - anchorSelf.x * self:width()
    end
end

function NodeEx:left1(node)
    if node == self:getParent() then
        local anchorSelf =(not self.ignoreAnchor) and self:anchor() or cc.pZero()
        local anchorNode =(not node.ignoreAnchor) and node:anchor() or cc.pZero()
        self:setPositionX((anchorSelf.x - 0.5) * self:width())
    else
        local anchorSelf =(not self.ignoreAnchor) and self:anchor() or cc.pZero()
        local anchorNode =(not node.ignoreAnchor) and node:anchor() or cc.pZero()
        local posNodeInSelf = getPosOfNode(self, node)
        self:setPositionX(posNodeInSelf.x -(anchorNode.x) * node:width() -(1 - anchorSelf.x) * self:width())
    end
    return self
end

function NodeEx:innerLeft(node)
    if node == self:getParent() then
        local anchorSelf =(not self.ignoreAnchor) and self:anchor() or cc.pZero()
        self:setPositionX(self:width() * anchorSelf.x)
    else
        local anchorSelf =(not self.ignoreAnchor) and self:anchor() or cc.pZero()
        local anchorNode =(not node.ignoreAnchor) and node:anchor() or cc.pZero()
        local posNodeInSelf = getPosOfNode(self, node)
        self:setPositionX(posNodeInSelf.x -((anchorNode.x) * node:width() - anchorSelf.x * self:width()))
    end
    return self
end

-- NodexEx在node的Center点的右边
function NodeEx:rightCenter(node)
    if node == self:getParent() then
        local anchorSelf =(not self.ignoreAnchor) and self:anchor() or cc.pZero()
        self:setPositionX(node:width2() + self:width() * anchorSelf.x)
    else
        local anchorSelf =(not self.ignoreAnchor) and self:anchor() or cc.pZero()
        local anchorNode =(not node.ignoreAnchor) and node:anchor() or cc.pZero()
        local posNodeInSelf = getPosOfNode(self, node)
        self:setPositionX(posNodeInSelf.x +(0.5 - anchorNode.x) * node:width() + anchorSelf.x * self:width())
    end
    return self
end

-- NodexEx在node的center点的左边
function NodeEx:leftCenter(node)
    if node == self:getParent() then
        local anchorSelf =(not self.ignoreAnchor) and self:anchor() or cc.pZero()
        self:setPositionX(node:width2() - self:width() *(1 - anchorSelf.x))
    else
        local anchorSelf =(not self.ignoreAnchor) and self:anchor() or cc.pZero()
        local anchorNode =(not node.ignoreAnchor) and node:anchor() or cc.pZero()
        local posNodeInSelf = getPosOfNode(self, node)
        self:setPositionX(posNodeInSelf.x -(anchorNode.x - 0.5) * node:width() -(1 - anchorSelf.x) * self:width())
    end
    return self
end

-- NodexEx在node的center点的上边
function NodeEx:topCenter(node)
    if node == self:getParent() then
        local anchorSelf =(not self.ignoreAnchor) and self:anchor() or cc.pZero()
        self:setPositionY(node:height2() + self:height() * anchorSelf.y)
    else
        local anchorSelf =(not self.ignoreAnchor) and self:anchor() or cc.pZero()
        local anchorNode =(not node.ignoreAnchor) and node:anchor() or cc.pZero()
        local posNodeInSelf = getPosOfNode(self, node)
        self:setPositionY(posNodeInSelf.y +(0.5 - anchorNode.y) * node:height() + anchorSelf.y * self:height())
    end
    return self
end

-- NodexEx在node的center点的下边
function NodeEx:bottomCenter(node)
    if node == self:getParent() then
        local anchorSelf =(not self.ignoreAnchor) and self:anchor() or cc.pZero()
        self:setPositionY(node:height2() - self:height() *(1 - anchorSelf.y))
    else
        local anchorSelf =(not self.ignoreAnchor) and self:anchor() or cc.pZero()
        local anchorNode =(not node.ignoreAnchor) and node:anchor() or cc.pZero()
        local posNodeInSelf = getPosOfNode(self, node)
        self:setPositionY(posNodeInSelf.y -(anchorNode.y - 0.5) * node:height() -(1 - anchorSelf.y) * self:height())
    end
    return self
end

function NodeEx:visible(flag)
    if flag == nil then
        return self:isVisible()
    else
        self:setVisible(not not flag)
    end
    return self
end

-- conf =
-- {
--    began = nil,
--    moved = nil,
--    ended = nil,
--    canceled = nil,
--    swallow = false,
-- }
local registerCommand = {
    began = cc.Handler.EVENT_TOUCH_BEGAN,
    moved = cc.Handler.EVENT_TOUCH_MOVED,
    ended = cc.Handler.EVENT_TOUCH_ENDED,
    canceled = cc.Handler.EVENT_TOUCH_CANCELLED
}
function NodeEx:addTouchEx(conf)
    self:removeTouch()
    local listener = cc.EventListenerTouchOneByOne:create()
    self.NodeEx_Node_Single_Touch_Listener = listener

    local swallow = true
    for k, v in pairs(conf) do
        if registerCommand[k] then
            listener:registerScriptHandler(v, registerCommand[k])
        else
            if k == "swallow" then
                listener:setSwallowTouches(v)
            end
        end
    end
    local eventDispatcher = self:getEventDispatcher()
    eventDispatcher:addEventListenerWithSceneGraphPriority(listener, self)
    return listener
end


function NodeEx:addTouches(...)
    self:removeTouches()
    local listener = cc.EventListenerTouchAllAtOnce:create()
    self.NodeEx_Node_Multi_Touch_Listener = listener
    local registerCommand = {
        cc.Handler.EVENT_TOUCHES_BEGAN,
        cc.Handler.EVENT_TOUCHES_MOVED,
        cc.Handler.EVENT_TOUCHES_ENDED,
        cc.Handler.EVENT_TOUCHES_CANCELLED
    }
    for k, v in ipairs( { ...}) do
        if type(v) == "function" then
            listener:registerScriptHandler(v, registerCommand[k])
        else
            break
        end
    end
    local eventDispatcher = self:getEventDispatcher()
    eventDispatcher:addEventListenerWithSceneGraphPriority(listener, self)
    return listener
end
-- 取消单点触摸，只对用addTouch或addTouches添加的方式有效 removeTouch和LayerEx中的同名，不能用
function NodeEx:removeTouch()
    if self.NodeEx_Node_Single_Touch_Listener then
        cc.Director:getInstance():getEventDispatcher():removeEventListener(self.NodeEx_Node_Single_Touch_Listener)
        self.NodeEx_Node_Single_Touch_Listener = nil
    end
    return self
end
function NodeEx:removeTouches()
    if self.NodeEx_Node_Multi_Touch_Listener then
        cc.Director:getInstance():getEventDispatcher():removeEventListener(self.NodeEx_Node_Multi_Touch_Listener)
    end
    return self
end

function NodeEx:swallowTouch(...)
    return self:addTouch( function(touch, event) return true end, ...)
end

-- node拦截node矩形区域内的事件，常见于对话弹框的管理
function NodeEx:swallowTouchInSide(outsidecallback, ...)
    return self:addTouch( function()
        return true
    end , function() end, function(touch, event)
        if not cc.rectContainsPoint(self:rect(), self:convertToNodeSpace(touch:getLocation())) then
            if outsidecallback then outsidecallback() end
        end
    end )
end

function NodeEx:enableClick(callback, movedCancel)
    local moveOffset = 0
    local moveOffsetMax = 10
    self:addTouchEx( {
        began = function(touch, event)
            return cc.rectContainsPoint(self:rect(), self:convertToNodeSpace(touch:getLocation()))
        end,
        moved = function(touch, event)
            if movedCancel then
                moveOffset = moveOffset + cc.pGetLength(touch:getDelta())
            end
        end,
        ended = function(touch, event)
            if cc.rectContainsPoint(self:rect(), self:convertToNodeSpace(touch:getLocation())) then
                if callback and moveOffset <= moveOffsetMax then
                    callback(self)
                end
            end
            moveOffset = 0
        end,
        swallow = false
    } )
    return self
end

-- 变换父亲节点，还是在屏幕上同样的位置
function NodeEx:changeParent(newParent, od, samePos)
    samePos = samePos == nil and true or samePos
    if samePos then
        local newPos = newParent:getPosByPos(self:pos(), self:getParent())
        if newPos then
            target:retain():removeFromParent():addTo(newParent, od):release():pos(newPos)
        end
    else
        target:retain():removeFromParent():addTo(newParent, od):release()
    end
    return self
end

function NodeEx:delay(delay, callbackOraction)
    return self:seq(delay, callbackOraction)
end

function NodeEx:scaleTo(time, scale)
    return self:runAction(cc.ScaleTo:create(time, scale))
end

function NodeEx:seq(...)
    local actions = { }
    for k, v in pairs( { ...}) do
        if v then
            local actCell = nil
            if type(v) == 'number' then
                actCell = cc.DelayTime:create(v)
            elseif type(v) == "function" then
                actCell = cc.CallFunc:create(v)
            else
                actCell = v
            end
            if actCell then
                actions[#actions + 1] = actCell
            end
        end
    end
    if #actions > 0 then
        local ret = cc.Sequence:create(actions)
        self:runAction(ret)
    end
    return self
end

-- 大型节点和Scene被引擎setIgnoreAnchorPointForPosition(true)，即默认为0，0的锚点
-- 这和框架把所有节点看成一样性质的节点相违背。
-- 所以都默认设置为false了。
-- 也就是说所有的节点的锚点初始默认都是cc.p(0.5,0.5)
local old = cc.Node.setIgnoreAnchorPointForPosition
function NodeEx:setIgnoreAnchorPointForPosition(bool)
    self.ignoreAnchor = bool
    old(self, bool)
    return self
end

-- 如果以前注册了相同的event，则会叠加callback，而不会覆盖
function NodeEx:onNodeEvent(eventName, callback)
    if "enter" == eventName then
        if self.onEnterCallback_ then
            local tmpCb = self.onEnterCallback_
            self.onEnterCallback_ = function()
                tmpCb()
                callback()
            end
        else
            self.onEnterCallback_ = callback
        end
    elseif "exit" == eventName then
        if self.onExitCallback_ then
            local tmpCb = self.onExitCallback_
            self.onExitCallback_ = function()
                tmpCb()
                callback()
            end
        else
            self.onExitCallback_ = callback
        end
        self.onExitCallback_ = callback
    elseif "enterTransitionFinish" == eventName then
        if self.onEnterTransitionFinishCallback_ then
            local tmpCb = self.onEnterTransitionFinishCallback_
            self.onEnterTransitionFinishCallback_ = function()
                tmpCb()
                callback()
            end
        else
            self.onEnterTransitionFinishCallback_ = callback
        end
    elseif "exitTransitionStart" == eventName then
        if self.onExitTransitionStartCallback_ then
            local tmpCb = self.onExitTransitionStartCallback_
            self.onExitTransitionStartCallback_ = function()
                tmpCb()
                callback()
            end
        else
            self.onExitTransitionStartCallback_ = callback
        end
    elseif "cleanup" == eventName then
        if self.onCleanupCallback_ then
            local tmpCb = self.onCleanupCallback_
            self.onCleanupCallback_ = function()
                tmpCb()
                callback()
            end
        else
            self.onCleanupCallback_ = callback
        end
    end
    return self:enableNodeEvents()
end

-- 返回键关闭
function NodeEx:keyBackClose(callback)
    -- 物理返回键
    ptf.util.setKeyBackListener(self, function(event)
        if callback then
            callback(self)
        else
            self:removeFromParent()
        end
        -- 阻止透传
        event:stopPropagation()
    end )
    return self
end
