-------------------------------------------------------------------------
-- Desc:            对引擎Scene进行了扩展。
-- Author:        Jackie Liu
-- CreateDate:    2016/08/23 11:12:45
-- Revisions:     Jackie Liu(2016/08/23 11:12:45) create this file
-- Purpose:       purpose
-- Copyright (c)wawagame Entertainment All right reserved.
-------------------------------------------------------------------------
local ScrollView = cc.ScrollView

-- 引擎默认的setIgnoreAnchorPositionForPostion（true）
-- 这里做一下lua端的同步
ScrollView.ignoreAnchor = true