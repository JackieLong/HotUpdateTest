-------------------------------------------------------------------------
-- Desc:
-- Author:        Jackie Liu
-- CreateDate:    2016/08/18 18:31:30
-- Revisions:     Jackie Liu(2016/08/18 18:31:30) create this file
-- Purpose:       
--maxScale = 1.0,
--minScale = 1.0,
--                    -- cc.SCROLLVIEW_DIRECTION_NONE = -1
--                    -- cc.SCROLLVIEW_DIRECTION_HORIZONTAL = 0
--                    -- cc.SCROLLVIEW_DIRECTION_VERTICAL = 1
--                    -- cc.SCROLLVIEW_DIRECTION_BOTH  = 2
--                    direction = cc.SCROLLVIEW_DIRECTION_BOTH,
--                    touchEnabled = false,
--                    isClipingToBounds = true,
--                    viewSize = cc.size(ptf.winSize.width * 0.9,ptf.winSize.height * 0.9),
--                    ignoreAnchor = false,
--                    center = ptf.contants.ui.Parent,
--                    bounceable = true,
--                    container = ptf.ui.createUI( {
--                        class = "Label",
--                        name = "logCntnt",
--                        -- SysFont
--                        sysFnt = "Arial",
--                        fntSize = 35,
--                        fntClr = display.COLOR_WHITE,
--                        dimensW = ptf.winSize.width * 0.9,
--                        dimensH = 0,
--                        txt = tostring(msg) .. "\n" .. debug.traceback(msg,3)
--                    } )
-- Copyright (c)wawagame Entertainment All right reserved.
-------------------------------------------------------------------------
local ScrollView = { __cname = "ScrollView" }
local Node = import(".base.Node")

local setAttr = ptf.ui.setAttr

function ScrollView.createInstance(style)
    local ret = cc.ScrollView:create()

    ScrollView.setAttr(ret, style)
    ret:updateInset()
    ret:setDelegate()

    ret:registerScriptHandler(style.didScroll or function() end, cc.SCROLLVIEW_SCRIPT_SCROLL)
    ret:registerScriptHandler(style.didZoom or function() end, cc.SCROLLVIEW_SCRIPT_ZOOM)
    return ret
end

function ScrollView.setAttr(node, style)
    setAttr(node, style, "setViewSize", "viewSize")
    setAttr(node, style, "setContainer", "container")
    setAttr(node, style, "setDirection", "direction")
    setAttr(node, style, "setClippingToBounds", "isClipingToBounds")
    setAttr(node, style, "setBounceable", "bounceable")
    setAttr(node, style, "setMaxScale", "maxScale")
    setAttr(node, style, "setMinScale", "minScale")
    setAttr(node, style, "setContentOffset", "contentOffset")
    return node
end

function ScrollView.getAttr()
    return
    table.merge( {
        name = 5,
        maxScale = 1,
        minScale = 1,
        direction = 3,
        touchEnabled = 1,
        isClipingToBounds = 2,
        viewSize = 4,
        bounceable = 2,
    } , Node.getAttr())
end

return ScrollView