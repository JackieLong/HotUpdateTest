-------------------------------------------------------------------------
-- Desc:          类似引擎的PageView，但开放接口更多，目前只支持水平方向，
-- Author:        Jackie Liu
-- CreateDate:    2016/08/20 11:47:40
-- Revisions:     Jackie Liu(2016/08/20 11:47:40) create this file
-- Purpose:
--        local conf = {
--            class = "PageView",
--            name = "test",
--            viewSize = cc.size(winSize.width,winSize.height - 160),
--            direction = cc.SCROLLVIEW_DIR_HORIZONTAL,
--            bgScale9 = true,
--            bg = "test.png",
--            items =
--            {
--                require(trackLua.views.layout.MainView.ViewFan),
--                require(trackLua.views.layout.MainView.ViewSui),
--                require(trackLua.views.layout.MainView.ViewZheng),
--                require(trackLua.views.layout.MainView.ViewZheng),
--            },
--            bottom = "topBar",
--            centerX = "topBar",
--        }
--        local pageView = ptf.ui.createUI(conf)
-- Copyright (c)wawagame Entertainment All right reserved.
-------------------------------------------------------------------------
local PageView = class("PageView", cc.Node)
local Node = import(".base.Node")

local ClipNode = import(".base.ClipNode")

local conf = ptf.conf

function PageView.createInstance(style)
    return PageView:create(style)
end

function PageView:ctor(style)
    self.items = { }
    self.viewConf = nil
    self.direction = style.direction
    self.viewSize = style.viewSize
    self.clip = nil
    -- 当前是否偏离位置,且手指是离开屏幕的。
    self._isInAutoScroll = nil
    -- 一次触摸拖动的距离，决定了是否需要翻页
    self._offset_touch_scroll = nil
    -- 触发自动翻页的滑动偏移量（灵敏度）
    self._threshold = conf.ui.PAGEVIEW_CUSTOM_THRESHOLD or 50
    -- 当前页面
    self._cur_page_idx = 1
    self.container = nil
    -- 自动滑动开始时的监听
    -- function(pageView,curIdx),curIdx是指自动滑动完成之后的页面idx
    self._autoScrollFinishedListener = nil
    self:_initUI(style)

    -- 背景大小
    local bg = self.viewConf.bg
    if bg and style.bgScale9 then
        bg:setPreferredSize(self.viewSize)
    end

    -- container大小
    if self.direction == cc.SCROLLVIEW_DIRECTION_VERTICAL then
        self.container:size(self.viewSize.width, #self.items * self.viewSize.height)
    else
        self.container:size(self.viewSize.width * #self.items, self.viewSize.height)
        self:addTouch( function(touch, event)
            if not self._isInAutoScroll then
                if cc.rectContainsPoint(self:rect(), self:convertToNodeSpace(touch:getLocation())) then
                    self._offset_touch_scroll = 0.0
                    return true
                else
                    return false
                end
            end
        end ,
        function(touch, event)
            if not self._isInAutoScroll then
                self._offset_touch_scroll = self._offset_touch_scroll + touch:getDelta().x
                local offsetX = touch:getDelta().x
                self.container:offsetX(offsetX)
                if self.follow and self.follow.node then
                    self.follow.node:offsetX(- offsetX * self.follow.rate)
                end
            end
        end ,
        function(touch, event)
            if not self._isInAutoScroll then
                self:handleReleaseLogic(self, touch, event)
            end
        end )
    end

    return self
end

function PageView:setListener(callback)
    self._autoScrollFinishedListener = callback
end

function PageView:_initUI(style)
    local viewSize = style.viewSize
    self:size(viewSize)
    local bg = style.bg
    local ret =
    {
        {
            class = "ClipNode",
            name = "clip",
            region = cc.rect(0,0,viewSize.width,viewSize.height),
            {
                class = "Layer",
                name = "container",
            },
        },
    }
    if bg then
        table.insert(ret, 1,
        {
            class = "Scale9Sprite",
            name = "bg",
            src = bg,
        } )
    end
    for k, v in pairs(ret) do
        v.parent = self
    end
    self.viewConf = ptf.ui.createLayout(ret)
    self.container = self.viewConf.container
    if style.items then
        for k, v in ipairs(style.items) do
            v.size = self.viewSize
            local item = ptf.ui.createUI(v):addTo(self.viewConf.container)
            self.items[#self.items + 1] = item
            if self.direction == cc.SCROLLVIEW_DIRECTION_VERTICAL then
                item:setPositionY((1 - k) * self.viewSize.height)
            else
                -- 其他都被看成是水平方向
                item:setPositionX((k - 1) * self.viewSize.width)
            end
        end
    end
    return self
end

function PageView:setFollowNode(node, unitDistance)
    self.follow =
    {
        node = node,
        unitDistance = unitDistance,
        rate = unitDistance / self.viewSize.width
    }
end

function PageView:setCustomThreshold(threshold)
    self._threshold = threshold
end

function PageView:handleReleaseLogic(touch, event)
    -- 0不需要翻页，1往右翻一页，-1往左边翻一页
    local needNextPage = 0
    -- 滑动距离够了
    if math.abs(self._offset_touch_scroll) >= self._threshold then
        if self._offset_touch_scroll > 0 then
            -- 往左滑动
            if self._cur_page_idx > 1 then
                -- 滑动方向还有下一页
                needNextPage = -1
            end
        else
            -- 往右滑动
            if self._cur_page_idx < #self.items then
                needNextPage = 1
            end
        end
    else
        -- 恢复到原来页
        needNextPage = 0
    end
    self:scrollTo(self._cur_page_idx + needNextPage)
    self._offset_touch_scroll = 0.0
end

function PageView:scrollTo(pageIdx)
    if not self._isInAutoScroll then
        if pageIdx >= 0 and pageIdx <= #self.items then
            self._isInAutoScroll = true
            self._cur_page_idx = pageIdx
            -- 目标页位置
            local targetPagePos = self.viewSize.width *(1 - self._cur_page_idx)
            local offsetX = targetPagePos - self.container:getPositionX()
            local time = math.abs(offsetX) / conf.ui.PAGEVIEW_SPEED
            self.container:runAction(ptf.ui.createAni( {
                class = "Spawn",
                {
                    -- EaseIn
                    -- EaseExponentialIn
                    -- EaseSineIn
                    -- EaseElastic
                    -- EaseBounce
                    -- EaseBackIn
                    cc.EaseBackOut:create(cc.MoveTo:create(time,cc.p(targetPagePos,0.0))),
                    function()
                        self._isInAutoScroll = false
                        if self._autoScrollFinishedListener then
                            self._autoScrollFinishedListener(self, self._cur_page_idx)
                        end
                    end
                },
                {
                    function()
                        if self.follow and self.follow.node then
                            self.follow.node:runAction(
                            cc.MoveBy:create(time, cc.p(- offsetX * self.follow.rate, 0.0))
                            )
                        end
                    end
                }
            } ))
        end
    end
    return self
end

function PageView.getAttr()
    return
    table.merge( {
        name = 5,
        viewSize = 4,
        direction = 4,
        bg = 3,
        items = 3,
        bgScale9 = 2,
    } , Node.getAttr())
end

return PageView
