-------------------------------------------------------------------------
-- Desc:          TabHeader,本质和CheckButton类似
-- Author:        Jackie Liu
-- ModifyDate:    2016/07/18 18:13:00
-- Purpose:
--        ptf.ui.createUI( {
--            class = "TabHeader",
--            -- 下面这个五个属性和CheckBox的这五个属性一样理解
--            bg = "1.png",
--            bgSelected = "2.png",
--            cross = "3.png",
--            bgDisabled = "4.png",
--            crossDisabled = "5.png",
--            -- tabheader上的文字，下面是他的字体，颜色，大小
--            title = "TAB1",
--            titleFnt = nil,
--            titleSize = 30,
--            titleClr = cc.c3b(0,255,255)
--        } )
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
local TabHeader = { __cname = "TabHeader" }
local Node = import("..base.Node")

local setAttr = ptf.ui.setAttr

function TabHeader.createInstance(style)
    local bg = style.bg
    local bgSelected = style.bgSelected
    local cross = style.cross
    local bgDisabled = style.bgDisabled
    local crossDisabled = style.crossDisabled

    local title = style.title

    local ret = nil
    if not bgSelected or not bgDisabled or not crossDisabled then
        ret = ccui.TabHeader:create(title, bg, bgSelected)
    else
        ret = ccui.TabHeader:create(title, bg, bgSelected, cross, bgDisabled, crossDisabled)
    end

    TabHeader.setAttr(ret, style)

    return ret
end

function TabHeader.setAttr(ret, style)
    setAttr(ret, style, "setTitleFontName", "titleFnt")
    setAttr(ret, style, "setTitleFontSize", "titleSize")
    setAttr(ret, style, "setTitleColor", "titleClr")
    return ret
end

function TabHeader.getAttr()
    return
    table.merge( {
        name = 5,
        bg = 1,
        bgSelected = 1,
        cross = 1,
        bgDisabled = 1,
        crossDisabled = 1,
        title = 1,
        titleFnt = 1,
        titleSize = 1,
        titleClr = 1,
    } , Node.getAttr())
end

return TabHeader
