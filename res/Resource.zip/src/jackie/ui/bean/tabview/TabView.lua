-------------------------------------------------------------------------
-- Desc:          自定义TabView（TabControl）
-- Author:        Jackie Liu
-- ModifyDate:    2016/07/18 18:13:00
-- Purpose:
--        local styleTabView =
--        {
--            class = "TabView",
--            -- tabView的大小
--            size = cc.size(300,300),
--            -- 设置tab的大小，会进行缩放
--            headerH = 100,
--            headerW = 100,
--            -- 点击tab时的缩放量，默认为引擎默认缩放量
--            headerZoomScale = 0.05,
--            -- TAb相对于container的位置,默认在上面
--            dockPlace = ptf.contants.ui.TabDockPlace.RIGHT,
--            pos = cc.p(200,200),
--            -- 不支持
--            --        callback = function(idx, eventType)
--            --            print("eventType *************** " .. eventType)
--            --        end,
--            callback = nil,
--            -- tabHeader和tabContainer，两者一一对应
--            views =
--            {
--                {
--                    -- 必须从0开始，并且连续
--                    idx = 0,
--                    -- tabHeader
--                    header =
--                    {
--                        class = "TabHeader",
--                        -- 下面这个五个属性和CheckBox的这五个属性一样理解
--                        bg = "1.png",
--                        bgSelected = "2.png",
--                        cross = "3.png",
--                        bgDisabled = "4.png",
--                        crossDisabled = "5.png",
--                        -- tabheader上的文字，下面是他的字体，颜色，大小
--                        title = "TAB1",
--                        titleFnt = nil,
--                        titleSize = 30,
--                        titleClr = cc.c3b(0,255,255)
--                    },
--                    -- tabContainer，其实就是一个Layout
--                    container =
--                    {
--                        class = "TabContainer",
--                        -- ccui.Layout的属性
--                        opacity = 255,
--                        -- none = 0,
--                        -- solid = 1,
--                        -- gradient = 2,
--                        bgClrType = ccui.LayoutBackGroundColorType.solid,
--                        bgClr = cc.c3b(255,0,255),
--                        bgClrOpacity = 255
--                    }
--                },
--                {
--                    idx = 1,
--                    header =
--                    {
--                        class = "TabHeader",
--                        bg = "1.png",
--                        bgSelected = "2.png",
--                        cross = "3.png",
--                        bgDisabled = "4.png",
--                        crossDisabled = "5.png",
--                        title = "TAB2",
--                        titleFnt = nil,
--                        titleSize = 30,
--                        titleClr = cc.c3b(0,255,255)
--                    },
--                    container =
--                    {
--                        class = "TabContainer",
--                        opacity = 255,
--                        -- none = 0,
--                        -- solid = 1,
--                        -- gradient = 2,
--                        bgClrType = ccui.LayoutBackGroundColorType.solid,
--                        bgClr = cc.c3b(255,0,0),
--                        bgClrOpacity = 255
--                    }
--                }
--            }
--        }
--        ptf.ui.createUI(styleTabView)
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
local TabView = { __cname = "TabView" }
local Node = import("..base.Node")

local setAttr = ptf.ui.setAttr

function TabView.createInstance(style)
    local place = style.dockPlace
    local views = style.views

    local ret = ccui.TabControl:create()

    if not place then
        ret:setHeaderDockPlace(ptf.contants.ui.TabDockPlace.TOP)
    end

    TabView.setAttr(ret, style)

    if views then
        for k, v in ipairs(views) do
            ret:insertTabEx(v)
        end
    end
    return ret
end

function TabView.setAttr(ret, style)
    setAttr(ret, style, "setHeaderHeight", "headerH")
    setAttr(ret, style, "setHeaderWidth", "headerW")
    setAttr(ret, style, "setHeaderSelectedZoom", "headerZoomScale")
    setAttr(ret, style, "setHeaderDockPlace", "dockPlace")
    setAttr(ret, style, "setTabChangedEventListener", "callback")
    return ret
end

function ccui.TabControl:insertTabEx(style)
    self:insertTab(style.idx, ptf.ui.createUI(style.header), ptf.ui.createUI(style.container))
    return self
end

function TabView.getAttr()
    return
    table.merge( {
        name = 5,
        idx = 1,
        header = 1,
        container = 1,
        views = 1,
        dockPlace = 1,
        headerH = 1,
        headerW = 1,
        headerZoomScale = 1,
        dockPlace = 1,
        callback = 1,
    } , Node.getAttr())
end

return TabView