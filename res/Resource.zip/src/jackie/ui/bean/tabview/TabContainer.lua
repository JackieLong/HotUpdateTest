-------------------------------------------------------------------------
-- Desc:          TabContainer和TabHeader搭配使用，TabHeader对应显示的内容面板,本质就是一个Layout
-- Author:        Jackie Liu
-- ModifyDate:    2016/07/18 18:13:00
-- Purpose:
--        ptf.ui.createUI( {
--            class = "TabContainer",
--            -- ccui.Layout的属性
--            TabOpacity = 255,
--            none = 0,
--            solid = 1,
--            gradient = 2,
--            bgClrType = ccui.LayoutBackGroundColorType.solid,
--            bgClr = cc.c3b(255,0,255),
--            bgClrOpacity = 255
--        } )
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
local TabContainer = { __cname = "TabContainer" }
local Node = import("..base.Node")

local setAttr = ptf.ui.setAttr

function TabContainer.createInstance(style)
    --    local opacity = style.TabOpacity
    local ret = ccui.Layout:create()

    TabContainer.setAttr(ret, style)

    return ret
end

function TabContainer.setAttr(ret, style)
    setAttr(ret, style, "setBackGroundColorType", "bgClrType")
    setAttr(ret, style, "setBackGroundColor", "bgClr")
    setAttr(ret, style, "setBackGroundColorOpacity", "bgClrOpacity")
    return ret
end

return TabContainer