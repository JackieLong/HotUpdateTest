-------------------------------------------------------------------------
-- Desc:          自定义按钮，满足点击音效，点击特效，点击保护等需求
-- Author:        Jackie Liu
-- ModifyDate:    2016/07/13 23:09:00
-- Purpose:
--        local btn = nil
--        btn = ptf.ui.createUI(
--        {
--            --class必不可少
--            class = "Btn",
--            -- 正常，选中和失效时的状态，目前只能是string类型，？？？日后加入node类型？？？
--            normal = "1.png",
--            selected = "2.png",
--            disabled = "3.png",
--            -- 按下时的音效
--            audio_down = "m1 (1).mp3",
--            -- 松开时的音效
--            audio_up = "m1 (2).mp3",
--            -- 按下时的特效,sender就是按钮的引用
--            ani_down = function(sender) cc.FadeOut:create(0.2) end,
--            -- 松开时的特效,sender就是按钮的引用
--            ani_up = function(sender) cc.FadeIn:create(0.2) end,
--            -- 回调
--            callback = function(sender) end
--        } ):addTo(self):center(fucker)
--        -- 设置按钮回调，第一个是回调函数，参数是回调者的引用，第二个参数是是否启用点击保护，可不赋值，默认为true
--        btn:onClick( function(sender)
--            print("motherucker")
--        end , true)
--        -- 设置按钮上的内容，参数为node类型
--        btn:setTxt(cc.Label:createWithSystemFont("Btn", "Arial", 40))
--        -- 用于微调按钮上内容的位置，以下代码将在X正方向偏移10个单位
--        btn:offsetTxt(10)
--        -- 以下代码将在X，Y正方向偏移10个单位
--        btn:offsetTxt(10, 10)
--        -- 以下代码将在Y正方向偏移10个单位
--        btn:offsetTxt(nil, 10)
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
local Btn = { __cname = "Btn" }
local Node = import(".base.Node")

local setAttr = ptf.ui.setAttr

local audioMgr = ptf.audio

-- callback和btnTxt可为空
function Btn.createInstance(style, callback, btnTxt)
    -- 按下的音效
    local audioDown = style.audio_down
    -- 松开的音效
    local audioUp = style.audio_up
    -- 按下的特效
    local aniDown = style.ani_down
    -- 松开的特效
    local aniUp = style.ani_up
    -- 按钮回调
    local callback = style.callback

    local ret = ccui.Button:create()
    ret._click_sensivity = ptf.conf.ui.DEFAULT_BTN_SENSIVITY
    ret._click_sensivity_tmp_ = 0
    ret.callback = callback

    ptf.ui.setNodeAttrs(ret, "Widget", style)
    Btn.setAttr(ret, style)

    ret:addTouchEventListener( function(sender, eventType)
        if eventType == ccui.TouchEventType.began then
            sender._click_sensivity_tmp_ = 0
            ptf.log.verbose("Btn.create", "**************began")
            if audioDown then
                audioMgr:play(audioDown)
            end
            local ani = aniDown and aniDown(ret)
            if ani then
                ret:runAction(ani)
            end
        elseif eventType == ccui.TouchEventType.moved then
            ptf.log.verbose("Btn.create", "**************moved")
        elseif eventType == ccui.TouchEventType.ended then
            ptf.log.verbose("Btn.create", "**************ended")
            if audioUp then
                audioMgr:play(audioUp)
            end
            local ani = aniUp and aniUp(ret)
            if ani then
                ret:runAction(ani)
            end
            if ret.safeClick then
                sender:setTouchEnabled(false)
                sender:delay(time or ptf.conf.ui.INTRVL_SAFE_CLICK, function()
                    sender:setTouchEnabled(true)
                end )
                if sender._click_sensivity_tmp_ <= sender._click_sensivity then
                    if ret.callback then ret.callback(sender) end
                end
            else
                if sender._click_sensivity_tmp_ <= sender._click_sensivity then
                    if ret.callback then ret.callback(sender) end
                end
            end
            sender._click_sensivity_tmp_ = 0
        else
            sender._click_sensivity_tmp_ = 0
        end
    end )
    return ret
end

function Btn.setAttr(ret, style)
    if style.titleTxt and not style.titleFntSize then
        style.titleFntSize = ptf.conf.ui.DEFAULT_BTN_TITLE_SIZE
    end
    -- 普通状态的ui
    setAttr(ret, style, "loadTextureNormal", "normal")
    -- 选中状态
    setAttr(ret, style, "loadTexturePressed", "selected")
    -- 失效装填
    setAttr(ret, style, "loadTextureDisabled", "disabled")
    setAttr(ret, style, "setTxt", "btnTxt")
    setAttr(ret, style, "setTitleColor", "titleClr")
    setAttr(ret, style, "setTitleText", "titleTxt")
    setAttr(ret, style, "setTitleFontSize", "titleFntSize")
    setAttr(ret, style, "setScale9Enabled", "scale9Enabled")
    setAttr(ret, style, "setPressedActionEnabled", "pressActionEnabled")
    setAttr(ret, style, "setCapInsetsDisabledRenderer", "capInsetsDisable")
    setAttr(ret, style, "setCapInsetsNormalRenderer", "capInsetsNormal")
    setAttr(ret, style, "setCapInsetsPressedRenderer", "capInsetsPressed")
    setAttr(ret, style, "setCapInsets", "capInsets")
    setAttr(ret, style, "setTitleFontName", "titleFntName")
    setAttr(ret, style, "setTitleAlignment", "titleAlign")
    setAttr(ret, style, "setZoomScale", "zoomScale")

    return ret
end

function ccui.Button:onClick(callback, safeClick)
    self.callback = callback
    self.safeClick = safeClick == nil and true or safeClick
    return self
end

function ccui.Button:offsetTxt(x, y)
    if self.btnTxt then
        self.btnTxt:offset(x, y)
    end
    return self
end

function ccui.Button:setTxt(btnTxt)
    local tmpBtnTxt = nil
    if self.btnTxt then
        self.btnTxt:removeFromParent()
        self.btnTxt = nil
    end
    if type(btnTxt) == "userdata" then
        tmpBtnTxt = btnTxt
    else
        tmpBtnTxt = ptf.ui.createUI(btnTxt)
    end
    tmpBtnTxt:addTo(self):center(self):setCascadeColorEnabled(true):setCascadeOpacityEnabled(true)
    self.btnTxt = tmpBtnTxt
    return self
end

-- 设置按钮灵敏度：在按钮上滑动的位移作为点击的界限。
-- 灵敏度越高，意味着按钮上越不能滑动当做点击
function ccui.Button:setClickSensivity(sensivity)
    if sensivity then
        self._click_sensivity = sensivity
    end
    return self
end

function Btn.getAttr()
    return
    table.merge( {
        name = 5,
        normal = 4.5,
        selected = 4.0,
        disabled = 3.5,
        callback = 3.0,
        btnTxt = 2.5,
        audio_down = 2.0,
        audio_up = 2.0,
        ani_down = 2.0,
        ani_up = 2.0,
        titleTxt = 1.5,
        titleFntSize = 1.4,
        titleFntName = 1.3,
        titleClr = 1.2,
        titleAlign = 1.1,
        zoomScale = 1.0,
        scale9Enabled = 0.9,
        pressActionEnabled = 0.9,
        capInsetsDisable = 0.8,
        capInsetsNormal = 0.7,
        capInsetsPressed = 0.6,
        capInsets = 0.5,
    } , Node.getAttr())
end

return Btn
