-------------------------------------------------------------------------
-- Desc:          LoadingBar
-- Author:        Jackie Liu
-- ModifyDate:    2016/07/21 16:49:00
-- Purpose:
--        local style =
--        {
--            class = "LoadingBar",
--            percent = 10,
--            loadTexture = "HelloWorld.png",
--            -- RIGHT
--            direction = ccui.LoadingBarDirection.LEFT,
--            -- false则按percent比例显示texture，
--            -- true则按比例缩放texture，percent100为原大小
--            scale9Enabled = true,
--            -- capInsets = cc.rect(0,1,1,1),
--        }
--        ptf.create(style):addTo(self):offset(400, 300)
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
local LoadingBar = { __cname = "LoadingBar" }
local Node = import(".base.Node")

local setAttr = ptf.ui.setAttr

function LoadingBar.createInstance(style)

    local ret = ccui.LoadingBar:create()

    LoadingBar.setAttr(ret, style)

    return ret
end

function LoadingBar.setAttr(ret, style)
    setAttr(ret, style, "setPercent", "percent")
    setAttr(ret, style, "loadTexture", "loadTexture")
    setAttr(ret, style, "setDirection", "direction")
    setAttr(ret, style, "setScale9Enabled", "scale9Enabled")
    setAttr(ret, style, "setCapInsets", "capInsets")
    return ret
end

function LoadingBar.getAttr()
    return
    table.merge( {
        name = 5,
        percent = 4,
        loadTexture = 3,
        scale9Enabled = 3,
        direction = 3,
        capInsets = 2,
    } , Node.getAttr())
end


return LoadingBar