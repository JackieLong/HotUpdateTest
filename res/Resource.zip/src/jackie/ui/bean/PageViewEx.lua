-------------------------------------------------------------------------
-- Desc:          自定义pageView，
-- Author:        Jackie Liu
-- ModifyDate:    2016/07/17 17:05:00
-- Purpose:
--        local styleTableView =
--        {
--            class = "PageView",
--            pageSize = cc.size(300,300),
--            -- cc.SCROLLVIEW_DIRECTION_HORIZONTAL,
--            -- cc.SCROLLVIEW_DIRECTION_VERTICAL,
--            -- cc.SCROLLVIEW_DIRECTION_NONE
--            -- cc.SCROLLVIEW_DIRECTION_BOTH
--            direction = cc.SCROLLVIEW_DIRECTION_BOTH,
--            -- 是否显示indicator
--            indicatorEnable = true,
--            -- indicator加在pageview的哪个锚点上
--            indicatorAnchr = cc.p(0.1,0.5),
--            -- 在pageview的锚点为原点，设置indicator的位置
--            indicatorPos = cc.p(100,200),
--            -- indicators之间的距离
--            indicatorSpace = 100,
--            -- 当前页面对应的indicator的颜色
--            indicatorSelectedClr = cc.c3b(100,200,100),
--            -- 除了当前页面对应的indicator的颜色
--            indicatorNodeClr = cc.c3b(200,100,150),
--            -- indicator的缩放比例
--            indicatorNodeScale = 1.5,
--            -- indicator的图片路径
--            indctrTexture = "HelloWorld.png",
--            -- 拖动并释放之后pageview的滑动速度
--            epsilon = 0.0,
--            items =
--            {
--                {
--                    class = "Layout",
--                    name = "item1",
--                    {
--                        class = "Sprite",
--                        src = "HelloWorld.png",
--                        name = "shit",
--                        center = "item1"
--                    }
--                },
--                {
--                    class = "Layout",
--                    name = "item1",
--                    {
--                        class = "Sprite",
--                        name = "shit",
--                        src = "HelloWorld.png",
--                        center = "item1"
--                    }
--                },
--                {
--                    class = "Layout",
--                    name = "item1",
--                    {
--                        class = "Sprite",
--                        name = "shit",
--                        src = "HelloWorld.png",
--                        center = "item1"
--                    }
--                },
--                {
--                    class = "Layout",
--                    name = "item1",
--                    {
--                        class = "Sprite",
--                        name = "shit",
--                        src = "HelloWorld.png",
--                        center = "item1"
--                    }
--                }
--            }
--        }
--        local pageView = ptf.ui.createUI(styleTableView):onEvent( function(event)
--            -- 松开之后自动滑动到静止位置时触发回调
--        end )
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
local PageViewEx = { __cname = "PageViewEx" }
local Node = import(".base.Node")

local setAttr = ptf.ui.setAttr

function PageViewEx.createInstance(style)
    local pageSize = style.pageSize
    local items = style.items

    local ret = ccui.PageView:create()

    PageViewEx.setAttr(ret, style)

    ret.items = { }
    if items and #items > 0 then
        for k, v in ipairs(items) do
            if v.class ~= "Layout" then
                assert("PageViewEx.create", "item of in PageViewEx's config's field items must be class == Layout")
            else
                v.size = pageSize
                v.parent = ret
                local item = ptf.ui.createUI(v)
                item:retain()
                item:removeFromParent()
                ret:addPage(item)
                ret.items[#ret.items + 1] = item
                item:release()
            end
        end
    end
    return ret
end

function PageViewEx.setAttr(ret, style)
    setAttr(ret, style, "setContentSize", "pageSize")
    setAttr(ret, style, "setDirection", "direction")
    setAttr(ret, style, "setIndicatorEnabled", "indicatorEnable")
    setAttr(ret, style, "setIndicatorPositionAsAnchorPoint", "indicatorAnchr")
    setAttr(ret, style, "setIndicatorPosition", "indicatorPos")
    setAttr(ret, style, "setIndicatorSpaceBetweenIndexNodes", "indicatorSpace")
    setAttr(ret, style, "setIndicatorSelectedIndexColor", "indicatorSelectedClr")
    setAttr(ret, style, "setIndicatorIndexNodesColor", "indicatorNodeClr")
    setAttr(ret, style, "setIndicatorIndexNodesScale", "indicatorNodeScale")
    setAttr(ret, style, "setIndicatorIndexNodesTexture", "indctrTexture")
    setAttr(ret, style, "setAutoScrollStopEpsilon", "epsilon")

    return ret
end

function PageViewEx.getAttr()
    return
    table.merge( {
        name = 5,
        pageSize = 4,
        items = 3,
        direction = 3,
        indicatorEnable = 2,
        indicatorAnchr = 2,
        indicatorPos = 2,
        indicatorSpace = 2,
        indicatorSelectedClr = 1,
        indicatorNodeClr = 2,
        indicatorNodeScale = 2,
        indctrTexture = 2,
        epsilon = 1,
    } , Node.getAttr())
end

return PageViewEx