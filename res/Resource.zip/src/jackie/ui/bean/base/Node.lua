local Node = { __cname = "Node" }

local setAttr = ptf.ui.setAttr

function Node.createInstance(style)
    -- 不需要执行Node.setAttr，为了让所有在UI中生成的节点都能具备Node的属性
    return cc.Node:create()
end

function Node.setAttr(cell, conf)
    --    setAttr(cell, conf, 'size', 'size')
    setAttr(cell, conf, 'setContentSize', 'size')
    setAttr(cell, conf, 'anchor', 'anchor')
    setAttr(cell, conf, 'setOnExitCallback', 'exitCallback')
    setAttr(cell, conf, 'setCascadeOpacityEnabled', 'cascadeOpacity')
    setAttr(cell, conf, 'setCascadeColorEnabled', 'cascadeColor')
    setAttr(cell, conf, 'setOpacity', 'opacity')
    setAttr(cell, conf, 'setTag', 'tag')
    setAttr(cell, conf, 'setScaleZ', 'scaleZ')
    setAttr(cell, conf, 'setScaleX', 'scaleX')
    setAttr(cell, conf, 'setScaleY', 'scaleY')
    setAttr(cell, conf, 'setName', 'name')
    setAttr(cell, conf, 'setPositionX', 'x')
    setAttr(cell, conf, 'setPositionY', 'y')
    setAttr(cell, conf, 'setPosition', 'pos')
    setAttr(cell, conf, 'setVisible', 'visible')
    setAttr(cell, conf, 'setScale', 'scale')
    setAttr(cell, conf, 'setGlobalZOrder', 'gOrder')
    setAttr(cell, conf, 'setLocalZOrder', 'order')
    setAttr(cell, conf, 'setColor', 'color')

    setAttr(cell, conf, 'setIgnoreAnchorPointForPosition', 'ignoreAnchor')
    setAttr(cell, conf, 'setRotation', 'rotation')
    setAttr(cell, conf, 'setRotationSkewX', 'rotationSkewX')
    setAttr(cell, conf, 'setonEnterTransitionDidFinishCallback', 'enterTransDidFinishCallback')
    setAttr(cell, conf, 'setCameraMask', 'cameraMask')
    setAttr(cell, conf, 'setSkewX', 'skewX')
    setAttr(cell, conf, 'setOnEnterCallback', 'enterCallback')
    setAttr(cell, conf, 'setNormalizedPosition', 'normalPos')
    setAttr(cell, conf, 'setonExitTransitionDidStartCallback', 'exitTransDidStartCallback')
    setAttr(cell, conf, 'setOrderOfArrival', 'orderOfArrval')
    setAttr(cell, conf, 'swallowTouch', 'nodeSwallowTouch')
    setAttr(cell, conf, 'swallowTouchInSide', 'nodeSwallowTouchInSide')
    return cell
end

function Node.getAttr()
    return
    {
        name = 5,
        top = 4.9,
        top1 = 4.8,
        bottom = 4.7,
        bottom1 = 4.6,
        left = 4.59,
        left1 = 4.58,
        right = 4.57,
        right1 = 4.56,
        centerX = 4.55,
        centerY = 4.54,
        center = 4.53,
        innerBottom = 4.52,
        innerTop = 4.51,
        innerLeft = 4.509,
        innerRight = 4.508,
        parent = 4.507,
        offset = 4.506,
        offsetX = 4.503,
        offsetY = 4.502,
        size = 4.5,
        pos = 4.0,
        x = 4.0,
        y = 4.0,
        scale = 3.5,
        anchor = 3.5,
        visible = 3.0,
        nodeSwallowTouch = 3.0,
        nodeSwallowTouchInSide = 3.0,
        order = 2.5,
        cascadeOpacity = 2.0,
        cascadeColor = 2.0,
        opacity = 2.0,
        color = 2.0,
        exitCallback = 1.5,
        enterCallback = 1.5,
        scaleX = 1.5,
        scaleY = 1.5,
        tag = 1,
        scaleZ = 1,
        gOrder = 1,
        ignoreAnchor = 1,
        rotation = 1,
        rotationSkewX = 1,
        enterTransDidFinishCallback = 1,
        exitTransDidStartCallback = 1,
        cameraMask = 1,
        skewX = 1,
        normalPos = 1,
        orderOfArrval = 1,
    }
end

return Node