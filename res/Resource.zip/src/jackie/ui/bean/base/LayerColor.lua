local LayerColor = { __cname = "LayerColor" }
local Node = import(".Node")

local setAttr = ptf.ui.setAttr

function LayerColor.createInstance(conf)
    return cc.LayerColor:create(conf.layerClr or cc.c4b(0, 0, 0, 255))
end

function LayerColor.setAttr(ret, style)
    --        tolua_function(tolua_S,"new",lua_cocos2dx_LayerColor_constructor);
    --        tolua_function(tolua_S,"changeWidthAndHeight",lua_cocos2dx_LayerColor_changeWidthAndHeight);
    --        tolua_function(tolua_S,"getBlendFunc",lua_cocos2dx_LayerColor_getBlendFunc);
    --        tolua_function(tolua_S,"setBlendFunc",lua_cocos2dx_LayerColor_setBlendFunc);
    --        tolua_function(tolua_S,"changeWidth",lua_cocos2dx_LayerColor_changeWidth);
    --        tolua_function(tolua_S,"initWithColor",lua_cocos2dx_LayerColor_initWithColor);
    --        tolua_function(tolua_S,"changeHeight",lua_cocos2dx_LayerColor_changeHeight);
    --        tolua_function(tolua_S,"create", lua_cocos2dx_LayerColor_create);
    return ret
end

function LayerColor.getAttr()
    return
    table.merge( {
        name = 5,
        layerClr = 1,
    } , Node.getAttr())
end

return LayerColor