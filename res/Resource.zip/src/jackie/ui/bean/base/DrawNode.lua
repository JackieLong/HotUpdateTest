local DrawNode = { __cname = "DrawNode" }
local Node = import(".Node")

local setAttr = ptf.ui.setAttr

function DrawNode.createInstance(style)


    --    tolua_function(tolua_S, "new", lua_cocos2dx_DrawNode_constructor);
    --    tolua_function(tolua_S, "drawLine", lua_cocos2dx_DrawNode_drawLine);
    --    tolua_function(tolua_S, "drawRect", lua_cocos2dx_DrawNode_drawRect);
    --    tolua_function(tolua_S, "drawSolidCircle", lua_cocos2dx_DrawNode_drawSolidCircle);
    --    tolua_function(tolua_S, "setLineWidth", lua_cocos2dx_DrawNode_setLineWidth);
    --    tolua_function(tolua_S, "onDrawGLPoint", lua_cocos2dx_DrawNode_onDrawGLPoint);
    --    tolua_function(tolua_S, "drawDot", lua_cocos2dx_DrawNode_drawDot);
    --    tolua_function(tolua_S, "drawSegment", lua_cocos2dx_DrawNode_drawSegment);
    --    tolua_function(tolua_S, "getBlendFunc", lua_cocos2dx_DrawNode_getBlendFunc);
    --    tolua_function(tolua_S, "onDraw", lua_cocos2dx_DrawNode_onDraw);
    --    tolua_function(tolua_S, "drawCircle", lua_cocos2dx_DrawNode_drawCircle);
    --    tolua_function(tolua_S, "drawQuadBezier", lua_cocos2dx_DrawNode_drawQuadBezier);
    --    tolua_function(tolua_S, "onDrawGLLine", lua_cocos2dx_DrawNode_onDrawGLLine);
    --    tolua_function(tolua_S, "drawTriangle", lua_cocos2dx_DrawNode_drawTriangle);
    --    tolua_function(tolua_S, "setBlendFunc", lua_cocos2dx_DrawNode_setBlendFunc);
    --    tolua_function(tolua_S, "clear", lua_cocos2dx_DrawNode_clear);
    --    tolua_function(tolua_S, "drawSolidRect", lua_cocos2dx_DrawNode_drawSolidRect);
    --    tolua_function(tolua_S, "getLineWidth", lua_cocos2dx_DrawNode_getLineWidth);
    --    tolua_function(tolua_S, "drawPoint", lua_cocos2dx_DrawNode_drawPoint);
    --    tolua_function(tolua_S, "drawCubicBezier", lua_cocos2dx_DrawNode_drawCubicBezier);
    --    tolua_function(tolua_S, "create", lua_cocos2dx_DrawNode_create);
end

function DrawNode.setAttr(ret, style)

    return ret
end

function DrawNode.getAttr()
    return
    table.merge( {
        name = 5,

    } , Node.getAttr())
end

return DrawNode