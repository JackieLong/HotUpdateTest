local Sprite = { __cname = "Sprite" }
local Node = import(".Node")

local setAttr = ptf.ui.setAttr

function Sprite.createInstance(conf)
    local ret = nil
    -- src:create(string),createWithSpriteFrameName,createWithSpriteFrame,createWithTexture
    if conf.src then
        ret = display.newSprite(conf.src)
    end
    Sprite:setAttr(ret, conf)
    return ret
end

function Sprite:setAttr(ret, style)
    setAttr(ret, style, "initWithFile", "spFile")
    setAttr(ret, style, "initWithTexture", "spTexture")
    setAttr(ret, style, "initWithSpriteFrame", "spFrame")
    setAttr(ret, style, "initWithSpriteFrameName", "spFrameName")
    setAttr(ret, style, "setFlippedY", "flipX")
    setAttr(ret, style, "setFlippedX", "flipY")
    setAttr(ret, style, "setTextureRect", "textureRect")
    setAttr(ret, style, "setBatchNode", "batchNode")
    setAttr(ret, style, "setDisplayFrameWithAnimationName", "displayFrame")
    setAttr(ret, style, "setTextureAtlas", "textureAtlas")
    setAttr(ret, style, "setAtlasIndex", "atlasIdx")
    setAttr(ret, style, "setDirty", "spDirty")
    setAttr(ret, style, "setBlendFunc", "spBlendFunc")
    setAttr(ret, style, "setVertexRect", "spVertRect")
    return ret
end

function Sprite.getAttr()
    return table.merge( {
        name = 5,
        src = 4.0,
        flipX = 3.0,
        flipY = 3.0,
        spFile = 1,
        spTexture = 1,
        spFrame = 1,
        spFrameName = 1,
        textureRect = 1,
        batchNode = 1,
        displayFrame = 1,
        textureAtlas = 1,
        atlasIdx = 1,
        spDirty = 1,
        spBlendFunc = 1,
        spVertRect = 1,
    } , Node.getAttr())
end

return Sprite