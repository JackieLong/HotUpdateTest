local Layer = { __cname = "Layer" }
local Node = import(".Node")

local setAttr = ptf.ui.setAttr

function Layer.createInstance(conf)
    if conf.layerClr then
        return cc.LayerColor:create(conf.layerClr or cc.c4b(0, 0, 0, 255))
    else
        return cc.Layer:create()
    end
end

function Layer.setAttr(ret, style)
    return ret
end

function Layer.getAttr()
    return
    table.merge( {
        name = 5,
        layerClr = 1,
    } , Node.getAttr())
end

return Layer