-------------------------------------------------------------------------
-- Desc:
-- Author:        Jackie Liu
-- CreateDate:    2016/09/04 00:20:26
-- Purpose:       purpose
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
local SpriteBatchNode = { __cname = "SpriteBatchNode" }
local Node = import(".Node")

local setAttr = ptf.ui.setAttr

function SpriteBatchNode.createInstance()

end

function SpriteBatchNode.setAttr(ret, style)
    return ret
end

function SpriteBatchNode.getAttr()
    return
    table.merge( {
        name = 5,
    } , Node.getAttr())
end

return SpriteBatchNode