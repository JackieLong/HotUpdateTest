local Layout = { __cname = "Layout" }
local Node = import(".Node")

local setAttr = ptf.ui.setAttr

function Layout.createInstance(style)
    local ret = ccui.Layout:create()
    ptf.ui.setNodeAttrs(ret, "Widget", style)
    Layout.setAttr(ret, style)
    return ret
end

function Layout.setAttr(ret, style)
    return ret
end

function Layout.getAttr()
    return
    table.merge( {
        name = 5,
    } , Node.getAttr())
end

return Layout