-------------------------------------------------------------------------
-- Desc:
-- Author:        Jackie Liu
-- CreateDate:    2016/08/24 10:16:01
-- Revisions:     Jackie Liu(2016/08/24 10:16:01) create this file
-- Purpose:       purpose
-- Copyright (c)wawagame Entertainment All right reserved.
-------------------------------------------------------------------------
local Scale9Sprite = { __cname = "Scale9Sprite" }
local Node = import(".Node")

local setAttr = ptf.ui.setAttr

function Scale9Sprite.createInstance(style)
    local src = style.src
    local delimitation = style.delimitation
    local capInsets = style.capInsets
    local spFrameName = style.spFrameName
    local spFrame = style.spFrame

    local spFrame = style.spFrame

    local ret = nil
    local Scale9 = ccui.Scale9Sprite
    if src and delimitation and capInsets then
        ret = Scale9:create(src, delimitation, capInsets)
    elseif capInsets and src then
        ret = Scale9:create(capInsets, src)
    elseif src and delimitation then
        ret = Scale9:create(src, delimitation)
    elseif src then
        ret = Scale9:create(src)
    elseif spFrameName and delimitation then
        ret = Scale9:createWithSpriteFrameName(spFrameName, delimitation)
    elseif spFrameName then
        ret = Scale9:createWithSpriteFrameName(spFrameName)
    elseif spFrame and capInsets then
        ret = Scale9:createWithSpriteFrame(spFrame, capInsets)
    elseif spFrame then
        ret = Scale9:createWithSpriteFrame(spFrame)
    else
        ret = Scale9:create()
    end
    Scale9Sprite.setAttr(ret, style)
    return ret
end

function Scale9Sprite.setAttr(ret, style)
    setAttr(ret, style, "disableCascadeColor", "disableCasClr")
    setAttr(ret, style, "disableCascadeOpacity", "disableCasOpa")
    setAttr(ret, style, "setScale9Enabled", "scale9Enabled")
    setAttr(ret, style, "setFlippedX", "flipX")
    setAttr(ret, style, "setFlippedY", "flipY")
    setAttr(ret, style, "setState", "state")
    setAttr(ret, style, "setInsetTop", "insetTop")
    setAttr(ret, style, "setInsetBottom", "insetBottom")
    setAttr(ret, style, "setInsetRight", "insetRight")
    setAttr(ret, style, "setInsetLeft", "insetLeft")
    setAttr(ret, style, "setPreferredSize", "preferSize")
    setAttr(ret, style, "setSpriteFrame", "spFrame")
    setAttr(ret, style, "setBlendFunc", "blendFunc")
    return ret
end

function Scale9Sprite.getAttr()
    return
    table.merge( {
        name = 5,
        src = 4.0,
        preferSize = 3.5,
        capInsets = 3.5,
        scale9Enabled = 3.0,
        spFrame = 2.5,
        flipX = 2.0,
        flipY = 2.0,
        blendFunc = 1,
        spFrameName = 1,
        spFrame = 1,
        delimitation = 1,
        disableCasClr = 1,
        disableCasOpa = 1,
        disableCasOpa = 1,
        state = 1,
        insetTop = 1,
        insetBottom = 1,
        insetRight = 1,
        insetLeft = 1,
    } , Node.getAttr())
end

return Scale9Sprite