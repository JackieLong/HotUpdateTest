local ClipNode = { __cname = "ClipNode" }
local Node = import(".Node")

local setAttr = ptf.ui.setAttr

function ClipNode.createInstance(style)
    if style.x and style.y and style.width and style.height then
        return cc.ClippingRectangleNode:create(clipRegion)
    elseif type(style) == "userdata" then
        return cc.ClippingNode:create():setStencil(style)
    else
        local clipRegion = style.region
        local ret = nil
        if clipRegion then
            ret = cc.ClippingRectangleNode:create(clipRegion)
        else
            ret = cc.ClippingNode:create()
            ClipNode.setAttr(ret, style)
        end
        return ret
    end
end

function ClipNode.setAttr(ret, style)
    setAttr(ret, style, "setInverted", inverted)
    setAttr(ret, style, "setStencil", stencil)
    setAttr(ret, style, "setAlphaThreshold", threshold)
    return ret
end

function ClipNode.getAttr()
    return
    table.merge( {
        name = 5,
        width = 1,
        height = 1,
        x = 1,
        y = 1,
        region = 1,
        inverted = 1,
        stencil = 1,
        threshold = 1,
    } , Node.getAttr())
end

return ClipNode