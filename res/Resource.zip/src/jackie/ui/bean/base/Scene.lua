local Scene = { __cname = "Scene" }
local Node = import(".Node")

local setAttr = ptf.ui.setAttr

function Scene.createInstance(conf)
    return cc.Scene:create()
end

function Scene.setAttr(ret, style)
    return ret
end

function Scene.getAttr()
    return
    table.merge( {
        name = 5,
    } , Node.getAttr())
end

return Scene