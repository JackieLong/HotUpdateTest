-------------------------------------------------------------------------
-- Desc:          自定义tableView，老版本的returnCellSize是返回height,width，新版本的是返回width,height。务必小心
-- Author:        Jackie Liu
-- ModifyDate:    2016/07/15 14:51:00
-- Purpose:
--            local style =
--            {
--                class = "TableView",
--                -- tableView的宽高
--                tablesize = cc.size(200,300),
--                -- tableView的滑动方向，默认为竖直方向
--                -- cc.SCROLLVIEW_DIRECTION_NONE,
--                -- cc.SCROLLVIEW_DIRECTION_HORIZONTAL,
--                -- cc.SCROLLVIEW_DIRECTION_VERTICAL,
--                -- cc.SCROLLVIEW_DIRECTION_BOTH,
--                dir = cc.SCROLLVIEW_DIRECTION_VERTICAL,
--                -- cc.TABLEVIEW_FILL_TOPDOWN = 0
--                -- cc.TABLEVIEW_FILL_BOTTOMUP = 1
--                -- 数据的填充顺序，TABLEVIEW_FILL_TOPDOWN为从上往下填，反之从下往上填，默认为从上往下填
--                fill = cc.TABLEVIEW_FILL_TOPDOWN,
--                -- 同时能显示的单元个数，可以为小数，比如4.5，表示能同时显示4个半的单元
--                frameCellNum = 5,
--                -- tableView单元的总个数
--                cellNum = 100,
--                -- tableview在拖动时触发的回调，可以不赋值
--                didscroll = function(tableView) end,
--                -- 可以不赋值
--                didzoom = function(tableView) end,
--                -- 生成每个单元界面时触发的回调，参数里的cell为已经设定好大小的cell
--                -- 可以使用ViewHolder的方式优化内存使用
--                tblCellCb = function(table, cell, idx) end,
--                -- 点下单元并释放的时候产生的回调，可以不赋值
--                cbTouched = function(table, cell) end,
--            }
--            local tableView = ptf.ui.createUI(style)
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
local TableView = { __cname = "TableView" }
local Node = import(".base.Node")

function TableView.createInstance(style)
    local size = style.tablesize
    local dir = style.dir or cc.SCROLLVIEW_DIRECTION_VERTICAL
    local fill = style.fill or cc.TABLEVIEW_FILL_TOPDOWN
    local cellNumPerFrame = function() return style.frameCellNum end
    local cbNumber = function() return style.cellNum end
    local cbDidScroll = style.didscroll or function(view) end
    local cbDidZoom = style.didzoom or function(view) end
    local cbTouched = style.cbTouched or function(table, cell) end
    --    local cbTouchHightLighted = style.cbTouchSelected or function(table, cell) end
    --    local cbTouchUnHightLighted = style.cbTouchUnSelected or function(table, cell) end

    local cbCellSize = function(table, idx)
        --        print("height" .. size.height)
        --        print(cellNumPerFrame())
        --        print(size.height /(cellNumPerFrame()))
        return size.width, size.height /(cellNumPerFrame())
    end
    local cbCell = function(table, idx)
        local cell = table:dequeueCell()
        local width, height = cbCellSize(table, idx)
        if not cell then
            cell = cc.TableViewCell:new()
            cell:setContentSize(cc.size(width, height))
        end
        style.tblCellCb(table, cell, idx, width, height)
        return cell
    end
    local tableView = cc.TableView:create(size):setDirection(dir)
    tableView:setDelegate()
    tableView:setVerticalFillOrder(fill)
    tableView:registerScriptHandler(cbNumber, cc.NUMBER_OF_CELLS_IN_TABLEVIEW)
    tableView:registerScriptHandler(cbDidScroll, cc.SCROLLVIEW_SCRIPT_SCROLL)
    tableView:registerScriptHandler(cbDidZoom, cc.SCROLLVIEW_SCRIPT_ZOOM)
    tableView:registerScriptHandler(cbTouched, cc.TABLECELL_TOUCHED)
    --  tableView:registerScriptHandler(cbTouchHightLighted, cc.TABLECELL_HIGH_LIGHT)
    --  tableView:registerScriptHandler(cbTouchUnHightLighted, cc.TABLECELL_UNHIGH_LIGHT)
    tableView:registerScriptHandler(cbCellSize, cc.TABLECELL_SIZE_FOR_INDEX)
    tableView:registerScriptHandler(cbCell, cc.TABLECELL_SIZE_AT_INDEX)
    tableView:reloadData()
    return tableView
end

function TableView.getAttr()
    return
    table.merge(
    {
        name = 5,
        size = 4,
        dir = 4,
        fill = 2,
        frameCellNum = 3,
        cellNum = 4,
        tblCellCb = 4,
        didscroll = 2,
        cbTouched = 1,
    } , Node.getAttr()
    )
end

return TableView