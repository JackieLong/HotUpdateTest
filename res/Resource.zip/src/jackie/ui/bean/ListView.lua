-------------------------------------------------------------------------
-- Desc:          自定义文本节点，满足CharMap，TTF，SysFont，BMFont。
-- Author:        Jackie Liu
-- ModifyDate:    2016/07/14 16:44:00
-- Purpose:
--        local style =
--        {
--            class = "ListView",
--            -- none = 0,
--            -- vertical = 1,
--            -- horizontal = 2,
--            -- 列表滑动方向
--            direction = ccui.ListViewDirection.vertical,
--            -- 滑动到最边上时，是否能继续拖动并且松开会自动复位。true是会。
--            bounceEnabled = true,
--            -- 拖动列表的背景
--            bg = "HelloWorld.png",
--            -- 背景是否需要点9缩放
--            bgScale9Enabled = false,
--            -- 列表的size大小
--            size = cc.size(300,300),

--            -- srollBarOffset = cc.p(0,1110),

--            -- NONE = 0,
--            -- CENTER = 1,
--            -- BOTH_END = 2,
--            -- LEFT = 3,
--            -- RIGHT = 4,
--            -- TOP = 5,
--            -- BOTTOM = 6,
--            magneticType = ptf.contants.ui.ListView.MagneticType.RIGHT,
--            magneticAllowedOutOfBoundary = false,
--            -- 两个item之间的间距。
--            itemsMargin = 10,
--            -- left = 0,
--            -- right = 1,
--            -- centerHorizontal = 2,
--            -- top = 3,
--            -- bottom = 4 ,
--            -- centerVertical = 5,
--            gravity = ccui.ListViewGravity.bottom,
--        }
--        local list = ptf.ui.createUI(style):addTo(self):offset(200, 100)
--        ----    list:setItemModel()
--        for i = 1, 100 do
--            local item = ccui.Layout:create():size(style.size)
--            list:pushBackCustomItem(item)
--            local btn = ptf.ui.createUI( {
--                class = "Label",
--                -- SysFont
--                sysFnt = "Arial",
--                fntSize = 50,
--                txt = "motherfucker",
--                fntClr = cc.c3b(100,200,200)
--            } ):addTo(item):center(item)
--            cc.Sprite:create("HelloWorld.png"):addTo(item):center(item):scale(0.3)
--        end
--        list:forceDoLayout()
--        -- 第一个参数，移动到idx，从0开始，
--        -- 第二个参数，最终在listView显示窗口的哪个位置比率，0.50.5表示最后在正中间
--        -- 第三个参数，代表这个item的锚点，用于引擎计算移动距离。
--        -- 第四个参数，移动的时间，可以不用设置。
--        --超出范围会自适应
--        self.layout.listAttr:scrollToItem(10, cc.p(05, 0.5), cc.p(0, 1.00, 3.0))
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
local ListView = { __cname = "ListView" }
local Node = import(".base.Node")

local setAttr = ptf.ui.setAttr

function ListView.createInstance(style)
    if not style.countPerFrame then
        style.countPerFrame = ptf.conf.ui.DEFAULT_LISTVIEW_COUNT_PER_FRAME
    end
    local items = style.items

    local ret = ccui.ListView:create()

    ListView.setAttr(ret, style)

    if items then
        for k, v in ipairs(items) do
            v.size = cc.size(style.size.width, style.size.height / style.countPerFrame)
            ret:pushBackCustomItem(ptf.ui.createUI(v))
        end
    end

    ret:forceDoLayout()
    ret._styleConf = style
    return ret
end

function ccui.ListView:refresh(uis)
    self:removeAllItems()
    for k, v in pairs(uis) do
        local item = nil
        if type(v) == "userdata" then
            item = v
        else
            v.size = cc.size(self._styleConf.size.width, self._styleConf.size.height / self._styleConf.countPerFrame)
            item = ptf.ui.createUI(v)
        end
        self:pushBackCustomItem(item)
    end
    --    self:forceDoLayout()
    return self
end

function ListView.setAttr(ret, style)
    setAttr(ret, style, "setGravity", "gravity")
    setAttr(ret, style, "setMagneticType", "magneticType")
    setAttr(ret, style, "setMagneticAllowedOutOfBoundary", "magneticAllowedOutOfBoundary")
    setAttr(ret, style, "setItemsMargin", "itemsMargin")
    --    setAttr(ret,style, "setItemModel", itemModel)
    setAttr(ret, style, "setDirection", "direction")
    setAttr(ret, style, "setBounceEnabled", "bounceEnabled")
    setAttr(ret, style, "setBackGroundImage", "bg")
    setAttr(ret, style, "setBackGroundImageScale9Enabled", "bgScale9Enabled")
    --    setAttr(ret, style, "setContentSize", "size")
    --    setAttr(ret,style, "setPosition", pos)
    setAttr(ret, style, "setScrollBarPositionFromCorner", "srollBarPos")
    --    setAttr(ret, style, "setInnerContainerSize", "size")
    return ret
end

function ListView.getAttr()
    return
    table.merge(
    {
        name = 5,
        size = 4.5,
        countPerFrame = 4,
        direction = 4,
        items = 3,
        itemsMargin = 3,
        bg = 2,
        bgScale9Enabled = 2,
        bounceEnabled = 1,
        magneticType = 1,
        srollBarPos = 1,
        magneticAllowedOutOfBoundary = 1,
        gravity = 1,
    } , Node.getAttr())
end

return ListView