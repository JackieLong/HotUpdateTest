-------------------------------------------------------------------------
-- Desc:
-- Author:        Jackie Liu
-- CreateDate:    2016/08/28 21:52:18
-- Purpose:       purpose
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
local Widget = { __cname = "Widget" }
local Node = import(".base.Node")

local setAttr = ptf.ui.setAttr

function Widget.createInstance()

end

function Widget.setAttr(node, conf)
    setAttr(node, conf, "setLayoutComponentEnabled", "layoutComponentEnabled")
    -- {0.5,0.5}
    setAttr(node, conf, "setSizePercent", "sizePercent")
    -- string
    setAttr(node, conf, "setCallbackName", "callbackName")
    -- bool
    setAttr(node, conf, "setPropagateTouchEvents", "propagateTouchEvents")
    -- {0.5,0.5}
    setAttr(node, conf, "setPositionPercent", "posPercent")
    -- bool
    setAttr(node, conf, "setSwallowTouches", "swallowTouches")
    -- bool
    setAttr(node, conf, "setHighlighted", "highLighted")
    -- Widget::PositionType
    setAttr(node, conf, "setPositionType", "posType")
    -- bool
    setAttr(node, conf, "ignoreContentAdaptWithSize", "ignoreContentAdaptWithSize")
    -- bool
    setAttr(node, conf, "setFocused", "focused")
    -- int
    setAttr(node, conf, "setActionTag", "actionTag")
    -- bool
    setAttr(node, conf, "setTouchEnabled", "touchEnabled")
    -- bool
    setAttr(node, conf, "setEnabled", "enabled")
    -- Widget::BrightStyle
    setAttr(node, conf, "setBrightStyle", "brightStyle")
    -- ui::LayoutParameter
    setAttr(node, conf, "setLayoutParameter", "layoutParam")
    -- bool
    setAttr(node, conf, "setFocusEnabled", "focusEnabled")
    -- bool
    setAttr(node, conf, "setUnifySizeEnabled", "unifySizeEnabled")
    -- Widget::SizeType
    setAttr(node, conf, "setSizeType", "sizeType")
    -- bool
    setAttr(node, conf, "setBright", "bright")
    -- string
    setAttr(node, conf, "setCallbackType", "callbackType")
    -- bool
    setAttr(node, conf, "enableDpadNavigation", "dpadNavigation")
    --
    setAttr(node, conf, "addClickEventListener", "clickEventListener")
    return node
end

function Widget.getAttr()
    return
    table.merge(
    {
        name = 5,
        layoutComponentEnabled = 1,
        sizePercent = 1,
        callbackName = 1,
        propagateTouchEvents = 3,
        posPercent = 1,
        swallowTouches = 4,
        highLighted = 3,
        posType = 1,
        ignoreContentAdaptWithSize = 2,
        focused = 2,
        actionTag = 1,
        touchEnabled = 3,
        enabled = 3,
        brightStyle = 2,
        layoutParam = 1,
        focusEnabled = 1,
        unifySizeEnabled = 1,
        sizeType = 1,
        bright = 1,
        callbackType = 1,
        dpadNavigation = 1,
    }
    , Node.getAttr())
end

return Widget
