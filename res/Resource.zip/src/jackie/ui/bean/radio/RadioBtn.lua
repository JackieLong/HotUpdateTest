-------------------------------------------------------------------------
-- Desc:          自定义RadioBtn
-- Author:        Jackie Liu
-- ModifyDate:    2016/07/18 13:52:00
-- Purpose:
--        local radioBtn = ptf.ui.createUI( {
--            class = "RadioBtn",
--            parent = self,
--            off = "btn1.png",
--            on = "btn2.png",
--            zoomScale = 0.97,
--            pos = cc.p(750,300),
--            callback = function(btn, eventType)
--                if eventType == ccui.RadioButtonEventType.selected then
--                    print("2*************selected")
--                elseif eventType == ccui.RadioButtonEventType.unselected then
--                    print("2*************unselected")
--                end
--            end
--        } )
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
local RadioBtn = { __cname = "RadioBtn" }
local Node = import("..base.Node")

local setAttr = ptf.ui.setAttr

function RadioBtn.createInstance(style)
    local offImg = style.off
    local onImg = style.on
    local disableImg = style.disable
    local ret = ccui.RadioButton:create(offImg, "", onImg, disableImg, disableImg)

    RadioBtn.setAttr(ret, style)

    return ret
end

function RadioBtn.setAttr(ret, style)
    setAttr(ret, style, "setZoomScale", "zoomScale")
    setAttr(ret, style, "addEventListener", "callback")
    return ret
end

return RadioBtn
