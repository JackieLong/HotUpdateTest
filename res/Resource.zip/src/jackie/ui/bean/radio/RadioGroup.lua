-------------------------------------------------------------------------
-- Desc:          自定义RadioBtn
-- Author:        Jackie Liu
-- ModifyDate:    2016/07/18 13:52:00
-- Purpose:
--        local style =
--        {
--            class = "RadioGroup",
--            allowedNoSelection = true,
--            btns =
--            {
--                {
--                    class = "RadioBtn",
--                    parent = self,
--                    off = "btn1.png",
--                    on = "btn2.png",
--                    zoomScale = 0.97,
--                    pos = cc.p(200,300),
--                    -- btn1,btn2,btn3，一开始选中btn1，点击btn2，
--                    -- 先触发btn2的event是selected的回调
--                    -- 在触发btn1的event是unselected的回调，
--                    callback = function(btn, eventType)
--                        if eventType == ccui.RadioButtonEventType.selected then
--                            print("0*************selected")
--                        elseif eventType == ccui.RadioButtonEventType.unselected then
--                            print("0*************unselected")
--                        end
--                    end
--                },
--                {
--                    class = "RadioBtn",
--                    parent = self,
--                    off = "btn1.png",
--                    on = "btn2.png",
--                    zoomScale = 0.97,
--                    pos = cc.p(350,300),
--                    callback = function(btn, eventType)
--                        if eventType == ccui.RadioButtonEventType.selected then
--                            print("1*************selected")
--                        elseif eventType == ccui.RadioButtonEventType.unselected then
--                            print("1*************unselected")
--                        end
--                    end
--                },
--                {
--                    class = "RadioBtn",
--                    parent = self,
--                    off = "btn1.png",
--                    on = "btn2.png",
--                    zoomScale = 0.97,
--                    pos = cc.p(500,300),
--                    callback = function(btn, eventType)
--                        if eventType == ccui.RadioButtonEventType.selected then
--                            print("2*************selected")
--                        elseif eventType == ccui.RadioButtonEventType.unselected then
--                            print("2*************unselected")
--                        end
--                    end
--                },
--            },
--            -- btn1,btn2,btn3，点击btn1时，触发btn1，idx = 0 的回调，其他都没有
--            callback = function(btn, idx, eventType)
--                if eventType == ccui.RadioButtonEventType.selected then
--                    print(idx .. "----radioGroupselected")
--                elseif eventType == ccui.RadioButtonEventType.unselected then
--                    print(idx .. "----radioGroupunselected")
--                end
--            end
--        }
--        local radioGroup = ptf.ui.createUI(style):addTo(self):centerX(fucker):bottom(fucker)
--        --    local radioBtn = radioGroup:getRadioButtonByIndex(0)

--        -- 和上面的callback是一样的
--        radioGroup:addEventListener( function(btn, idx, eventType)
--            if eventType == ccui.RadioButtonEventType.selected then
--                print(idx .. "----radioGroupselected")
--            elseif eventType == ccui.RadioButtonEventType.unselected then
--                print(idx .. "----radioGroupunselected")
--            end
--        end )
--        --    radioGroup:setSelectedButtonWithoutEvent(0)
--        --    radioGroup:setSelectedButton(0)
--        --    radioGroup:setSelectedButton(radioBtn)
--        --    local selectedIdx = radioGroup:getSelectedButtonIndex()
--        --    radioGroup:removeAllRadioButtons()
--        --    radioGroup:getNumberOfRadioButtons()
--        radioGroup:addRadioButton(
--        ptf.ui.createUI( {
--            class = "RadioBtn",
--            parent = self,
--            off = "btn1.png",
--            on = "btn2.png",
--            zoomScale = 0.97,
--            pos = cc.p(750,300),
--            callback = function(btn, eventType)
--                if eventType == ccui.RadioButtonEventType.selected then
--                    print("2*************selected")
--                elseif eventType == ccui.RadioButtonEventType.unselected then
--                    print("2*************unselected")
--                end
--            end
--        } ))
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
local RadioGroup = { __cname = "RadioGroup" }
local Node = import("..base.Node")

local setAttr = ptf.ui.setAttr

function RadioGroup.createInstance(style)
    local ret = ccui.RadioButtonGroup:create()
    for k, v in ipairs(style.btns) do
        ret:addRadioButton(ptf.ui.createUI(v))
    end

    RadioGroup.setAttr(ret, style)

    return ret
end

function RadioGroup.setAttr(ret, style)
    setAttr(ret, style, "setAllowedNoSelection", "allowedNoSelection")
    setAttr(ret, style, "addEventListener", "callback")
    return ret
end

return RadioGroup