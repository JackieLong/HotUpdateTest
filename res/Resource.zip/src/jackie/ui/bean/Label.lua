-------------------------------------------------------------------------
-- Desc:          自定义文本节点,满足CharMap,TTF,SysFont,BMFont。
-- Author:        Jackie Liu
-- ModifyDate:    2016/07/14 16:44:00
-- Purpose:
--        local styles =
--        {
--            {
--                --class必不可少
--                class = "Label",
--                -- TTF
--                ttfConf =
--                {
--                    fontFilePath = "Abberancy.ttf",
--                    fontSize = 28,
--                    -- 使用的字符集,默认"DYNAMIC"
--                    glyphs = cc.GLYPHCOLLECTION_CUSTOM,
--                    customGlyphs = "MotherFucker",
--                    -- 令字体紧凑
--                    distanceFieldEnabled = true,
--                    -- 描边大小
--                    outlineSize = 10,
--                },
--                -- 荧光效果,只有TTF支持
--                glowClr = cc.c4b(0,0,255,255),
--                -- 描边大小,只有TTF和SysFnt支持
--                outLineSize = 1,
--                -- 描边颜色
--                outLineClr = cc.c4b(100,100,100,100),
--                -- 阴影颜色
--                shadowClr = cc.c4b(0,255,0,255),
--                -- 阴影偏移量,width为x方向,height为y方向
--                shadowOffset = { width = 0, height = 2 },
--                -- 阴影模糊指数
--                shadowBlur = 0.5,
--                -- cc.TEXT_ALIGNMENT_CENTER,cc.TEXT_ALIGNMENT_LEFT,cc.TEXT_ALIGNMENT_RIGHT
--                alignH = cc.TEXT_ALIGNMENT_CENTER,
--                -- cc.VERTICAL_TEXT_ALIGNMENT_BOTTOM,cc.VERTICAL_TEXT_ALIGNMENT_CENTER,cc.VERTICAL_TEXT_ALIGNMENT_TOP
--                alignV = cc.VERTICAL_TEXT_ALIGNMENT_CENTER,
--                -- alignH和alignV是针对于dimens的区域来说的。
--                -- width或者height为0时,则不限制。
--                --            dimens = { width = 200, height = 200 },
--                -- 与dimens同时使用,则失效,除非dimens的width为0才能生效
--                dimensW = 100,
--                dimensH = 200,
--                maxWidth = 500,
--                -- 是否裁剪label上下间距
--                clipMargin = true,
--                -- 设置行间距,不支持system font
--                lineH = 1000,
--                -- 最大行宽,内容超过MaxLineWidth,就会自动换行
--                -- 前提条件: 仅在width==0时,起作用。
--                lineBreakWithoutSpace = false,
--                anchor = cc.p(0.5,0.5),
--                opacity = 200,
--            },
--            {
--                class = "Label",
--                -- SysFont
--                sysFnt = "Arial",
--                fntSize = 50,
--                fntClr = cc.c3b(100,200,200)
--            },
--            {
--                class = "label",
--                -- BMFont字体
--                bmFnt = "bitmapFontTest4.fnt",
--                fntSize = 50,
--                fntClr = cc.c3b(100,200,200)
--            },
--            {
--                class = "label",
--                -- charMap类型,plist针对有多行的charmap,目前暂不支持
--                charMapPlist = "tuffy_bold_italic-charmap.plist"
--            },
--            {
--                class = "label",
--                -- charMap类型
--                charMap = "fucker.png",
--                itemW = 10,
--                itemH = 10,
--                start = string.byte("0")
--            }
--        }
--        local txt = ptf.ui.createUI(styles[1],"MotherFucker")
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
local Label = { __cname = "Label" }
local Node = import(".base.Node")

local setAttr = ptf.ui.setAttr

function Label.createInstance(style)
    local ret = nil
    if style.ttfConf then
        -- TTFConf类型的Label
        ret = cc.Label:createWithTTF(style.ttfConf, style.txt)
        if style.fntClr then
            ret:setTextColor(style.fntClr)
        end
    elseif style.sysFnt then
        -- SystemFont类型的Label
        ret = cc.Label:createWithSystemFont(style.txt, style.sysFnt, style.fntSize)
        if style.fntClr then
            ret:setTextColor(style.fntClr)
        end
    else
        if style.bmFnt then
            -- BMFont类型的Label
            ret = cc.Label:createWithBMFont(style.bmFnt, style.txt):setBMFontSize(style.fntSize)
        elseif style.charMap then
            -- CharMap类型的Label
            ret = cc.Label:createWithCharMap(style.charMap, style.itemW, style.itemH, style.start):setString(txt)
        elseif style.charMapPlist then
            -- CharMap类型的Label
            ret = cc.Label:createWithCharMap(style.charMapPlist):setString(style.txt)
        end
        if style.fntClr then
            ret:setColor(style.fntClr)
        end
    end
    Label.setAttr(ret, style)
    return ret
end

function Label.setAttr(ret, style)
    setAttr(ret, style, "setHorizontalAlignment", "alignH")
    setAttr(ret, style, "setVerticalAlignment", "alignV")
    setAttr(ret, style, "setDimensions", "dimensW", "dimensH")
    setAttr(ret, style, "setMaxLineWidth", "maxWidth")
    setAttr(ret, style, "setClipMarginEnabled", "clipMargin")
    setAttr(ret, style, "setLineHeight", "lineH")
    setAttr(ret, style, "setLineBreakWithoutSpace", "lineBreakWithoutSpace")
    -- 荧光
    setAttr(ret, style, "enableGlow", "glow")
    -- 描边
    setAttr(ret, style, "enableOutline", "outLineClr", "outLineSize")
    -- 阴影
    setAttr(ret, style, "enableShadow", "shadowClr", "shadowOffset", "shadowBlur")

    return ret
end

function Label.getAttr()
    return
    table.merge( {
        name = 5,
        txt = 4.5,
        sysFnt = 4,
        bmFnt = 4,
        fntSize = 3.2,
        ttfConf = 3.5,
        fntClr = 3.2,
        charMap = 3,
        itemW = 3,
        itemH = 3,
        start = 3,
        charMapPlist = 2.5,
        dimensW = 2,
        dimensH = 2,
        alignH = 2,
        alignV = 2,
        -- 描边
        outLineSize = 1.0,
        outLineClr = 0.9,
        maxWidth = 0.8,
        lineH = 0.7,
        clipMargin = 0.6,
        lineBreakWithoutSpace = 0.5,
        -- 荧光
        glow = 0.4,
        shadowClr = 0.3,
        shadowOffset = 0.2,
        shadowBlur = 0.1,
    } , Node.getAttr())
end

return Label
