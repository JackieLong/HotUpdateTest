-------------------------------------------------------------------------
-- Desc:          自定义CheckBox
-- Author:        Jackie Liu
-- ModifyDate:    2016/07/17 18:39:00
-- Purpose:
--        local checkBox = ptf.ui.createUI(
--        {
--            class = "CheckBox",
--            -- 普通状态
--            bg = "1.png",
--            -- 普通状态时的点击状态
--            bgSelected = "2.png",
--            -- 已经勾上状态
--            cross = "3.png",
--            -- 未勾上时的失效状态
--            bgDisabled = "4.png",
--            -- 勾上时的失效状态
--            crossDisabled = "5.png",
--        }
--        ):addTo(self):centerX(fucker):bottom(fucker)
--        :onClick(
--        function() print("************selected") end,
--        function() print("************unselected") end
--        )
--        checkBox:setSelected(false):setEnabled(false)
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
local CheckBox = { __cname = "CheckBox" }
local Node = import(".base.Node")

function CheckBox.createInstance(style)
    local ret = nil
    local bg = style.bg
    local bgSelected = style.bgSelected
    local cross = style.cross
    local bgDisabled = style.bgDisabled
    local crossDisabled = style.crossDisabled
    if not style.bgSelected or not style.bgDisabled or not style.crossDisabled then
        ret = ccui.CheckBox:create(
        style.bg,
        style.cross
        )
    else
        ret = ccui.CheckBox:create(
        style.bg,
        style.bgSelected,
        style.cross,
        style.bgDisabled,
        style.crossDisabled
        )
    end

    return ret
end

function ccui.CheckBox:onClick(selectedCallback, unselectedCallback)
    self:addEventListener( function(sender, eventType)
        if eventType == 0 then
            -- selected
            if selectedCallback then
                selectedCallback(sender)
            end
        else
            -- unselected
            if unselectedCallback then
                unselectedCallback(sender)
            end
        end
    end )
    return self
end

function CheckBox.getAttr()
    return
    table.merge( {
        name = 5,
        bg = 4.5,
        bgSelected = 4.0,
        cross = 3.5,
        bgDisabled = 3.0,
        crossDisabled = 2.5,
    } , Node.getAttr())
end

return CheckBox