-------------------------------------------------------------------------
-- Desc:          自定义富文本控件，生成的节点就是一个普通的带大小的node
-- Author:        Jackie Liu
-- ModifyDate:    2016/07/20 18:20:00
-- Purpose:
--        local styleRichTxt =
--        {
--            class = "RichTxt",
--            -- 反文本的宽高，超出的不予显示
--            richTxtWidth = 500,
--            richTxtHeight = 350,
--            -- 内容，可以是ui style，也可以是节点
--            txt =
--            {
--                {
--                    class = "Label",
--                    txt = "fucker",
--                    -- SysFont
--                    sysFnt = "Arial",
--                    fntSize = 50,
--                    fntClr = cc.c3b(100,200,200)
--                },
--                cc.Sprite:create("HelloWorld.png"):scale(0.1),
--                cc.Sprite:create("HelloWorld.png"):scale(0.2),
--                cc.Sprite:create("HelloWorld.png"):scale(1),
--                {
--                    class = "Label",
--                    txt = "fucker",
--                    -- SysFont
--                    sysFnt = "Arial",
--                    fntSize = 50,
--                    fntClr = cc.c3b(100,200,200)
--                },
--                cc.Sprite:create("HelloWorld.png")
--                :scale(0.3),

--                {
--                    class = "Label",
--                    txt = "fucker",
--                    -- SysFont
--                    sysFnt = "Arial",
--                    fntSize = 30,
--                    fntClr = cc.c3b(100,200,200)
--                },
--                cc.Sprite:create("HelloWorld.png")
--                :scale(0.4),

--                {
--                    class = "Label",
--                    txt = "fucker",
--                    -- SysFont
--                    sysFnt = "Arial",
--                    fntSize = 20,
--                    fntClr = cc.c3b(100,200,200)
--                },
--                cc.Sprite:create("HelloWorld.png")
--                :scale(0.5),

--                {
--                    txt = "fucker",
--                    class = "Label",
--                    -- SysFont
--                    sysFnt = "Arial",
--                    fntSize = 10,
--                    fntClr = cc.c3b(100,200,200)
--                },
--                cc.Sprite:create("HelloWorld.png"):scale(0.6),
--                cc.Sprite:create("HelloWorld.png"):scale(0.7),
--                cc.Sprite:create("HelloWorld.png"):scale(0.8),
--                cc.Sprite:create("HelloWorld.png"):scale(0.9),
--            }
--        }
--        -- 返回的就是一个和普通Node没有任何区别的node，只是
--        local richTxt = ptf.ui.createUI(styleRichTxt):addTo(self):right(fucker):bottom(fucker)
--        -- items是一个table，里面保存的是排布情况，内容格式如下
--        {
--            --第1行,maxHeight表示该行的高度，也是最高item的高度
--            --注意！！！只有maxHeight被显示的
--            --item1都是节点
--            {item1,item2,item3,item4,...,maxHeight = 100},
--            --第2行
--            {item1,item2,item3,item4,...,maxHeight = 100},
--            --第3行
--            {item1,item2,item3,item4,...,maxHeight = 100},
--            --第4行
--            {item1,item2,item3,item4,...,maxHeight = 100},
--        }
--        dump(richTxt.items)
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
local RichTxt = { __cname = "RichTxt" }
local Node = import(".base.Node")

function RichTxt.createInstance(style)
    local nodes = { }
    for k, v in ipairs(style.txt) do
        local node = nil
        if type(v) == "userdata" then
            -- 直接传入了节点，比如精灵Sprite
            node = v
        else
            node = ptf.ui.createUI(v)
        end
        nodes[#nodes + 1] = node
    end
    return self.createEx(nodes, style.richTxtWidth, style.richTxtHeight)
end

function RichTxt.createEx(nodes, width, height)
    local maxWidth = width
    local maxHeight = height
    local curLineIdx = 0
    local last = nil
    local ret = cc.Node:create()

    -- lines从宽度看，当前节点序列的排列情况，一个元素代表一行，每一行包含当前行的节点
    local lines = { }
    local tmpLine = nil
    local tmpWidth = 0
    -- 第一遍循环，先考虑宽度方向的放下情况
    for i, v in ipairs(nodes) do
        -- 当前节点的宽度
        local nodeWidth = v:width()
        if (tmpWidth + nodeWidth) <= maxWidth then
            -- 从宽度看，当前节点能放在当前行
            if not tmpLine then
                tmpLine = { }
                lines[#lines + 1] = tmpLine
            end
            tmpLine[#tmpLine + 1] = v
            tmpWidth = tmpWidth + nodeWidth
        else
            -- 从宽度看，当前节点在当前已经放不下了，则要换行
            tmpWidth = 0
            tmpLine = nil
            if (tmpWidth + nodeWidth) <= maxWidth then
                -- 换行之后能放得下则正常放
                tmpLine = { }
                lines[#lines + 1] = tmpLine
                tmpLine[#tmpLine + 1] = v
                tmpWidth = tmpWidth + nodeWidth
            else
                -- 换行之后还放不下说明当前节点在所有行都放不下
                break
            end
        end
    end
    tmpLine = nil
    tmpWidth = 0
    -- 当前的最大高度
    local tmpCurMaxHeight = 0
    -- 当前已经遍历的高度
    local tmpTotalHeight = 0
    -- targetIdx为空说明全部都能显示，反之则代表第几行开始显示不下了，
    -- 通过这个才能决定到底最终显示那些节点
    local targetIdx = nil
    for k, v in ipairs(lines) do
        for k1, v1 in ipairs(v) do
            -- 遍历找出当前行最高的节点
            tmpCurMaxHeight = math.max(v1:height(), tmpCurMaxHeight)
        end
        if (tmpCurMaxHeight + tmpTotalHeight) > maxHeight then
            -- 如果当前行加已有的高度已经超出，就不予显示了
            targetIdx = k
            break
        else
            -- 当前遍历的行能下，则继续循环
            tmpTotalHeight = tmpCurMaxHeight + tmpTotalHeight
            v.maxHeight = tmpCurMaxHeight
        end
        tmpCurMaxHeight = 0
    end

    -- 上一个添加的节点，方便定位当前节点加的位置
    local last = nil
    -- 第一个添加的节点，所以节点以这个节点对齐显示
    local tmpFirstNode = nil
    -- 遍历的当前行的下边框的位置，以最大高度的节点为准
    local offsetH = 0
    for k, v in ipairs(lines) do
        if targetIdx then
            -- targetIdx不为空代表行数为targetIdx之前的才能显示下
            if k == targetIdx then
                break
            end
        end
        for k1, v1 in ipairs(v) do
            if not tmpFirstNode then
                -- 初始化好初始值
                offsetH = v.maxHeight / 2
                -- 第一个加的节点
                tmpFirstNode = v1
                last = v1
                v1:addTo(ret):offsetY(offsetH - v.maxHeight + v1:height2())
            else
                -- 不是第一个添加的节点
                if not last then
                    -- 非第一行的第一个节点
                    last = v1
                    v1:addTo(ret):innerLeft(tmpFirstNode):offsetY(offsetH - v.maxHeight + v1:height2())
                else
                    -- 非第一行的非第一个节点
                    v1:addTo(ret):right(last):innerBottom(last)
                    last = v1
                end
            end
        end
        -- 遍历完了第一行
        offsetH = offsetH - v.maxHeight
        last = nil
    end
    last = nil
    tmpFirstNode = nil
    offsetH = nil
    -- 在这个条件里算出ret的size来
    if #lines > 0 then
        local retWidth, retHeight = 0, 0
        -- 是不是只能显示一行
        local isSingleLine = false
        if targetIdx then
            if targetIdx > 2 then
                isSingleLine = false
            else
                isSingleLine = true
            end
        else
            if #lines > 1 then
                isSingleLine = false
            else
                isSingleLine = true
            end
        end
        if not isSingleLine then
            -- 多行则宽度知道，高度需要计算
            for k, v in ipairs(lines) do
                -- 显示不完，只把能显示出来的考虑
                if targetIdx and targetIdx == v then
                    break
                end
                retHeight = retHeight + v.maxHeight
            end
            retWidth = width
            ret:size(retWidth, retHeight)
        else
            -- 一行则高度知道，宽度需要计算
            for k, v in ipairs(lines[1]) do
                retWidth = retWidth + v:width()
            end
            retHeight = lines[1].maxHeight
            ret:size(retWidth, retHeight)
        end
        --        dump(lines)
        local anchor = lines[1][1]:anchor()
        --        print("anchor" .. anchor.x .. "   " .. anchor.y)
        --        print("line[1].maxHeight = " .. lines[1].maxHeight)
        local offsetXToCenter = - anchor.x * lines[1][1]:width()
        local offsetYToCenter = retHeight - lines[1].maxHeight / 2
        --        local offsetXToCenter = retWidth / 2 - anchor.x * lines[1][1]:width()
        --        local offsetYToCenter = retHeight / 2 - lines[1].maxHeight / 2
        --        print("line[1][1].size = " .. lines[1][1]:width() .. "  " .. lines[1][1]:height())
        --        print("offsetXToCenter:" .. offsetXToCenter)
        --        print("offsetYToCenter:" .. offsetYToCenter)
        --        print("ret.size" .. ret:size().width .. "   " .. ret:size().height)
        for k, v in ipairs(lines) do
            -- 显示不完，只把能显示出来的考虑
            if targetIdx and targetIdx == v then
                break
            end
            for k1, v1 in ipairs(v) do
                v1:offset(
                - offsetXToCenter,
                offsetYToCenter
                )
            end
        end
    end
    ret.items = lines
    -- 只保留显示出来的item
    for k, v in ipairs(ret.items) do
        if not v.maxHeight then
            v = nil
        end
    end
    return ret
end

function RichTxt.getAttr()
    return
    table.merge( {
        name = 5,
        txt = 4,
        richTxtWidth = 3,
        richTxtHeight = 2
    } , Node.getAttr())
end

return RichTxt