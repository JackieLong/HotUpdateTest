-------------------------------------------------------------------------
-- Desc:          Slider
-- Author:        Jackie Liu
-- ModifyDate:    2016/07/21 17:00:00
-- Purpose:
--        local style =
--        {
--            class = "Slider",
--            percent = 50,
--            scale9Enabled = true,
--            capInsetProgressRenderer = cc.rect(0,1,1,1),
--            maxPercent = 100,
--            capInsetsBarRenderer = cc.rect(0,1,1,1),
--            capInsets = cc.rect(0,1,1,1),
--            zoomScale = 0.05,
--            ballTextureNormal = "HelloWorld.png",
--            progressTexture = "HelloWorld.png",
--            ballTextures = "HelloWorld.png",
--            barTexture = "HelloWorld.png",
--            ballTexturePressed = "HelloWorld.png",
--            ballTextureDisabled = "HelloWorld.png",
--        }
--        ptf.create(style):addTo(self):offset(400, 200)
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
local Slider = { __cname = "Slider" }
local Node = import(".base.Node")

local setAttr = ptf.ui.setAttr

function Slider.createInstance(style)
    local ret = ccui.Slider:create()

    Slider.setAttr(ret, style)

    return ret
end

function Slider.setAttr(ret, conf)
    setAttr(ret, style, "setPercent", "percent")
    setAttr(ret, style, "setScale9Enabled", "scale9Enabled")
    setAttr(ret, style, "setCapInsetProgressBarRenderer", "capInsetProgressRenderer")
    setAttr(ret, style, "setMaxPercent", "maxPercent")
    setAttr(ret, style, "setCapInsetsBarRenderer", "capInsetsBarRenderer")
    setAttr(ret, style, "setCapInsets", "capInsets")
    setAttr(ret, style, "setZoomScale", "zoomScale")
    setAttr(ret, style, "loadSlidBallTextureNormal", "ballTextureNormal")
    setAttr(ret, style, "loadProgressBarTexture", "progressTexture")
    setAttr(ret, style, "loadSlidBallTextures", "ballTextures")
    setAttr(ret, style, "addEventListener", "listener")
    setAttr(ret, style, "loadBarTexture", "barTexture")
    setAttr(ret, style, "loadSlidBallTexturePressed", "ballTexturePressed")
    setAttr(ret, style, "loadSlidBallTextureDisabled", "ballTextureDisabled")

    return ret
end

function Slider.getAttr()
    return
    table.merge( {
        name = 5,
        percent = 4,
        scale9Enabled = 3,
        capInsetProgressRenderer = 1,
        maxPercent = 4,
        capInsetsBarRenderer = 1,
        capInsets = 1,
        zoomScale = 2,
        ballTextureNormal = 2,
        progressTexture = 4,
        ballTextures = 2,
        listener = 2,
        barTexture = 3,
        ballTexturePressed = 2,
        ballTextureDisabled = 2,
    } , Node.getAttr())
end

return Slider