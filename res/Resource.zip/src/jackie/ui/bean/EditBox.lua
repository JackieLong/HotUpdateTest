-------------------------------------------------------------------------
-- Desc:          自定义输入框
-- Author:        Jackie Liu
-- ModifyDate:    2016/07/17 18:39:00
-- Purpose:
--        local styleEditBox =
--        {
--            class = "EditBox",
--            --        size = cc.size(300,300),
--            bg = "HelloWorld.png",
--            -- 注意不同平台对字体的支持
--            --        fonts/American Typewriter.ttf
--            fnt = "American Typewriter",
--            fntClr = cc.c3b(0,255,0),
--            fntSize = 50,
--            placeHolder = "MotherFucker",
--            placeHolderFntClr = cc.c3b(255,255,0),
--            placeHolderFntSize = 52,
--            maxLen = 20,
--            -- cc.KEYBOARD_RETURNTYPE_DEFAULT = 0
--            -- cc.KEYBOARD_RETURNTYPE_DONE = 1
--            -- cc.KEYBOARD_RETURNTYPE_SEND = 2
--            -- cc.KEYBOARD_RETURNTYPE_SEARCH = 3
--            -- cc.KEYBOARD_RETURNTYPE_GO = 4
--            returnType = cc.KEYBOARD_RETURNTYPE_GO,
--            -- cc.EDITBOX_INPUT_FLAG_PASSWORD = 0
--            -- cc.EDITBOX_INPUT_FLAG_SENSITIVE = 1
--            -- cc.EDITBOX_INPUT_FLAG_INITIAL_CAPS_WORD = 2
--            -- cc.EDITBOX_INPUT_FLAG_INITIAL_CAPS_SENTENCE = 3
--            -- cc.EDITBOX_INPUT_FLAG_INITIAL_CAPS_ALL_CHARACTERS = 4
--            inputFlag = cc.EDITBOX_INPUT_FLAG_INITIAL_CAPS_WORD,
--            --        cc.EDITBOX_INPUT_MODE_ANY = 0,
--            --        cc.EDITBOX_INPUT_MODE_EMAILADDR = 1,
--            --        cc.EDITBOX_INPUT_MODE_NUMERIC = 2,
--            --        cc.EDITBOX_INPUT_MODE_PHONENUMBER = 3,
--            --        cc.EDITBOX_INPUT_MODE_URL = 4,
--            --        cc.EDITBOX_INPUT_MODE_DECIMAL = 5,
--            --        cc.EDITBOX_INPUT_MODE_SINGLELINE = 6,
--            inputMode = cc.EDITBOX_INPUT_MODE_ANY,
--        }
--        local editBox = ptf.ui.createUI(styleEditBox):addTo(self):centerX(fucker):bottom(fucker)
--        -- 注册输入监听
--        editBox:registerEditListener( function(strEventName, pSender)
--            local edit = pSender
--            local strFmt
--            if strEventName == "began" then
--                strFmt = string.format("editBox %p DidBegin !", edit)
--                print(strFmt)
--            elseif strEventName == "ended" then
--                strFmt = string.format("editBox %p DidEnd !", edit)
--                print(strFmt)
--            elseif strEventName == "return" then
--                strFmt = string.format("editBox %p was returned !", edit)
--                print(strFmt)
--            elseif strEventName == "changed" then
--                strFmt = string.format("editBox %p TextChanged, text: %s ", edit, edit:getText())
--                print(strFmt)
--            end
--        end )
--        :unregisterEditListener()-- 注销监听
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
local EditBox = { __cname = "EditBox" }
local Node = import(".base.Node")

local setAttr = ptf.ui.setAttr

function EditBox.createInstance(style)
    local ret = nil
    if style.bg and style.bgPressed and style.bgDisabled then
        local size = style.size
        local bg = style.bg
        local bgPressed = style.bgPressed
        local bgDisabled = style.bgDisabled
        if not size then
            size = bg:getPreferredSize()
        else
            bg:setPreferredSize(size)
            bgPressed:setPreferredSize(size)
            bgDisabled:setPreferredSize(size)
        end
        ret = ccui.EditBox:create(size, bg, bgPressed, bgDisabled)
    elseif style.bg and style.bgPressed then
        local size = style.size
        local bg = style.bg
        local bgPressed = style.bgPressed
        if not size then
            size = bg:getPreferredSize()
        else
            bg:setPreferredSize(size)
            bgPressed:setPreferredSize(size)
        end
        ret = ccui.EditBox:create(size, bg, bgPressed)
    elseif style.bg then
        local size = style.size
        local bg = style.bg
        if type(bg) == "string" then
            local bgNode = ccui.Scale9Sprite:create(bg)
            if not size then
                size = bgNode:getPreferredSize()
            else
                bgNode:setPreferredSize(size)
            end
            ret = ccui.EditBox:create(size, bg)
        else
            if not size then
                size = bg:getPreferredSize()
            else
                bg:setPreferredSize(size)
            end
            ret = ccui.EditBox:create(size, bg)
        end
    end
    if style.editListener then ret:registerEditListener(style.editListener) end
    ptf.ui.setNodeAttrs(ret, "Widget", style)
    EditBox.setAttr(ret, style)
    return ret
end

function EditBox.setAttr(ret, style)
    setAttr(ret, style, "setText", "txt")
    setAttr(ret, style, "setFontName", "fnt")
    setAttr(ret, style, "setFontColor", "fntClr")
    setAttr(ret, style, "setFontSize", "fntSize")
    setAttr(ret, style, "setPlaceHolder", "placeHolder")
    setAttr(ret, style, "setPlaceholderFontColor", "placeHolderFntClr")
    setAttr(ret, style, "setPlaceholderFontSize", "placeHolderFntSize")
    setAttr(ret, style, "setMaxLength", "maxLen")
    setAttr(ret, style, "setReturnType", "returnType")
    setAttr(ret, style, "setInputFlag", "inputFlag")
    setAttr(ret, style, "setInputMode", "inputMode")
    return ret
end

local old = ccui.EditBox.registerScriptEditBoxHandler
local oldUn = ccui.EditBox.unregisterScriptEditBoxHandler

function ccui.EditBox:registerEditListener(listener)
    old(self, listener)
    return self
end

function ccui.EditBox:unregisterEditListener()
    oldUn(self)
    return self
end

function EditBox.getAttr()
    return
    table.merge( {
        name = 5,
        bg = 4.5,
        size = 4,
        fnt = 3.5,
        fntClr = 3.5,
        fntSize = 3.5,
        placeHolder = 3,
        placeHolderFntClr = 3,
        placeHolderFntSize = 3,
        maxLen = 2.5,
        bgPressed = 2.5,
        bgDisabled = 2.5,
        returnType = 2,
        inputFlag = 1,
        inputMode = 1,
    } , Node.getAttr())
end

return EditBox