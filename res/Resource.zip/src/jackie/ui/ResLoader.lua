-------------------------------------------------------------------------
-- Title:          资源加载工具
-- Author:      Jackie Liu
-- Date:         2016/04/04 21:08:55
-- Desc:
--        1、异步加载/卸载指定目录下的资源，必须是通过python脚本生成资源文件（如赢三张项目下的res.lua文件）
--        2、ResLoadConf为加载配置，可添加对新资源的加载
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
local ResLoader = class('ResLoader')
local ResLoadConf = nil

function ResLoader:ctor()
    self.loadDir = nil
    self.unLoadDir = nil
    self.loadEndedCallback = nil
    self.unLoadEndedCallback = nil
end

function ResLoader:load(dir, callback)
    if dir and ResLoadConf then
        self.loadDir = { }
        self.loadEndedCallback = callback
        self:_parseRes(self.loadDir, dir)

        -- added by jackie 2016/04/04
        if #self.loadDir > 0 then
            local tmpTbl = { }
            for i = 1, #self.loadDir do
                tmpTbl[#tmpTbl + 1] = { dir = self.loadDir[i], filesize = io.filesize(cc.FileUtils:getInstance():fullPathForFilename(self.loadDir[i])) or 0 }
            end
            self.loadDir = { }
            table.sort(tmpTbl, function(a, b) return a.filesize > b.filesize end)
            for i = 1, #tmpTbl do
                self.loadDir[i] = tmpTbl[i].dir
            end
            self:_load()
        end
    else
        if callback then callback() end
    end
end

function ResLoader:unload(dir, callback)
    if dir and ResLoadConf then
        self.unLoadDir = { }
        self.unLoadEndedCallback = callback
        self:_parseRes(self.unLoadDir, dir)
        self:_unLoad()
    else
        if callback then callback() end
    end
end

function ResLoader:_parseRes(save, dir)
    if type(dir) == 'string' then
        local splits = string.split(dir, ".")
        for k, v in pairs(ResLoadConf) do
            if v.check(splits[#splits]) then
                table.insert(save, dir)
                break
            end
        end
    elseif type(dir) == 'table' then
        for k, v in pairs(dir) do
            self:_parseRes(save, v)
        end
    end
end

function ResLoader:_load()
    if #self.loadDir > 0 then
        local dir = self.loadDir[#self.loadDir]
        if dir then
            local splits = string.split(dir, ".")
            -- 遍历加载配置
            for k, v in pairs(ResLoadConf) do
                if v.check(splits[#splits]) then
                    v.handle_load(dir, function()
                        table.remove(self.loadDir)
                        self:_load()
                    end )
                    break
                end
            end
        end
    else
        self.loadDir = nil
        self.unLoadDir = nil
        self.unLoadEndedCallback = nil
        --        self.loadEndedCallback = nil
        if self.loadEndedCallback then self.loadEndedCallback() end
    end
end

function ResLoader:_unLoad()
    for k, v in ipairs(self.unLoadDir) do
        local splits = string.split(v, ".")
        for k1, v1 in pairs(ResLoadConf) do
            if v1.check(splits[#splits]) then
                v1.handle_unLoad(v)
                break
            end
        end
    end
    self.loadDir = nil
    self.unLoadDir = nil
    self.loadEndedCallback = nil
    --    self.unLoadEndedCallback = nil
    if self.unLoadEndedCallback then self.unLoadEndedCallback() end
end

-- 资源加载配置
ResLoadConf =
{
    -- PNG,JPG图片加卸载方式
    IMG =
    {
        -- 什么是IMG
        check = function(extName) return extName == "jpg" or extName == "png" end,
        -- IMG加载方式
        handle_load = function(fullPathName, callback)
            if not display.getImage(fullPathName) then
                display.loadImage(fullPathName, callback)
            else
                if callback then callback() end
            end
        end,
        -- IMG卸载方式
        handle_unLoad = function(fullPathName)
            display.removeSpriteFrame(fullPathName)
            display.removeImage(fullPathName)
        end
    },
    -- plist文件加卸载方式
    PLIST =
    {
        -- 什么是PLIST
        check = function(extName) return extName == "plist" end,
        -- IMG加载方式
        handle_load = function(fullPathName, callback)
            display.loadSpriteFrames(fullPathName, string.sub(fullPathName, -5) .. 'png')
            if callback then callback() end
        end,
        -- IMG卸载方式
        handle_unLoad = function(fullPathName)
            display.removeSpriteFrames(fullPathName, string.sub(fullPathName, -5) .. 'png')
        end
    },
}

return ResLoader