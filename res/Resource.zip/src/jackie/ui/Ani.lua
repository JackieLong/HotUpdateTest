-------------------------------------------------------------------------
-- Author:      Jackie Liu
-- Date:        2017-03-30 11:50:24
-- Desc:        动画管理工具，不可多得的好东西哦
--        local conf = {
--            class = "Spawn",
--            {
--                class = "Repeat",
--                time = 10,
--                cc.ScaleTo:create(1 / 24,10),-- 函数被认为是CallFunc
--                1.0,-- 数字被认为是delay
--                cc.ScaleTo:create(1 / 24,1),-- 函数被认为是CallFunc
--                1.0,-- 数字被认为是delay
--            },
--            {
--                -- 配置型的Action，举例Animate
--                class = "Ani",
--                speed = 1.5 / 24,
--                -- 没帧的时间
--                -- 播放次数
--                time = 30,
--                -- 帧的表，务必以数字和字母的升序来命名
--                dir =
--                {
--                    flash_a = "ani/cell_ani/cell_erase/cell_erase_a.png",
--                    flash_b = "ani/cell_ani/cell_erase/cell_erase_b.png",
--                    flash_c = "ani/cell_ani/cell_erase/cell_erase_c.png",
--                    flash_d = "ani/cell_ani/cell_erase/cell_erase_d.png",
--                },
--                --默认是true
--                orignal = true,
--            },
--            --ScaleTo
--            { class = "ScaleTo", 10.0, 5.0 },
--            0.5,-- 数字被认为是delay
--            function() print("********shit") end-- 函数被认为是CallFunc
--        }
--        sprite:runAction(ptf.ui.createAni(conf))
-- Revisions:         Jackie Liu create this file at 2017-03-30 11:50:24
-- Copyright (c) 2017 Jackie Game
-------------------------------------------------------------------------
local createMap = nil
local createAni = nil

createAni = function(style, ...)
    --    k,v 中的v是下面这些值就直接确定要生成什么
    if type(style) == "userdata" then return style end
    if type(style) == "number" then return cc.DelayTime:create(style) end
    if type(style) == "function" then return cc.CallFunc:create(style) end

    if style.class then return createMap[style.class](style, ...) end

    local seqStyle = { }
    for k, v in ipairs(style) do
        if type(v) ~= "string" then
            seqStyle[k] = v
        end
    end
    if #seqStyle > 0 then
        if #seqStyle == 1 then
            return createAni(seqStyle[1])
        else
            return createMap.Sequence(seqStyle)
        end
    end
end

createMap = {
    Sequence = function(style)
        if type(style) == "userdata" then
            return style
        end
        if #style > 0 then
            local cell = { }
            for k, v in ipairs(style) do
                if type(v) ~= "string" then
                    cell[#cell + 1] = createAni(v)
                end
            end
            return cc.Sequence:create(cell)
        end
    end,

    Repeat = function(style)
        if type(style) == "userdata" then return style end
        local time = style.time or 1
        local seqStyle = { }
        for k, v in ipairs(style) do
            if type(v) ~= "string" then
                seqStyle[#seqStyle + 1] = v
            end
        end
        if #seqStyle > 0 then
            if #seqStyle == 1 then
                return cc.Repeat:create(createAni(seqStyle[1]), time)
            else
                return cc.Repeat:create(createMap.Sequence(seqStyle), time)
            end
        end
    end,

    RepeatForever = function(style)
        if type(style) == "userdata" then return style end
        local seqStyle = { }
        for k, v in ipairs(style) do
            if type(v) ~= "string" then
                seqStyle[#seqStyle + 1] = v
            end
        end
        if #seqStyle > 0 then
            if #seqStyle == 1 then
                return cc.RepeatForever:create(createAni(seqStyle[1]))
            else
                return cc.RepeatForever:create(createMap.Sequence(seqStyle))
            end
        end
    end,

    Spawn = function(style)
        if type(style) == "userdata" then return style end
        local acts = { }
        for k, v in pairs(style) do
            if type(v) ~= "string" then
                acts[#acts + 1] = createAni(v)
            end
        end
        if #acts > 0 then
            return cc.Spawn:create(acts)
        end
    end,
    --    {class = "RotateTo",10,100}
    RotateTo = function(style)
        if type(style) == "userdata" then return style end
        return cc.RotateTo:create(style[1], style[2])
    end,
    --    {class = "RotateBy",10,100}
    RotateBy = function(style)
        if type(style) == "userdata" then return style end
        return cc.RotateBy:create(style[1], style[2])
    end,
    --    {class = "MoveTo",10,213.5,354.5}
    MoveTo = function(style)
        if type(style) == "userdata" then return style end
        return cc.MoveTo:create(style[1], cc.p(style[2], style[3]))
    end,
    --    {class = "MoveBy",10,213.5,354.5}
    MoveBy = function(style)
        if type(style) == "userdata" then return style end
        return cc.MoveBy:create(style[1], cc.p(style[2], style[3] or 0.0))
    end,
    --    {class = "ScaleTo",1.0,2.0}
    ScaleTo = function(style)
        if type(style) == "userdata" then return style end
        return cc.ScaleTo:create(style[1], style[2])
    end,
    --    {class = "ScaleBy",1.0,2.0}
    ScaleBy = function(style)
        if type(style) == "userdata" then return style end
        return cc.ScaleBy:create(style[1], style[2])
    end,
    --    {class = "FadeTo",1.0,150}
    FadeTo = function(style)
        if type(style) == "userdata" then return style end
        return cc.FadeTo:create(style[1], style[2])
    end,
    --    {class = "FadeBy",1.0,150}
    FadeBy = function(style)
        if type(style) == "userdata" then return style end
        return cc.FadeBy:create(style[1], style[2])
    end,
    --    {class = "FadeIn",1.0}
    FadeIn = function(style)
        if type(style) == "userdata" then return style end
        return cc.FadeIn:create(style[1])
    end,
    --    {class = "FadeOut",1.0}
    FadeOut = function(style)
        if type(style) == "userdata" then return style end
        return cc.FadeOut:create(style[1])
    end,
    --    {class = "TintTo",1.0,cc.c3b(100,200,200)}
    TintTo = function(style)
        if type(style) == "userdata" then return style end
        return cc.TintTo:create(style[1], style[2])
    end,
    --    {class = "TintBy",1.0,cc.c3b(100,200,200)}
    TintBy = function(style)
        if type(style) == "userdata" then return style end
        return cc.TintTo:create(style[1], style[2])
    end,
    --    {class = "Delay",1.0}
    Delay = function(style)
        if type(style) == "userdata" then return style end
        return cc.DelayTime:create(style[1])
    end,

    Ani = function(style)
        if type(style) == "userdata" then return style end
        local dir = style.dir
        local speed = style.speed or ptf.conf.ui.ANI_SPEED
        local repeatTime = style.time or cc.REPEAT_FOREVER
        local orignal = style.orignal == nil and true or style.orignal
        local frameStartIdx = style.frameStartIdx or 1

        local frames = { }
        if dir then
            local frameFiles = dir
            for k, v in ipairs(frameFiles) do
                local texture = display.getImage(v)
                if not texture then
                    texture = display.loadImage(v)
                end
                local size = texture:getContentSize()
                frames[#frames + 1] = display.newSpriteFrame(texture, cc.rect(0, 0, size.width, size.height))
            end
        elseif style.format and style.frameCount and frameStartIdx then
            if style.plist then
                frames = display.newFrames(style.format, style.frameStartIdx, style.frameCount)
            else
                local tmpName = nil
                for i = frameStartIdx, style.frameCount do
                    tmpName = string.format(style.format, i)
                    local texture = display.getImage(tmpName)
                    if not texture then
                        texture = display.loadImage(tmpName)
                    end
                    local size = texture:getContentSize()
                    frames[#frames + 1] = display.newSpriteFrame(texture, cc.rect(0, 0, size.width, size.height))
                end
            end
        end
        return
        cc.Animate:create(cc.Animation:createWithSpriteFrames(frames, speed, repeatTime):setRestoreOriginalFrame(orignal))
        --        cc.Sprite:createWithSpriteFrame(frames[1])
    end,
    --    {class = "Delay",function()end}
    CallFunc = function(style)
        if type(style) == "userdata" then return style end
        return cc.CallFunc:create(style[1])
    end,
}

return createAni