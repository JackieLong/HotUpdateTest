-------------------------------------------------------------------------
-- Title:          UI模块，资源模块更为准确。
-- Author:        Jackie Liu
-- CreateDate:    2016/09/11 18:37:20
-- Desc:
--            动画工具
--            快速创建布局工具
--            资源加载工具
--            视图管理工具
--            图形化布局编辑工具
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
local ptf = ptf
local ui = { }
ptf.ui = ui

import(".extension.ExtNode")
import(".extension.ExtLayer")
import(".extension.ExtScene")

-- 当前scene
ui.mainScene = nil

ui.baseView = import(".BaseView")

-- 创建UI方法
import(".UI")

-- 将会根据UIResLoaderConf进行资源的加载
ui.resLoader = import(".ResLoader").create()

ui.viewMgr = import(".ViewMgr").create()

ui.createAni = import(".Ani")

-- 只允许出现唯一的scene
local old = ptf.director.runWithScene
local assert = ptf.log.assert
ptf.director.runWithScene = function(_, scene)
    old(_, scene)
    ui.mainScene = scene
    ptf.director.runWithScene = old
    return scene
end