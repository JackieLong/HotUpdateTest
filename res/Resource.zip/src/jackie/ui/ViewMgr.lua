-------------------------------------------------------------------------
-- Desc:        视图管理
-- Author:        Jackie Liu
-- ModifyDate:    2016/04/04 23:35:00
-- Purpose:
--    --负责界面堆栈的管理，界面生命周期的控制，界面切换等管理工作
--    --一个被添加到ViewMgr的view栈中的view可以用的方法如下
--    --界面生成前的回调，返回需要加载的资源列表
--    view:onPreload()
--    -- 界面生成
--    view:onGetLayout(view)
--    -- 界面销毁前的回调,返回需要卸载的资源列表
--    view:onDestroy()
--    -- 返回loading界面
--    view:onLoadingView()
--    -- view切换动画,in进入的动画，out退出的动画，返回动画的时间
--    view:onTransAniIn(view ,viewOld)
--    view:onTransAniOut(view,viewOld)
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
local ViewMgr = class("ViewMgr")
local TAG = "ViewMgr"
local UIResLoader = ptf.ui.resLoader
local director = ptf.director
local safeExeSeq = ptf.util.safeExeSeq
local safeExefld = ptf.util.safeExefld
local createUI = ptf.ui.createUI

local assert = ptf.log.assert
local error = ptf.log.error

function ViewMgr:ctor()
    --    {
    --        {
    --            view = loginView,state = only_reference
    --        }
    --    }
    self._viewStack = { }
    self._queueTsk = { }
    self.data = { }
    self.data._isHandling = false
    self._out_of_view_listener = nil
    ptf.util.bindDataListener(self.data, {
        _isHandling = function(old, new)
            if not new then
                self:_checkQueue()
            end
        end
    } )
end

function ViewMgr:close()

end

function ViewMgr:_checkQueue()
    if #self._queueTsk > 0 and not self.data._isHandling then
        self.data._isHandling = true
        local tsk, params = unpack(table.remove(self._queueTsk, 1))
        tsk(params)
    end
end

function ViewMgr:_addTsk(tsk, params)
    self._queueTsk[#self._queueTsk + 1] = { tsk, params }
    self:_checkQueue()
end

-- replaceView：替换栈顶view
-- 替换界面过程：
-- 新界面有loadingView
-- 1、loadingView入场动画。loadingView:onTransAniIn()
-- 2、oldView卸载工作，UIResLoader:unload()
-- 3、oldView退出，oldView:removeFromParent()
-- 4、newView预加载工作，UIResLoader:load()
-- 5、newView生成界面工作，newView:onGetLayout()
-- 5.5、newView界面稳定，newView:onCreateView(view)
-- 6、newView入场动画（）,newView:onTransAniIn
-- 7、loadingView退出。loadingView:removeFromParent()
-- 新界面没有loadingView
-- 1、oldView卸载工作，UIResLoader:unload()
-- 2、newView预加载工作，UIResLoader:load()
-- 3、newView生成界面工作，newView:onGetLayout()
-- 3.5 newView生成界面工作，newView:onCreateView(view)
-- 4、newView入场动画,newView:onTransAniIn
-- 5、oldView退出，oldView:removeFromParent()
function ViewMgr:replaceView(view, params)
    if self:_checkView(view) then
        if #self._viewStack == 0 then
            self:addView(view, params)
            do return end
        end
        if #self._viewStack > 0 then
            self:_addTsk( function(params)
                local viewInstance = nil
                local loadingView = safeExefld(view, "onLoadingView")
                local loadingViewInstance = nil
                local curViewState = self:_topView()
                local curView = curViewState.view
                local curViewInstance = nil
                if curView then
                    curViewInstance = curView:getView()
                end
                if loadingView then
                    -- 生成loadingView
                    local loadingLayout = safeExefld(loadingView, "onGetLayout")
                    if not self:_checkLayout(loadingLayout) then
                        self:dumpInfo()
                        self.data._isHandling = false
                        return
                    end
                    -- loadingLayout.parent = ptf.ui.mainScene
                    loadingViewInstance = createUI(loadingLayout)
                    safeExefld(loadingView, "onCreateView", loadingViewInstance)
                    --                    loadingLayout.parent = ptf.ui.mainScene
                    loadingViewInstance:addTo(ptf.ui.mainScene)
                    safeExeSeq(loadingViewInstance,
                    -- loadingView入场动画
                    cc.DelayTime:create(safeExefld(loadingView, "onTransAniIn", loadingViewInstance, curViewInstance) or 0),
                    function()
                        -- oldView资源卸载
                        UIResLoader:unload(safeExefld(curView, "onDestroy"),
                        function()
                            -- oldView退出
                            if curViewInstance then
                                curViewInstance:removeFromParent()
                                curViewInstance = nil
                            end

                            if params and params.keep_last_reference then
                                curViewState.state = "only_reference"
                            else
                                self:_popViewStack()
                            end

                            -- newView预加载
                            UIResLoader:load(safeExefld(view, "onPreload"),
                            function()
                                -- newView生成界面
                                local curLayout = safeExefld(view, "onGetLayout")
                                if not self:_checkLayout(curLayout) then
                                    self:dumpInfo()
                                    self.data._isHandling = false
                                    return
                                end
                                -- curLayout.parent = ptf.ui.mainScene
                                viewInstance = createUI(curLayout)
                                safeExefld(view, "onCreateView", viewInstance)
                                --                                curLayout.parent = ptf.ui.mainScene
                                viewInstance:addTo(ptf.ui.mainScene)
                                safeExeSeq(viewInstance,
                                -- newView入场动画
                                cc.DelayTime:create(safeExefld(view, "onTransAniIn", viewInstance, loadingViewInstance) or 0),
                                function()
                                    loadingViewInstance:removeFromParent()
                                    loadingViewInstance = nil
                                    self:_pushViewStack( { view = view })
                                    self:dumpInfo()
                                    self.data._isHandling = false
                                end )
                            end )
                        end )
                    end )
                else
                    -- 没有loadingView的情况
                    -- curView卸载
                    UIResLoader:unload(safeExefld(curView, "onDestroy"),
                    function()
                        -- newView预加载
                        UIResLoader:load(safeExefld(view, "onPreload"),
                        function()
                            -- 生成newView
                            local curLayout = safeExefld(view, "onGetLayout")
                            if not self:_checkLayout(curLayout) then
                                self:dumpInfo()
                                self.data._isHandling = false
                                return
                            end
                            -- curLayout.parent = ptf.ui.mainScene
                            viewInstance = createUI(curLayout)
                            safeExefld(view, "onCreateView", viewInstance)
                            --                            curLayout.parent = ptf.ui.mainScene
                            viewInstance:addTo(ptf.ui.mainScene)
                            safeExeSeq(viewInstance,
                            -- newView入场动画
                            cc.DelayTime:create(safeExefld(view, "onTransAniIn", viewInstance, curViewInstance) or 0),
                            function()
                                -- curView退出
                                if curViewInstance then
                                    curViewInstance:removeFromParent()
                                    curViewInstance = nil
                                end
                                if params and params.keep_last_reference then
                                    curViewState.state = "only_reference"
                                else
                                    self:_popViewStack()
                                end
                                self:_pushViewStack( { view = view })
                                self:dumpInfo()
                                self.data._isHandling = false
                            end )
                        end )
                    end )
                end
            end , params)
        else
            error("ViewMgr:replceView", "there must be at least 1 view in stack while executing replaceView.try ViewMgr:addView")
        end
    end
end

-- replaceView的衍生形态：替换栈顶view，但在back的时候，会返回这个view。
-- 适用的场景：大厅进入游戏的时候，需要关闭大厅并清理大厅资源，但是在游戏里要能返回大厅。
function ViewMgr:replaceViewEx(view)
    self:replaceView(view, { keep_last_reference = true })
end

-- addView：新增界面到栈顶
-- 添加界面过程：
-- 新界面有loadingView
-- 1、loadingView入场动画。loadingView:onTransAniIn()
-- 4、newView预加载工作，UIResLoader:load()
-- 5、newView生成界面工作，newView:onGetLayout()
-- 6、newView入场动画（）,newView:onTransAniIn
-- 7、loadingView退出。loadingView:removeFromParent()
-- 新界面没有loadingView
-- 2、newView预加载工作，UIResLoader:load()
-- 3、newView生成界面工作，newView:onGetLayout()
-- 4、newView入场动画,newView:onTransAniIn
-- 5、oldView退出，oldView:removeFromParent()
function ViewMgr:addView(view, params)
    if self:_checkView(view) then
        self:_addTsk( function(params)
            local viewInstance = nil
            local loadingView = safeExefld(view, "onLoadingView")
            local loadingViewInstance = nil
            local curView = self:_topView() and self:_topView().view or nil
            local curViewInstance = nil
            if curView then
                curViewInstance = curView:getView()
            end
            if loadingView then
                -- 有loadingView的情况
                -- 创建loadingView
                local loadingLayout = safeExefld(loadingView, "onGetLayout")
                if not self:_checkLayout(loadingLayout) then
                    self:dumpInfo()
                    self.data._isHandling = false
                    return
                end
                --                loadingLayout.parent = ptf.ui.mainScene
                loadingViewInstance = createUI(loadingLayout)
                safeExefld(loadingView, "onCreateView", loadingViewInstance)
                -- 需要出发onCreateView中的onEnter回调
                --                loadingLayout.parent = ptf.ui.mainScene
                loadingViewInstance:addTo(ptf.ui.mainScene)

                safeExeSeq(loadingViewInstance,
                -- loadingView入场动画
                cc.DelayTime:create(safeExefld(loadingView, "onTransAniIn", loadingViewInstance, curViewInstance) or 0),
                function()
                    -- newView预加载
                    UIResLoader:load(safeExefld(view, "onPreload"),
                    function()
                        -- 生成newView
                        local curLayout = safeExefld(view, "onGetLayout")
                        if not self:_checkLayout(curLayout) then
                            self:dumpInfo()
                            self.data._isHandling = false
                            return
                        end
                        -- curLayout.parent = ptf.ui.mainScene
                        viewInstance = createUI(curLayout)
                        safeExefld(view, "onCreateView", viewInstance)
                        --                        curLayout.parent = ptf.ui.mainScene
                        viewInstance:addTo(ptf.ui.mainScene)
                        safeExeSeq(viewInstance,
                        -- newView入场动画
                        cc.DelayTime:create(safeExefld(view, "onTransAniIn", viewInstance, loadingViewInstance) or 0),
                        function()
                            -- loadingView退出
                            loadingViewInstance:removeFromParent()
                            loadingViewInstance = nil
                            self:_popViewStack()
                            self:_pushViewStack( { view = view })
                            self:dumpInfo()
                            self.data._isHandling = false
                        end )
                    end )
                end )
            else
                -- 没有loadingView的情况
                UIResLoader:load(
                -- view预加载
                safeExefld(view, "onPreload"),
                function()
                    -- view生成
                    local curLayout = safeExefld(view, "onGetLayout")
                    if not self:_checkLayout(curLayout) then
                        self:dumpInfo()
                        self.data._isHandling = false
                        return
                    end
                    -- curLayout.parent = ptf.ui.mainScene
                    viewInstance = createUI(curLayout)
                    safeExefld(view, "onCreateView", viewInstance)
                    --                    curLayout.parent = ptf.ui.mainScene
                    viewInstance:addTo(ptf.ui.mainScene)
                    -- view入场动画
                    safeExeSeq(viewInstance, cc.DelayTime:create(safeExefld(view, "onTransAniIn", viewInstance, curViewInstance) or 0))
                    self:_pushViewStack( { view = view })
                    self:dumpInfo()
                    self.data._isHandling = false
                end )
            end
        end , params)
    end
end

function ViewMgr:back()
    self:_addTsk( function()
        local topViewState = self:_topView()
        local state = topViewState.state
        ptf.log.debug(TAG, "back view[%s]", topViewState.view.__cname)
        ptf.log.debug(TAG, "curViewStack", self._viewStack)
        if #self._viewStack > 1 then
            local secondViewState = self:_topView(2)
            if secondViewState.state == "only_reference" then
                -- 只保留了引用，并没有视图界面了，需要再生成
                local state = self:_popViewStack(2)
                self:replaceView(state.view:create())
                self.data._isHandling = false
            else
                local topView = topViewState.view
                local topViewInstance = topView:getView()
                local secondTop = secondViewState.view
                local secondTopInstance = secondTop:getView()
                UIResLoader:unload(
                -- curView卸载
                safeExefld(topView, "onDestroy"),
                function()
                    -- 退出动画
                    safeExeSeq(topViewInstance, cc.DelayTime:create(safeExefld(topView, "onTransAniOut", topView:getView(), secondTop:getView()) or 0),
                    function()
                        -- 退出
                        topViewInstance:removeFromParent()
                        topViewInstance = nil
                        self:_popViewStack()
                        self:dumpInfo()
                        self.data._isHandling = false
                    end )
                end )
            end
        else
            if self._out_of_view_listener then
                self._out_of_view_listener()
            end
            self.data._isHandling = false
        end
    end )
end

-- 检查View的合法性
function ViewMgr:_checkView(view)
    if not view then
        error("ViewMgr:_checkView", "nil is invalid view")
        return false
    end
    if not view.onGetLayout and type(view.onGetLayout) == "function" then
        error("ViewMgr:_checkView", "invalid view which must have a method named onGetLayout")
        return false
    end
    if not view.getView and type(view.getView) == "function" then
        error("ViewMgr:_checkView", "invalid view which must have a method named getView")
        return false
    end
    return true
end

-- 检查View的onGetLayout方法返回的界面布局文件的合法性
function ViewMgr:_checkLayout(layout)
    if not layout then
        error("ViewMgr:_checkViewLayout", "nil is invalid view")
        return false
    end
    if not layout.class then
        error("ViewMgr:_checkViewLayout", "invalid view which must have a attr named class")
        return false
    end
    --    if layout.parent then
    --        error("ViewMgr:_checkViewLayout", "invalid view, attr named parent is forbidden.")
    --        return false
    --    end
    return true
end

-- 栈里只有一个view时候，按返回键触发会带
function ViewMgr:setOutOfViewListener(callback)
    self._out_of_view_listener = callback
end

-- idx=1表示栈顶，默认栈顶
function ViewMgr:_topView(idx)
    if #self._viewStack > 0 then
        local targetView = self._viewStack[idx and #self._viewStack - idx + 1 or #self._viewStack]
        return targetView
    end
end

-- idx=1表示栈顶，默认栈顶
function ViewMgr:_popViewStack(idx)
    return table.remove(self._viewStack, idx and(#self._viewStack - idx + 1) or #self._viewStack)
end

-- viewState:可以看成是view及其状态的集合体
-- viewState = { view= view的实例,... }，...保存了一些状态参数
function ViewMgr:_pushViewStack(state)
    table.insert(self._viewStack, state)
end

function ViewMgr:dumpInfo()
    --    ptf.log.debug("ViewMgr", self._viewStack)
    return self
end

return ViewMgr