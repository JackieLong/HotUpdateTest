-------------------------------------------------------------------------
-- Desc:          框架配置
-- Author:        Jackie Liu
-- ModifyDate:    2016/07/13 23:09:00
-- Purpose:
--        当前版本的框架基于cocos2dx 3.12版本设计，
--        由于触控的一贯尿性，接入新版本cocos2dx可
--        能导致框架与引擎不兼容。
-- Copyright (c) Jackie Liu All right reserved.
-------------------------------------------------------------------------
return
{
    -- 资源设计分辨率
    -- 资源分辨率到设计分辨率的缩放因子，0.5意思就是资源都被放大2倍。
    DESIGN_SIZE = cc.size(1280,960),
    -- 屏幕的缩放比，只在非android，ios下有效
    FRAME_ZOOM_FACTOR = 0.4,
    -- 渲染帧率,1秒刷新的帧数
    FRAME_RATE = 30.0,
    -- 日志配置
    log =
    {
        LVL = ptf.contants.log.DEBUG,
        -- 是否将日志保存到本地
        WRITE_LOCAL = false,
        -- 本地日志保存地址
        WRITE_PATH = 'log.txt',
        -- 日志文件大小
        WRITE_SIZE = 1024 * 1024 * 10,
        -- 是否需要将日志上传服务器
        UPLOAD_SERVER = false,
        -- 上传日志服务器账号
        UPLOAD_ACCOUNT = { username = "liul", psw = "username" },
        -- 上传参数
        UPLOAD_PARAM = { method = "POST", svrAddr = 'http://192.168.10.204:8080/xGame/LogUpload.action' },
    },
    -- ui配置
    ui =
    {
        -- 双次点击返回键退出时间反应间隔
        TWICE_CLICK_TO_EXIT = 1.5,
        -- 按钮防多连击的默认时间间隔
        INTRVL_SAFE_CLICK = 1.0,
        -- 帧动画速度，1秒24帧。
        ANI_SPEED = 1 / 24,
        -- 默认按钮点击灵敏度：在按钮上滑动的位移作为点击的界限。
        -- 灵敏度越高，意味着按钮上越不能滑动当做点击
        DEFAULT_BTN_SENSIVITY = 5,
        -- pageView的翻页灵敏度
        PAGEVIEW_CUSTOM_THRESHOLD = 50,
        -- pageView自动翻页时的速度
        PAGEVIEW_SPEED = 2000.0,
        -- 默认UIButton上的字体大小
        DEFAULT_BTN_TITLE_SIZE = 25.0,
        -- uiListView默认每页有多少个item
        DEFAULT_LISTVIEW_COUNT_PER_FRAME = 10,
    },
}