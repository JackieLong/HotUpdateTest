-------------------------------------------------------------------------
-- Title:        常量
-- Author:    Jackie Liu
-- Date:       2016/09/13 15:48:27
-- Desc:
-- Copyright (c) wawagame Entertainment All right reserved.
-------------------------------------------------------------------------
return
{
    -- 日志等级
    log =
    {
        VERBOSE = 2,
        DEBUG = 3,
        INFO = 4,
        WARN = 5,
        ERROR = 6,
        ASSERT = 7,
    },
    ui =
    {
        -- RadioGroup的方向。
        RadioGroup_Direction =
        {
            Horizontal = 1,
            Vertical = 2,
        },
        TabDockPlace =
        {
            TOP = 0,
            LEFT = 1,
            BOTTOM = 2,
            RIGHT = 3
        },
        TabEventType =
        {
            SELECT_CHANGED = 0
        },
        ListView =
        {
            MagneticType =
            {
                NONE = 0,
                CENTER = 1,
                BOTH_END = 2,
                LEFT = 3,
                RIGHT = 4,
                TOP = 5,
                BOTTOM = 6,
            }
        },
        Parent = 1,
    }
}