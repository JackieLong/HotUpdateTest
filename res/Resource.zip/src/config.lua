-- 屏幕方向设置方法：修改项目根目录下的配置文件config.json中的init_cfg中的isLandscape字段true横屏，false竖屏
-- win32平台下，当使用插件babelua开发，启动lua项目时，可能是搜索路径的问题，不会读取到根目录下的config.json导致那里设置屏幕方向无效。
-- 因此需要这个常量来手动设置。只针对win32平台,mac平台上并没有测过
LANDSCAPE_WIN32 = true
-- 0 - disable debug info, 1 - less debug info, 2 - verbose debug info
DEBUG = 1
-- use framework, will disable all deprecated API, false - use legacy API
CC_USE_FRAMEWORK = true
-- show FPS on screen
CC_SHOW_FPS = true
-- 是否启用全局变量限制声明
CC_DISABLE_GLOBAL = true
-- for module display
--CC_DESIGN_RESOLUTION =
--{
--    width = 960,
--    height = 640,
--    autoscale = "FIXED_HEIGHT",
--    callback = function(framesize)
--        local ratio = framesize.width / framesize.height
--        if ratio <= 1.34 then
--            -- iPad 768*1024(1536*2048) is 4:3 screen
--            return { autoscale = "FIXED_WIDTH" }
--        end
--    end
--}